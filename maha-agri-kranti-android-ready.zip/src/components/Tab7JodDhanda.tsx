import React, { useState } from 'react';
import { 
  Coins, 
  DollarSign, 
  TrendingUp, 
  PlayCircle, 
  Volume2, 
  CheckCircle2, 
  Sparkles,
  X,
  ArrowRight
} from 'lucide-react';
import { JOD_DHANDA_LIST } from '../data/agriData';
import { JodDhandaItem } from '../types';
import { speakMarathi } from '../utils/speech';

export const Tab7JodDhanda: React.FC = () => {
  const [selectedGuideModal, setSelectedGuideModal] = useState<JodDhandaItem | null>(null);

  const handleSpeakJodDhanda = (item: JodDhandaItem) => {
    const text = `${item.titleMr}. मासिक संभाव्य नफा: ${item.monthlyIncome}. सुरुवातीचा खर्च: ${item.setupCost}. सरकारी कर्ज योजना: ${item.loanScheme}. ${item.stepsMr.join('. ')}.`;
    speakMarathi(text);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Header Banner */}
      <div className="bg-gradient-to-br from-[#1B5E20] via-emerald-800 to-slate-900 text-white p-3.5 rounded-2xl shadow-lg border border-emerald-500">
        <div className="flex items-center justify-between mb-1">
          <span className="bg-[#FFC107] text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
            💰 शेतकऱ्यांचे फायदेशीर जोडधंदे
          </span>
          <span className="text-[10px] text-amber-300 font-bold">
            दरमहा ₹२५,००० ते ₹८०,००० कमाई
          </span>
        </div>
        <h2 className="text-base font-black text-white leading-tight">
          शेतीसोबत ५ शाश्वत जोडधंदे — दरमहा खात्रीशीर अतिरिक्त उत्पन्न!
        </h2>
        <p className="text-[11px] text-emerald-100 mt-0.5">
          दुग्ध व्यवसाय, कुक्कुटपालन, शेळीपालन, मधमाशी व अळंबी शेती
        </p>
      </div>

      {/* 5 Enterprise Cards */}
      <div className="space-y-3">
        {JOD_DHANDA_LIST.map((item) => (
          <div
            key={item.id}
            className="bg-white p-3.5 rounded-2xl shadow-md border border-slate-200 hover:border-emerald-500 transition-all"
          >
            <div className="flex items-start justify-between gap-2 mb-2">
              <div className="flex items-center gap-2">
                <span className="text-3xl p-1.5 bg-amber-50 rounded-xl border border-amber-200">
                  {item.iconEmoji}
                </span>
                <div>
                  <h3 className="text-xs font-black text-slate-950 leading-tight">
                    {item.titleMr}
                  </h3>
                  <span className="text-[10px] text-slate-500 font-medium">{item.titleEn}</span>
                </div>
              </div>
              <button
                onClick={() => handleSpeakJodDhanda(item)}
                className="p-1.5 bg-amber-100 hover:bg-amber-200 text-slate-900 rounded-lg shrink-0"
                title="ऐका"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </div>

            {/* 3 Stats Boxes: Utpadan, Kharch, Loan */}
            <div className="grid grid-cols-3 gap-1.5 mb-3 text-center">
              <div className="bg-emerald-50 p-2 rounded-xl border border-emerald-200">
                <span className="text-[9px] text-emerald-700 block font-semibold">मासिक उत्पन्न</span>
                <span className="text-[10px] font-black text-emerald-950 block mt-0.5">
                  {item.monthlyIncome}
                </span>
              </div>

              <div className="bg-slate-50 p-2 rounded-xl border border-slate-200">
                <span className="text-[9px] text-slate-500 block font-semibold">सुरुवातीचा खर्च</span>
                <span className="text-[10px] font-bold text-slate-900 block mt-0.5">
                  {item.setupCost}
                </span>
              </div>

              <div className="bg-amber-50 p-2 rounded-xl border border-amber-200">
                <span className="text-[9px] text-amber-800 block font-semibold">कर्ज / सबसिडी</span>
                <span className="text-[10px] font-black text-amber-950 block mt-0.5">
                  {item.subsidyPercent}
                </span>
              </div>
            </div>

            <div className="text-[11px] text-slate-700 font-medium mb-3 bg-slate-50 p-2 rounded-xl border border-slate-100">
              💡 <strong>बाजारपेठ संधी:</strong> {item.marketTips}
            </div>

            {/* Action Button */}
            <button
              onClick={() => {
                setSelectedGuideModal(item);
                speakMarathi(`${item.titleMr} कसा सुरू करावा याचे संपूर्ण मार्गदर्शन उघडले आहे.`);
              }}
              className="w-full bg-[#1B5E20] hover:bg-emerald-800 text-amber-300 font-black py-2.5 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow active:scale-95 transition-all border border-emerald-500"
            >
              <PlayCircle className="w-4 h-4 text-amber-400" />
              <span>सुरू कसा करावा? व्हिडिओ व मार्गदर्शक पहा</span>
            </button>
          </div>
        ))}
      </div>

      {/* Guide Details Modal */}
      {selectedGuideModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl border-2 border-emerald-600 overflow-hidden">
            <div className="bg-[#1B5E20] text-white p-3 flex items-center justify-between">
              <h3 className="font-bold text-xs text-amber-300">
                {selectedGuideModal.titleMr}
              </h3>
              <button onClick={() => setSelectedGuideModal(null)} className="text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 space-y-3 text-xs">
              {/* Video Mock */}
              <div className="aspect-video bg-slate-900 rounded-xl flex flex-col items-center justify-center text-white p-3 relative overflow-hidden">
                <PlayCircle className="w-10 h-10 text-amber-400 mb-1 animate-pulse" />
                <span className="text-xs font-bold text-amber-200 text-center">
                  यशस्वी शेतकऱ्यांचा थेट अनुभव व नफा-तोटा हिशोब
                </span>
                <span className="text-[9px] bg-red-600 px-2 py-0.5 rounded-full mt-1">
                  HD शेती यशोगाथा 📹
                </span>
              </div>

              {/* Step by step checklist */}
              <div className="space-y-1.5">
                <span className="font-bold text-slate-900 block">सुरू करण्यासाठी मुख्य टप्पे:</span>
                {selectedGuideModal.stepsMr.map((step, idx) => (
                  <div key={idx} className="flex items-start gap-2 bg-emerald-50 p-2 rounded-lg text-[11px] text-slate-800">
                    <span className="font-bold text-emerald-800">{idx + 1}.</span>
                    <span>{step}</span>
                  </div>
                ))}
              </div>

              <div className="bg-amber-50 p-2.5 rounded-xl border border-amber-200 text-[11px]">
                <span className="font-bold text-amber-950 block">सरकारी योजना व बँक सहकार्य:</span>
                <p className="text-slate-800 font-semibold">{selectedGuideModal.loanScheme}</p>
              </div>

              <button
                onClick={() => setSelectedGuideModal(null)}
                className="w-full bg-slate-800 text-white font-bold py-2 rounded-xl"
              >
                माहिती समजली (Close)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
