package com.mahaagri.kranti.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColorScheme = lightColorScheme(
    primary = Green800,
    onPrimary = SurfaceCard,
    primaryContainer = Green100,
    onPrimaryContainer = Green900,
    secondary = Amber500,
    onSecondary = Slate900,
    secondaryContainer = Amber100,
    onSecondaryContainer = Slate900,
    background = BackgroundLight,
    surface = SurfaceCard,
    onSurface = Slate900,
    outline = Slate200
)

@Composable
fun MahaAgriTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        typography = Typography,
        content = content
    )
}
