import { 
  DiseaseInfo, 
  DoctorExpert, 
  SugarcaneVariety, 
  RegionFarmer, 
  MarketCropItem, 
  SugarKarkhana, 
  ProcessingKarkhana, 
  SarkariYojana, 
  JodDhandaItem, 
  AgriVideoLesson,
  LiveMandiRate,
  FarmingEquipment,
  ProgressiveFarmerStory
} from '../types';

export const DISEASES_DATABASE: DiseaseInfo[] = [
  {
    id: 'leafy_veg_spot',
    nameMr: 'पालेभाज्यांवरील पानांचे ठिपके (Leaf Spot)',
    nameEn: 'Leafy Vegetables Leaf Spot / Blight',
    cropMr: 'पालेभाज्या (पालक, मेथी, कोथिंबीर)',
    cropEn: 'Leafy Vegetables',
    seasonMr: 'सर्व हंगामात (विशेषत: पावसाळ्यात व दमट हवेत)',
    severityPercent: 45,
    severityLabel: '४५% पानांवर काळे/तपकिरी डाग',
    upcharMr: 'मॅन्कोझेब (Mancozeb) २.५ ग्रॅम किंवा कॉपर ऑक्सिक्लोराईड (COC) २ ग्रॅम / लिटर पाणी फवारणी करावी. फवारणीनंतर किमान ४-५ दिवस भाजी काढू नये.',
    kharchMr: '₹३०० / एकर',
    medicines: [
      { brand: 'Dithane M-45 (Mancozeb)', company: 'Corteva', dose: '2.5 gm/Ltr पाणी', timing: 'सुरुवातीच्या टप्प्यात' },
      { brand: 'Blitox (Copper Oxychloride)', company: 'Tata Rallis', dose: '2 gm/Ltr पाणी', timing: 'रोग वाढल्यास' }
    ],
    imagePlaceholder: '🥬'
  },
  {
    id: 'leafy_veg_aphids',
    nameMr: 'पालेभाज्यांवरील मावा (Aphids)',
    nameEn: 'Leafy Vegetables Aphids',
    cropMr: 'पालेभाज्या (कोथिंबीर, मेथी, मोहरी)',
    cropEn: 'Leafy Vegetables',
    seasonMr: 'हिवाळा आणि उन्हाळा',
    severityPercent: 55,
    severityLabel: '५५% पानांच्या मागील बाजूस हिरवे/काळे कीटक',
    upcharMr: '५% निंबोळी अर्काची फवारणी करावी. प्रादुर्भाव जास्त असल्यास थायोमेथोक्झाम (Thiamethoxam) ०.५ ग्रॅम / लिटर फवारावे.',
    kharchMr: '₹३५० / एकर',
    medicines: [
      { brand: 'Neem Oil 10000 PPM', company: 'Organic', dose: '3 ml/Ltr पाणी', timing: 'सुरुवातीच्या अवस्थेत' },
      { brand: 'Actara (Thiamethoxam)', company: 'Syngenta', dose: '0.5 gm/Ltr पाणी', timing: 'किडीचा प्रादुर्भाव जास्त असल्यास' }
    ],
    imagePlaceholder: '🥬'
  },

  {
    id: 'wheat_rust',
    nameMr: 'गहू तांबेरा (Wheat Rust)',
    nameEn: 'Wheat Rust (Brown/Yellow)',
    cropMr: 'गहू (Wheat - Lokwan/HD2189)',
    cropEn: 'Wheat',
    seasonMr: 'रब्बी (थंडीच्या दिवसात)',
    severityPercent: 50,
    severityLabel: '५०% पानांवर पिवळे/तपकिरी डाग',
    upcharMr: 'मॅन्कोझेब (Mancozeb) २.५ ग्रॅम किंवा प्रोपिकोनाझोल (Tilt) १ मिली / लिटर पाणी फवारणी करावी.',
    kharchMr: '₹४०० / एकर',
    medicines: [
      { brand: 'Dithane M-45 (Mancozeb)', company: 'Corteva', dose: '2.5 gm/Ltr पाणी', timing: 'सुरुवातीच्या टप्प्यात' },
      { brand: 'Tilt 25% EC (Propiconazole)', company: 'Syngenta', dose: '1 ml/Ltr पाणी', timing: 'प्रादुर्भाव वाढल्यास' }
    ],
    imagePlaceholder: '🌾'
  },
  {
    id: 'rice_blast',
    nameMr: 'भात करपा रोग (Rice Blast)',
    nameEn: 'Rice Blast Fungus',
    cropMr: 'भात / तांदूळ (Rice - Indrayani/Basmati)',
    cropEn: 'Rice',
    seasonMr: 'खरीप (पावसाळा - दमट हवामान)',
    severityPercent: 65,
    severityLabel: '६५% पानांवर डोळ्यांच्या आकाराचे डाग',
    upcharMr: 'ट्रायसायक्लाझोल (Tricyclazole) ०.६ ग्रॅम किंवा आयसोप्रोथिओलेन (Fuji-One) १.५ मिली / लिटर पाणी फवारावे.',
    kharchMr: '₹५०० / एकर',
    medicines: [
      { brand: 'Baan (Tricyclazole 75% WP)', company: 'Coromandel', dose: '0.6 gm/Ltr पाणी', timing: 'रोग दिसताच फवारा' },
      { brand: 'Fuji-One (Isoprothiolane 40% EC)', company: 'Rallis', dose: '1.5 ml/Ltr पाणी', timing: 'करपा वाढल्यावर' }
    ],
    imagePlaceholder: '🌾'
  },
  {
    id: 'jowar_shoot_fly',
    nameMr: 'ज्वारी खोडमाशी (Shoot Fly)',
    nameEn: 'Jowar Shoot Fly',
    cropMr: 'ज्वारी (Jowar/Sorghum - Maldandi)',
    cropEn: 'Jowar',
    seasonMr: 'रब्बी / खरीप (पेरणीनंतर १ ते ४ आठवडे)',
    severityPercent: 40,
    severityLabel: '४०% मुख्य कोंब सुकलेले (Dead Heart)',
    upcharMr: 'इमिडाक्लोप्रिड (Imidacloprid) बीजप्रक्रिया किंवा क्लोरपायरीफॉस (Chlorpyrifos) २०% EC २ मिली / लिटर पाणी फवारणी.',
    kharchMr: '₹३५० / एकर',
    medicines: [
      { brand: 'Gaucho (Imidacloprid 600 FS)', company: 'Bayer', dose: '10 ml/kg बियाणे', timing: 'पेरणीपूर्वी बीजप्रक्रिया' },
      { brand: 'Dursban 20 EC (Chlorpyrifos)', company: 'Corteva', dose: '2 ml/Ltr पाणी', timing: 'खोडमाशी दिसल्यावर' }
    ],
    imagePlaceholder: '🌾'
  },
  {
    id: 'bajra_ergot',
    nameMr: 'बाजरी अरगट (चिकटा रोग)',
    nameEn: 'Bajra Ergot (Sticky honeydew)',
    cropMr: 'बाजरी (Bajra/Pearl Millet)',
    cropEn: 'Bajra',
    seasonMr: 'खरीप (फुलोरा अवस्थेत पाऊस असल्यास)',
    severityPercent: 55,
    severityLabel: '५५% कणसातून चिकट स्राव',
    upcharMr: 'मॅन्कोझेब (Mancozeb) २.५ ग्रॅम किंवा कार्बेन्डाझिम (Carbendazim) १ ग्रॅम / लिटर पाणी फवारणी.',
    kharchMr: '₹३०० / एकर',
    medicines: [
      { brand: 'SAAF (Mancozeb + Carbendazim)', company: 'UPL', dose: '2 gm/Ltr पाणी', timing: 'फुलोरा अवस्थेत प्रतिबंधात्मक' }
    ],
    imagePlaceholder: '🌾'
  },
  {
    id: 'maize_fall_armyworm',
    nameMr: 'मका लष्करी अळी (Fall Armyworm)',
    nameEn: 'Maize Fall Armyworm (FAW)',
    cropMr: 'मका (Maize/Corn)',
    cropEn: 'Maize',
    seasonMr: 'खरीप व रब्बी (सर्व हंगामात)',
    severityPercent: 70,
    severityLabel: '७०% पोंग्यात अळ्या व खाल्लेली पाने',
    upcharMr: 'स्पायनेटोरम (Delegate) ०.५ मिली किंवा इमामेक्टिन बेंझोएट (Proclaim) ०.४ ग्रॅम / लिटर पाणी पोंग्यात फवारावे.',
    kharchMr: '₹६५० / एकर',
    medicines: [
      { brand: 'Delegate (Spinetoram 11.7% SC)', company: 'Corteva', dose: '0.5 ml/Ltr पाणी', timing: 'अळीचा प्रादुर्भाव वाढल्यावर' },
      { brand: 'Proclaim (Emamectin Benzoate 5% SG)', company: 'Syngenta', dose: '0.4 gm/Ltr पाणी', timing: 'लहान अळ्या दिसल्यास' }
    ],
    imagePlaceholder: '🌽'
  },

  {
    id: 'banana_sigatoka',
    nameMr: 'केळी सिगाटोका (काळे व तपकिरी ठिपके)',
    nameEn: 'Banana Black Sigatoka Fungus',
    cropMr: 'केळी (Banana G9)',
    cropEn: 'Banana',
    seasonMr: 'खरीप - पावसात व दमट हवेत जास्त प्रादुर्भाव',
    severityPercent: 45,
    severityLabel: '४५% पान खराब (मध्यम धोका)',
    upcharMr: 'टिल्ट (Tilt) २५% EC १ मिली / लिटर पाणी + बाविस्टीन (Bavistin) १ ग्रॅम / लिटर - ७ दिवसांच्या अंतराने २ फवारण्या कराव्यात.',
    kharchMr: '₹४५० / एकर',
    medicines: [
      { brand: 'Tilt 25% EC (Propiconazole)', company: 'Syngenta', dose: '1 ml/Ltr पाणी', timing: 'सकाळी किंवा संध्याकाळी' },
      { brand: 'Bavistin 50% WP (Carbendazim)', company: 'Crystal Crop', dose: '1 gm/Ltr पाणी', timing: 'पहिल्या फवारणीनंतर ७ दिवसांनी' },
      { brand: 'Silwet Gold (Sticker)', company: 'Chemtura', dose: '0.3 ml/Ltr', timing: 'पावसात धुवून न जाण्यासाठी' }
    ],
    imagePlaceholder: '🍌'
  },
  {
    id: 'grape_downy',
    nameMr: 'द्राक्ष डाऊनी मिल्ड्यू (केवडा रोग)',
    nameEn: 'Grape Downy Mildew (Plasmopara)',
    cropMr: 'द्राक्ष (Grapes - Thomson Seedless)',
    cropEn: 'Grapes',
    seasonMr: 'ऑगस्ट-ऑक्टोबर छाटणी नंतर (पावसाळा)',
    severityPercent: 60,
    severityLabel: '६०% पान व घड बाधित (तात्काळ फवारणी आवश्यक)',
    upcharMr: 'अलियेट (Aliette) २ ग्रॅम + एक्रोबॅट (Acrobat) १ ग्रॅम / लिटर पाणी. पाण्याचा निचरा योग्य ठेवावा.',
    kharchMr: '₹६८० / एकर',
    medicines: [
      { brand: 'Aliette (Fosetyl-Al)', company: 'Bayer CropScience', dose: '2 gm/Ltr पाणी', timing: 'धुके किंवा रिमझिम पाऊस असताना' },
      { brand: 'Acrobat (Dimethomorph)', company: 'BASF', dose: '1 gm/Ltr पाणी', timing: 'घड अवस्थेत सुरक्षित' }
    ],
    imagePlaceholder: '🍇'
  },
  {
    id: 'sugarcane_rust',
    nameMr: 'ऊस तांबेरा व पोक्का बोईंग',
    nameEn: 'Sugarcane Rust & Pokkah Boeng',
    cropMr: 'ऊस (Sugarcane 86032 / 265)',
    cropEn: 'Sugarcane',
    seasonMr: 'जुलै-सप्टेंबर (जास्त आद्रता)',
    severityPercent: 30,
    severityLabel: '३०% पानांवर तांबडे डाग (नियंत्रणात)',
    upcharMr: 'साफ (SAAF) २ ग्रॅम / लिटर किंवा कस्टोडिया (Custodia) १.५ मिली फवारणी + युरियाचा अतिरेक टाळावा.',
    kharchMr: '₹३८० / एकर',
    medicines: [
      { brand: 'SAAF (Mancozeb + Carbendazim)', company: 'UPL Limited', dose: '2 gm/Ltr पाणी', timing: 'पाने पिवळी पडताना' },
      { brand: 'Custodia', company: 'ADAMA', dose: '1.5 ml/Ltr पाणी', timing: 'वाढ जोमात असताना' }
    ],
    imagePlaceholder: '🎋'
  },
  {
    id: 'chilli_murda',
    nameMr: 'मिरची चुरडा-मुरडा (थ्रिप्स व माइट्स)',
    nameEn: 'Chilli Leaf Curl & Thrips',
    cropMr: 'मिरची (Chilli - G-4 / Teja)',
    cropEn: 'Chilli',
    seasonMr: 'उन्हाळी व हिवाळी कोरडे हवामान',
    severityPercent: 50,
    severityLabel: '५०% पाने चुरडली आहेत',
    upcharMr: 'पेगासस (Pegasus) १.२ ग्रॅम किंवा डेलिगेट (Delegate) ०.९ मिली / लिटर पाणी. निंबोळी अर्क ५ मिली वापरावा.',
    kharchMr: '₹५२० / एकर',
    medicines: [
      { brand: 'Pegasus (Diafenthiuron)', company: 'Syngenta', dose: '1.2 gm/Ltr', timing: 'माइट्स व पांढरी माशीसाठी' },
      { brand: 'Delegate (Spinetoram)', company: 'Corteva', dose: '0.9 ml/Ltr', timing: 'थ्रिप्स नियंत्रणासाठी' }
    ],
    imagePlaceholder: '🌶️'
  },
  {
    id: 'cotton_pink_bollworm',
    nameMr: 'कापूस गुलाबी बोंडअळी',
    nameEn: 'Cotton Pink Bollworm',
    cropMr: 'कापूस (Cotton)',
    cropEn: 'Cotton',
    seasonMr: 'ऑगस्ट-ऑक्टोबर (फुले व बोंडे येताना)',
    severityPercent: 75,
    severityLabel: '७५% प्रादुर्भाव (अत्यंत धोकादायक)',
    upcharMr: 'प्रोफेनोफॉस ५०% ईसी २ मिली किंवा स्पिनोसॅड ४५% एससी ०.३ मिली / लिटर पाणी फवारणी करा. कामगंध सापळे (Pheromone traps) लावा.',
    kharchMr: '₹४५० / एकर',
    medicines: [
      { brand: 'Profenofos 50% EC', company: 'Nagarjuna / PI', dose: '2 ml/Ltr पाणी', timing: 'पाती व बोंडे लागताना' },
      { brand: 'Spinosad (Tracer)', company: 'Corteva', dose: '0.3 ml/Ltr पाणी', timing: 'अळीचा प्रादुर्भाव वाढल्यास' }
    ],
    imagePlaceholder: '☁'
  },
  {
    id: 'soybean_stem_fly',
    nameMr: 'सोयाबीन खोडमाशी व चक्रीभुंगा',
    nameEn: 'Soybean Stem Fly & Girdle Beetle',
    cropMr: 'सोयाबीन (Soybean)',
    cropEn: 'Soybean',
    seasonMr: 'पेरणीनंतर १५-३० दिवसांनी (खरीप)',
    severityPercent: 55,
    severityLabel: '५५% झाडे पिवळी (लगेच फवारणी)',
    upcharMr: 'क्लोरँट्रानिलिप्रोल (Coragen) ०.३ मिली किंवा थायोमेथोक्झाम + लॅम्बडा सायहॅलोथ्रिन (Alika) ०.५ मिली / लिटर पाणी फवारावे.',
    kharchMr: '₹५५० / एकर',
    medicines: [
      { brand: 'Coragen', company: 'FMC', dose: '0.3 ml/Ltr पाणी', timing: 'किडीची अंडी/अळी दिसताच' },
      { brand: 'Alika', company: 'Syngenta', dose: '0.5 ml/Ltr पाणी', timing: 'चक्रीभुंगा नियंत्रणासाठी' }
    ],
    imagePlaceholder: '🌱'
  },
  {
    id: 'onion_purple_blotch',
    nameMr: 'कांदा करपा (जांभळा करपा)',
    nameEn: 'Onion Purple Blotch / Blight',
    cropMr: 'कांदा (Onion)',
    cropEn: 'Onion',
    seasonMr: 'रब्बी व खरीप (ढगाळ व दमट हवामान)',
    severityPercent: 65,
    severityLabel: '६५% पाने सुकली (गंभीर)',
    upcharMr: 'मँकोझेब (M-45) २.५ ग्रॅम किंवा टेब्युकोनॅझोल (Folicur) १ मिली / लिटर पाणी + स्टिकर मिसळून फवारणी करा.',
    kharchMr: '₹३५० / एकर',
    medicines: [
      { brand: 'Dithane M-45 (Mancozeb)', company: 'Corteva', dose: '2.5 gm/Ltr पाणी', timing: 'सुरुवातीच्या काळात' },
      { brand: 'Folicur (Tebuconazole)', company: 'Bayer', dose: '1 ml/Ltr पाणी', timing: 'करपा वेगाने पसरत असल्यास' }
    ],
    imagePlaceholder: '🧅'
  },
  {
    id: 'pomegranate_bacterial_blight',
    nameMr: 'डाळिंब तेल्या रोग (Bacterial Blight)',
    nameEn: 'Pomegranate Bacterial Blight (Telya)',
    cropMr: 'डाळिंब (Pomegranate - Bhagwa)',
    cropEn: 'Pomegranate',
    seasonMr: 'पावसाळा (दमट हवामान)',
    severityPercent: 80,
    severityLabel: '८०% फळे व पाने बाधित (अति गंभीर)',
    upcharMr: 'ब्रोनोपोल ०.५ ग्रॅम + कॉपर ऑक्सिक्लोराईड २.५ ग्रॅम / लिटर पाणी फवारा. बाधित फळे व फांद्या तोडून जाळा.',
    kharchMr: '₹७०० / एकर',
    medicines: [
      { brand: 'Bactronash (Bronopol)', company: 'Various', dose: '0.5 gm/Ltr पाणी', timing: 'पावसाळी वातावरणात' },
      { brand: 'Blitox (Copper Oxychloride)', company: 'Tata Rallis', dose: '2.5 gm/Ltr पाणी', timing: 'बुरशी व जिवाणू नियंत्रणासाठी' }
    ],
    imagePlaceholder: '🔴'
  },
  {
    id: 'tomato_early_blight',
    nameMr: 'टोमॅटो करपा व नागअळी',
    nameEn: 'Tomato Blight & Leaf Miner',
    cropMr: 'टोमॅटो (Tomato)',
    cropEn: 'Tomato',
    seasonMr: 'सर्व हंगाम (विशेषतः पावसाळा)',
    severityPercent: 50,
    severityLabel: '५०% प्रादुर्भाव',
    upcharMr: 'अझोक्सीस्ट्रोबिन (Amistar) १ मिली / लिटर पाणी करप्यासाठी. नागअळीसाठी अबामेक्टिन (Abamectin) १ मिली / लिटर फवारा.',
    kharchMr: '₹४८० / एकर',
    medicines: [
      { brand: 'Amistar (Azoxystrobin)', company: 'Syngenta', dose: '1 ml/Ltr पाणी', timing: 'करप्याचे ठिपके दिसताच' },
      { brand: 'Abacin (Abamectin)', company: 'Crystal', dose: '1 ml/Ltr पाणी', timing: 'नागअळीच्या रेषा दिसल्यास' }
    ],
    imagePlaceholder: '🍅'
  },
  {
    id: 'maize_fall_armyworm',
    nameMr: 'मका लष्करी अळी (Fall Armyworm)',
    nameEn: 'Maize Fall Armyworm',
    cropMr: 'मका (Maize / Corn)',
    cropEn: 'Maize',
    seasonMr: 'खरीप व रब्बी (पेरणीनंतर १०-४० दिवस)',
    severityPercent: 70,
    severityLabel: '७०% पोंगे बाधित',
    upcharMr: 'इमामेक्टिन बेंझोएट (Proclaim) ०.४ ग्रॅम किंवा स्पिनोटोरम (Delegate) ०.५ मिली / लिटर पाणी फवारणी पोंग्यात करा.',
    kharchMr: '₹६५० / एकर',
    medicines: [
      { brand: 'Proclaim (Emamectin)', company: 'Syngenta', dose: '0.4 gm/Ltr पाणी', timing: 'अळी लहान असताना' },
      { brand: 'Delegate (Spinetoram)', company: 'Corteva', dose: '0.5 ml/Ltr पाणी', timing: 'मोठ्या अळीच्या नियंत्रणासाठी' }
    ],
    imagePlaceholder: '🌽'
  },
  {
    id: 'orange_gummosis',
    nameMr: 'मोसंबी / संत्रा डिंक्या रोग',
    nameEn: 'Citrus Gummosis (Phytophthora)',
    cropMr: 'मोसंबी / संत्रा (Citrus)',
    cropEn: 'Citrus (Orange / Sweet Lime)',
    seasonMr: 'पावसाळा व हिवाळा',
    severityPercent: 60,
    severityLabel: '६०% खोडातून डिंक स्रवत आहे',
    upcharMr: 'मेटॅलॅक्सिल + मँकोझेब (Ridomil Gold) २.५ ग्रॅम / लिटर पाण्याने खोड धुवावे व पेस्ट लावावी.',
    kharchMr: '₹५०० / एकर',
    medicines: [
      { brand: 'Ridomil Gold', company: 'Syngenta', dose: '2.5 gm/Ltr पाणी', timing: 'खोडातून डिंक येताना' },
      { brand: 'Bordeaux Paste (बोर्डो पेस्ट)', company: 'Home Made', dose: 'खोड रंगवणे', timing: 'पावसाळ्यापूर्वी व नंतर' }
    ],
    imagePlaceholder: '🍊'
  },
  {
    id: 'tur_pod_borer',
    nameMr: 'तूर शेंगा पोखरणारी अळी (हेलिकोवर्पा)',
    nameEn: 'Pigeon Pea Pod Borer (Helicoverpa)',
    cropMr: 'तूर (Pigeon Pea)',
    cropEn: 'Tur / Pigeon Pea',
    seasonMr: 'फुलोरा व शेंगा धरताना (नोव्हेंबर-जानेवारी)',
    severityPercent: 55,
    severityLabel: '५५% शेंगा बाधित (तातडीची फवारणी)',
    upcharMr: 'क्लोरँट्रानिलिप्रोल (Coragen) ०.३ मिली किंवा फ्लुबेंडायमाईड (Fame) ०.३ मिली / लिटर पाणी फवारावे.',
    kharchMr: '₹६०० / एकर',
    medicines: [
      { brand: 'Coragen (Chlorantraniliprole)', company: 'FMC', dose: '0.3 ml/Ltr पाणी', timing: 'फुलोरा अवस्थेत व शेंगा धरताना' },
      { brand: 'Fame (Flubendiamide)', company: 'Bayer', dose: '0.3 ml/Ltr पाणी', timing: 'अळीचा प्रादुर्भाव दिसताच' }
    ],
    imagePlaceholder: '🌿'
  }

];

export const DOCTOR_EXPERTS: DoctorExpert[] = [
  {
    id: 'dr_anil_pawar',
    name: 'डॉ. अनिल पवार (PhD)',
    degree: 'PhD (Horticulture) MPKV राहुरी',
    specialtyMr: 'केळी तज्ज्ञ - G9 टिशू कल्चर व निर्यात सल्लागार',
    specialtyEn: 'Banana & Export Specialist',
    locationMr: 'बारामती - इंदापूर (पुणे)',
    experience: '१५ वर्षे अनुभव (३०००+ शेतकरी)',
    phone: '9021458701',
    rating: 4.9,
    isAvailable: true,
    avatar: '🌱'
  },
  {
    id: 'dr_sunil_deshmukh',
    name: 'डॉ. सुनील देशमुख (PhD)',
    degree: 'PhD (Plant Pathology) NRC Grapes',
    specialtyMr: 'द्राक्ष रोग व ग्लोबल गॅप (GlobalGAP) युरोप निर्यात',
    specialtyEn: 'Grapes & Disease Expert',
    locationMr: 'पिंपळगाव बसवंत, नाशिक',
    experience: '१८ वर्षे अनुभव',
    phone: '9422789102',
    rating: 4.95,
    isAvailable: true,
    avatar: '🍇'
  },
  {
    id: 'dr_kavita_more',
    name: 'डॉ. कविता मोरे (PhD)',
    degree: 'PhD (Biotechnology) जैन हिल्स',
    specialtyMr: 'टिश्यू कल्चर रोपे व सूक्ष्म अन्नद्रव्य व्यवस्थापन',
    specialtyEn: 'Tissue Culture & Nutrition',
    locationMr: 'जळगाव (खानदेश)',
    experience: '१२ वर्षे अनुभव',
    phone: '9823145603',
    rating: 4.85,
    isAvailable: true,
    avatar: '🌱'
  },
  {
    id: 'dr_ramesh_patil',
    name: 'डॉ. रमेश पाटील (MSc Agri)',
    degree: 'MSc (Agronomy) VSI पुणे',
    specialtyMr: 'ऊस उत्पादन तंत्रज्ञान - १५०+ टन एकरी फॉर्म्युला',
    specialtyEn: 'Sugarcane Specialist',
    locationMr: 'इंदापूर - बारामती पट्टा',
    experience: '१६ वर्षे अनुभव (VSI गोल्ड मेडलिस्ट)',
    phone: '9158674204',
    rating: 4.9,
    isAvailable: true,
    avatar: '🎋'
  },
  {
    id: 'dr_sneha_jadhav',
    name: 'डॉ. स्नेहा जाधव (PhD)',
    degree: 'PhD (Soil Science) पुणे विद्यापीठ',
    specialtyMr: 'माती परीक्षण, सेंद्रिय कर्ब व जिवाणू संवर्धन',
    specialtyEn: 'Soil & Carbon Specialist',
    locationMr: 'पुणे / सातारा',
    experience: '१० वर्षे अनुभव',
    phone: '9764512305',
    rating: 4.8,
    isAvailable: true,
    avatar: '🌱'
  },
  {
    id: 'dr_vikram_shinde',
    name: 'डॉ. विक्रम शिंदे (MBA Agri)',
    degree: 'MBA (Agri Export) APEDA Certified',
    specialtyMr: 'थेट दुबई-इराण शेतमाल निर्यात व कंटेनर पॅकिंग',
    specialtyEn: 'Agri Export Trade Expert',
    locationMr: 'सांगली - मिरज बेल्ट',
    experience: '१४ वर्षे अनुभव (५००+ कंटेनर निर्यात)',
    phone: '9371289406',
    rating: 4.92,
    isAvailable: true,
    avatar: '✈️'
  }
];

export const SUGARCANE_VARIETIES: SugarcaneVariety[] = [
  {
    code: 'Co-86032',
    name: 'नीरा राजा (Co-86032)',
    yieldTon: '१०६ - १३९ टन / एकर',
    sugarPercent: '१२.५% साखर उतारा',
    popularity: '८२.८५% महाराष्ट्रातील शेतकऱ्यांची पहिली पसंती',
    waterRequirement: 'मध्यम पाणी (टणक कांडी, खोडव्याला नंबर १)',
    highlightMr: 'वजनदार कांडी, दुष्काळातही तग धरणारी जात. साखर कारखान्यांकडून सर्वाधिक मागणी.',
    maturationDays: '१२ ते १४ महिने'
  },
  {
    code: 'CoM-0265',
    name: 'फुले २६५ (CoM-0265)',
    yieldTon: '१४० - १५६.३६ टन / एकर',
    sugarPercent: '१३.१% साखर उतारा (सुपर यील्ड)',
    popularity: 'भरघोस वजनासाठी पश्‍चिम महाराष्ट्रात प्रसिद्ध',
    waterRequirement: 'भरपूर पाणी व खत दिल्यास रेकॉर्डब्रेक उत्पादन',
    highlightMr: 'जाड कांडी, जलद वाढ, क्षारपड जमिनीतही उत्तम उत्पादन देणारी क्रांतिकारी जात.',
    maturationDays: '१३ ते १५ महिने'
  },
  {
    code: 'CoVSI-18121',
    name: 'नवीन २०२४ - CoVSI 18121',
    yieldTon: '१४५ - १५५ टन / एकर',
    sugarPercent: '१३.५% साखर उतारा (हाय रिकव्हरी)',
    popularity: 'VSI पुणे द्वारा विकसित २०२४ चे नवीन वाण',
    waterRequirement: 'कमी पाण्यात व ठिबकवर सर्वाधिक साखर उतारा',
    highlightMr: 'रोगास पूर्णपणे प्रतिकारक्षम, लवकर पक्व होणारे, कारखान्याकडून प्रति टन ₹१०० जादा दर मिळण्याची शक्यता.',
    maturationDays: '११ ते १२ महिने'
  }
];

export const REGION_FARMERS: RegionFarmer[] = [
  // Paschim Maharashtra
  {
    id: 'f_paschim_1',
    name: 'अनिल बबन पवार',
    taluka: 'इंदापूर',
    district: 'पुणे',
    region: 'paschim',
    cropMr: 'केळी (G9 Export)',
    acres: 6,
    phone: '9822014521',
    verified: true,
    avatar: '🌱',
    notes: 'थेट इराणला कंटेनर भरतो. १० शेतकऱ्यांना जोडले आहे.'
  },
  {
    id: 'f_paschim_2',
    name: 'सचिन दत्तात्रय जाधव',
    taluka: 'बारामती',
    district: 'पुणे',
    region: 'paschim',
    cropMr: 'ऊस (Co 86032) + मिरची',
    acres: 8,
    phone: '9421056782',
    verified: true,
    avatar: '🌾',
    notes: 'सोमेश्वर कारखान्याला प्रति एकर १२० टन वजन देतो.'
  },
  {
    id: 'f_paschim_3',
    name: 'महेश चंद्रकांत पाटील',
    taluka: 'मिरज',
    district: 'सांगली',
    region: 'paschim',
    cropMr: 'द्राक्ष (Super Sonaka)',
    acres: 5,
    phone: '9763124589',
    verified: true,
    avatar: '🍇',
    notes: 'दुबई मार्केटमध्ये थेट एक्सपोर्ट ग्रेड माल उपलब्ध.'
  },

  // Vidarbha
  {
    id: 'f_vid_1',
    name: 'गजानन रामकृष्ण ठाकरे',
    taluka: 'कारंजा',
    district: 'वाशीम',
    region: 'vidarbha',
    cropMr: 'सोयाबीन + हरभरा (BBF पद्धत)',
    acres: 12,
    phone: '9657841230',
    verified: true,
    avatar: '🌱',
    notes: 'BBF गादी वाफा पद्धतीने एकरी १८ क्विंटल सोयाबीन उत्पादन.'
  },
  {
    id: 'f_vid_2',
    name: 'विठ्ठल नागोराव देशमुख',
    taluka: 'वरुड (संत्रा पट्टा)',
    district: 'अमरावती',
    region: 'vidarbha',
    cropMr: 'नागपूरी संत्रा (Nagpur Orange)',
    acres: 7,
    phone: '9923458712',
    verified: true,
    avatar: '🍊',
    notes: 'बांगलादेश व दिल्ली थेट संत्रा सप्लाय करतो.'
  },
  {
    id: 'f_vid_3',
    name: 'संजय मारोतराव बोबडे',
    taluka: 'हिंगणघाट',
    district: 'वर्धा',
    region: 'vidarbha',
    cropMr: 'कापूस (घन लागवड हाय डेन्सिटी)',
    acres: 10,
    phone: '9158742369',
    verified: true,
    avatar: '☁️',
    notes: 'ड्रिप व एचडीपीएस पद्धतीने एकरी २५ क्विंटल कपाशी.'
  },

  // Marathwada
  {
    id: 'f_mar_1',
    name: 'बाळासाहेब लक्ष्मण माने',
    taluka: 'माजलगाव',
    district: 'बीड',
    region: 'marathwada',
    cropMr: 'ऊस (Phule 265) + रेशीम उद्योग',
    acres: 9,
    phone: '9890124578',
    verified: true,
    avatar: '🐛',
    notes: 'रेशीम कोष उत्पादनातून दर महिन्याला ₹७०,००० निव्वळ नफा.'
  },
  {
    id: 'f_mar_2',
    name: 'ज्ञानेश्वर तुकाराम सोळंके',
    taluka: 'जालना',
    district: 'जालना',
    region: 'marathwada',
    cropMr: 'मोसंबी + डाळिंब (भगवा)',
    acres: 6,
    phone: '9423157894',
    verified: true,
    avatar: '🍈',
    notes: 'ठिबकवर भगवा डाळिंब एक्सपोर्ट क्वालिटी ग्रेडिंग.'
  },
  {
    id: 'f_mar_3',
    name: 'प्रल्हाद भगवान इंगळे',
    taluka: 'औसा',
    district: 'लातूर',
    region: 'marathwada',
    cropMr: 'सोयाबीन बियाणे + तूर आंतरपीक',
    acres: 11,
    phone: '9765412890',
    verified: true,
    avatar: '🌾',
    notes: 'प्रमाणित घरगुती बियाणे बँक - १००% उगवण क्षमता.'
  },

  // Khandesh
  {
    id: 'f_khan_1',
    name: 'रोहिदास ओंकार पाटील',
    taluka: 'रावेर (केळी हब)',
    district: 'जळगाव',
    region: 'khandesh',
    cropMr: 'केळी (Grand Naine Export)',
    acres: 15,
    phone: '9823015487',
    verified: true,
    avatar: '🍌',
    notes: 'उत्तर भारतात दररोज ३ गाड्या केळी पाठवतो.'
  },
  {
    id: 'f_khan_2',
    name: 'कैलास आनंदा चौधरी',
    taluka: 'शहादा',
    district: 'नंदुरबार',
    region: 'khandesh',
    cropMr: 'पपई (Taiwn 786) + मिरची',
    acres: 8,
    phone: '9403215874',
    verified: true,
    avatar: '🍈',
    notes: 'तैवान ७८६ पपई थेट दिल्ली आजादपूर मंडीला करार.'
  },
  {
    id: 'f_khan_3',
    name: 'दिनेश विठ्ठल सोनवणे',
    taluka: 'चाळीसगाव',
    district: 'जळगाव',
    region: 'khandesh',
    cropMr: 'कांदा (लाल खरीप) + मका',
    acres: 6,
    phone: '9156897412',
    verified: true,
    avatar: '🧅',
    notes: 'चाळीसगाव कांदा चाळ साठवणूक तंत्रज्ञान expert.'
  }
];

export const MARKET_CROPS: MarketCropItem[] = [
  {
    id: 'mc_kothimbir',
    nameMr: 'कोथिंबीर व मेथी (ताजी/सेंद्रिय)',
    nameEn: 'Fresh Coriander & Fenugreek',
    emoji: '🥬',
    farmerName: 'संदीप काळे',
    location: 'नारायणगाव, पुणे',
    qty: 'रोज ५००+ जुड्या उपलब्ध',
    directPrice: 12,
    apmcPrice: 8,
    contact: '9876543210',
    tag: '⭐ थेट शेतातून ताजी'
  },
  {
    id: 'mc_palak',
    nameMr: 'पालक व शेपू (Fresh Palak)',
    nameEn: 'Fresh Spinach',
    emoji: '🥬',
    farmerName: 'रमेश जाधव',
    location: 'वाई, सातारा',
    qty: 'रोज ३०० जुड्या',
    directPrice: 10,
    apmcPrice: 6,
    contact: '9123456780',
    tag: '✨ हिरवीगार व ताजी'
  },

  {
    id: 'mc_wheat',
    nameMr: 'गहू (लोकवन / सिहोर)',
    nameEn: 'Wheat (Lokwan)',
    emoji: '🌾',
    farmerName: 'ज्ञानेश्वर कदम',
    location: 'शिरूर, पुणे',
    qty: '२० क्विंटल उपलब्ध',
    directPrice: 3200,
    apmcPrice: 2800,
    contact: '9856321470',
    tag: '⭐ स्वच्छ गहू'
  },
  {
    id: 'mc_rice',
    nameMr: 'इंद्रायणी तांदूळ (प्रीमियम)',
    nameEn: 'Indrayani Rice',
    emoji: '🌾',
    farmerName: 'सुनील पवार',
    location: 'भोर, पुणे',
    qty: '१० क्विंटल उपलब्ध',
    directPrice: 6500,
    apmcPrice: 5500,
    contact: '9965412380',
    tag: '✨ सुगंधी'
  },
  {
    id: 'mc_jowar',
    nameMr: 'शाळू / मालदांडी ज्वारी',
    nameEn: 'Maldandi Jowar',
    emoji: '🌾',
    farmerName: 'बाळासाहेब सोळुंके',
    location: 'मोहोळ, सोलापूर',
    qty: '१५ क्विंटल उपलब्ध',
    directPrice: 5000,
    apmcPrice: 4200,
    contact: '9012345678',
    tag: '🔥 उत्तम प्रत'
  },
  {
    id: 'mc_maize',
    nameMr: 'मका (पिवळा - पोल्ट्री ग्रेड)',
    nameEn: 'Maize (Yellow Corn)',
    emoji: '🌽',
    farmerName: 'कैलास चौधरी',
    location: 'सिल्लोड, छ. संभाजीनगर',
    qty: '५० क्विंटल',
    directPrice: 2100,
    apmcPrice: 1900,
    contact: '9123456789',
    tag: '⭐ सुकलेला मका'
  },

  {
    id: 'mc_1',
    nameMr: 'G9 निर्यातक्षम केळी (Export Quality)',
    nameEn: 'G9 Export Banana',
    emoji: '🍌',
    farmerName: 'अनिल पवार (इंदापूर)',
    location: 'इंदापूर, पुणे',
    qty: '२ टन उपलब्ध (Ready Lot)',
    directPrice: 22,
    apmcPrice: 15,
    contact: '9822014521',
    tag: '⭐ थेट शेतातून'
  },
  {
    id: 'mc_2',
    nameMr: 'नाशिक सुपर सोनाका द्राक्षे',
    nameEn: 'Nashik Export Grapes',
    emoji: '🍇',
    farmerName: 'सचिन जाधव (नाशिक)',
    location: 'पिंपळगाव, नाशिक',
    qty: '५ टन (शुगर १८+ Brix)',
    directPrice: 48,
    apmcPrice: 30,
    contact: '9421056782',
    tag: '🔥 दुबई ग्रेड'
  },
  {
    id: 'mc_3',
    nameMr: 'बारामती सरदार पेरू (L-49 Guava)',
    nameEn: 'Baramati Sweet Guava',
    emoji: '🍐',
    farmerName: 'दत्तात्रय सावंत (बारामती)',
    location: 'माळेगाव, बारामती',
    qty: '१.५ टन (सफेद गोड)',
    directPrice: 38,
    apmcPrice: 24,
    contact: '9763124589',
    tag: '✨ क्रिस्पी गोड'
  },
  {
    id: 'mc_4',
    nameMr: 'नाशिक उन्हाळ गावरान कांदा',
    nameEn: 'Nashik Red Onion',
    emoji: '🧅',
    farmerName: 'भाऊसाहेब पाटील (चांदवड)',
    location: 'चांदवड, नाशिक',
    qty: '१० टन (चाळीतील सुका)',
    directPrice: 28,
    apmcPrice: 19,
    contact: '9890124578',
    tag: '🧅 ५ महिने टिकणारा'
  },
  {
    id: 'mc_5',
    nameMr: 'सांगली हळद (सेलम राजा)',
    nameEn: 'Sangli Pure Turmeric',
    emoji: '🌿',
    farmerName: 'विजय शिंदे (मिरज)',
    location: 'मिरज, सांगली',
    qty: '३ टन पॉलिश हळद',
    directPrice: 140,
    apmcPrice: 110,
    contact: '9371289406',
    tag: '💛 ५% कुरकुमीन'
  }
];

export const EXPORT_BHAV_TABLE = [
  { market: 'लोकल आडत (Local APMC)', price: 15, totalOn10Ton: '१.५ लाख', multiplier: '१x', color: 'bg-slate-100 text-slate-800' },
  { market: 'पुणे गुलटेकडी (Pune Market)', price: 18, totalOn10Ton: '१.८ लाख', multiplier: '१.२x', color: 'bg-emerald-50 text-emerald-800' },
  { market: 'मुंबई वाशी (Mumbai Vashi)', price: 22, totalOn10Ton: '२.२ लाख', multiplier: '१.४x', color: 'bg-teal-50 text-teal-800' },
  { market: 'दिल्ली आझादपूर (Delhi Azadpur)', price: 30, totalOn10Ton: '३.० लाख', multiplier: '२x', color: 'bg-blue-50 text-blue-800' },
  { market: 'दुबई मार्केट (Dubai Export)', price: 85, totalOn10Ton: '८.५ लाख', multiplier: '५x नफा', color: 'bg-indigo-600 text-white font-bold' },
  { market: 'इराण थेट निर्यात (Iran Direct)', price: 125, totalOn10Ton: '१२.५ लाख', multiplier: '७x जॅकपॉट ⭐', color: 'bg-amber-400 text-slate-950 font-black border-2 border-red-500 gold-pulse' }
];

export const SUGAR_KARKHANE: SugarKarkhana[] = [
  {
    id: 'malegaon',
    nameMr: 'माळेगाव सहकारी साखर कारखाना, बारामती',
    location: 'बारामती, पुणे',
    ratePerTon: 3100,
    paymentDays: 10,
    frpBonus: 350,
    rating: '⭐⭐⭐⭐⭐ (सर्वोत्कृष्ट)',
    isBest: true
  },
  {
    id: 'rajarambapu',
    nameMr: 'राजारामबापू पाटील साखर कारखाना, सांगली',
    location: 'इस्लामपूर, सांगली',
    ratePerTon: 3150,
    paymentDays: 7,
    frpBonus: 400,
    rating: '⭐⭐⭐⭐⭐ (सर्वात वेगवान पेमेंट)',
    isBest: true
  },
  {
    id: 'someshwar',
    nameMr: 'सोमेश्वर सहकारी साखर कारखाना, सोमेश्वरनगर',
    location: 'सोमेश्वरनगर, बारामती',
    ratePerTon: 3050,
    paymentDays: 15,
    frpBonus: 300,
    rating: '⭐⭐⭐⭐⭐ (पारदर्शक वजन)'
  },
  {
    id: 'shahu',
    nameMr: 'छत्रपती शाहू सहकारी साखर कारखाना, कागल',
    location: 'कागल, कोल्हापूर',
    ratePerTon: 3080,
    paymentDays: 12,
    frpBonus: 320,
    rating: '⭐⭐⭐⭐½ (उच्च साखर उतारा)'
  },
  {
    id: 'chhatrapati_indapur',
    nameMr: 'छत्रपती सहकारी साखर कारखाना, भवानीनगर',
    location: 'इंदापूर, पुणे',
    ratePerTon: 2950,
    paymentDays: 14,
    frpBonus: 250,
    rating: '⭐⭐⭐⭐ (नियमित गाळप)'
  }
];

export const FRUIT_PROCESSING_KARKHANE: ProcessingKarkhana[] = [
  {
    id: 'baramati_agro',
    name: 'बारामती अ‍ॅग्रो फूड्स (Baramati Agro Foods)',
    location: 'पिंपळी, बारामती',
    specialty: 'केळी, आंबा व डाळिंब थेट दुबई/इराण निर्यात',
    paymentTerms: '७०% अ‍ॅडव्हान्स + १० दिवसांत संपूर्ण बिल',
    phone: '02112-245100',
    cert: 'APEDA & GlobalGAP Certified'
  },
  {
    id: 'indapur_banana_cluster',
    name: 'इंदापूर बनाना क्लस्टर फार्मर प्रोड्युसर कंपनी (FPO)',
    location: 'इंदापूर, पुणे-सोलापूर हायवे',
    specialty: 'इराणसाठी दररोज ५ कंटेनर जी-९ केळी पॅकिंग',
    paymentTerms: 'थेट शेतात वजन, ७ दिवसांत NEFT ट्रान्सफर',
    phone: '9822098450',
    cert: 'Govt Approved Export Hub'
  },
  {
    id: 'desai_fruits',
    name: 'देसाई फ्रूट्स अँड व्हेजिटेबल्स (Desai Fruits)',
    location: 'इंदापूर - दौंड बेल्ट',
    specialty: 'इराण स्पेशल बनाना व पेरू कॉन्ट्रॅक्ट फार्मिंग',
    paymentTerms: '७ दिवसांत बँक खात्यात थेट पेमेंट',
    phone: '9922458712',
    cert: 'ISO 22000 & APEDA'
  },
  {
    id: 'akash_agro',
    name: 'आकाश अ‍ॅग्रो एक्सपोर्ट्स (Akash Agro)',
    location: 'माळेगाव एमआयडीसी, बारामती',
    specialty: 'सरदार पेरू (L-49), जांभूळ व सीताफळ पल्प व निर्यात',
    paymentTerms: '५ दिवसांत RTGS / रोख स्लिप',
    phone: '02112-289450',
    cert: 'FSSAI + APEDA Standard'
  },
  {
    id: 'sahyadri_farms',
    name: 'सह्याद्री फार्म्स पोस्ट हार्वेस्ट केअर लि. (Sahyadri Farms)',
    location: 'मोहाडी, दिंडोरी रोड, नाशिक',
    specialty: 'द्राक्षे, टोमॅटो प्युरी, मोसंबी व युरोप एक्सपोर्ट',
    paymentTerms: 'शेतकरी भागीदार मॉडेल - १० दिवसांत पेमेंट',
    phone: '0253-2405000',
    cert: 'India’s Largest Farmer Enterprise'
  }
];

export const SARKARI_YOJANA_LIST: SarkariYojana[] = [

  {
    id: 'pacs_pik_karj',
    nameMr: 'प्राथमिक कृषी पतसंस्था (PACS) पीक कर्ज',
    nameEn: 'PACS Crop Loan (Zero Percent Interest)',
    benefitMr: '₹३ लाख पर्यंत पीक कर्ज (वेळेवर परतफेड केल्यास ०% व्याज)',
    categoryMr: 'पतसंस्था पीक कर्ज',
    subsidyTag: '०% व्याज कर्ज',
    descriptionMr: 'गावातील विविध कार्यकारी सेवा सहकारी संस्था (V.K.S.S.) / पतसंस्था यांच्यामार्फत शेतकऱ्यांना खरीप व रब्बी हंगामासाठी पीक कर्ज दिले जाते. डॉ. पंजाबराव देशमुख व्याज सवलत योजनेअंतर्गत नियमित परतफेड करणाऱ्यांना ३ लाखांपर्यंत ०% व्याजाने कर्ज मिळते.',
    eligibilityMr: ['गावातील सोसायटीचे (पतसंस्थेचे) क्रियाशील सभासद असणे आवश्यक.', 'स्वतःच्या नावावर शेतजमीन (७/१२) असावी.', 'मागील कर्जाची थकबाकी नसावी.'],
    documentsMr: ['७/१२ आणि ८-अ उतारा', 'आधार कार्ड व पॅन कार्ड', 'दोन जामीनदार', 'पीक पेरा नोंद'],
    applyLink: 'https://sahakarayukta.maharashtra.gov.in/',
    videoMinutes: '५ मिनिट'
  },
  {
    id: 'bank_agri_term_loan',
    nameMr: 'राष्ट्रीयकृत / जिल्हा मध्यवर्ती बँक शेती विकास कर्ज',
    nameEn: 'Bank Agri Term Loan (Tractor, Drip, Well)',
    benefitMr: 'ट्रॅक्टर, विहीर व शेती विकासासाठी दीर्घ मुदतीचे कर्ज',
    categoryMr: 'बँक शेती कर्ज',
    subsidyTag: 'दीर्घ मुदत कर्ज',
    descriptionMr: 'शेतकऱ्यांना शेतीची अवजारे (ट्रॅक्टर, रोटावेटर), सिंचन सुविधा (विहीर, पाईपलाईन, शेततळे) आणि जोडधंद्यासाठी राष्ट्रीयकृत बँका (उदा. SBI, BOI) आणि जिल्हा मध्यवर्ती सहकारी बँका (DCCB) ५ ते ७ वर्षांसाठी दीर्घ मुदतीचे कर्ज देतात.',
    eligibilityMr: ['शेतजमीन धारक शेतकरी', 'चांगला सिबिल स्कोअर (CIBIL) किंवा मागील कर्ज परतफेड इतिहास चांगला असावा.', 'प्रकल्पासाठी आवश्यक तांत्रिक व आर्थिक क्षमता असावी.'],
    documentsMr: ['७/१२, ८-अ, फेरफार उतारा', 'आधार कार्ड, पॅन कार्ड', 'खरेदी करायच्या वस्तूचे/ट्रॅक्टरचे कोटेशन (Quotation)', 'वकिलांचा सर्च रिपोर्ट'],
    applyLink: 'https://sbi.co.in/web/agri-rural/agriculture-banking/crop-loan',
    videoMinutes: '६ मिनिट'
  },


  {
    id: 'loan_waiver_mjpsky',
    nameMr: '१. महात्मा जोतीराव फुले शेतकरी कर्जमुक्ती योजना',
    nameEn: 'Mahatma Jyotirao Phule Farmer Loan Waiver',
    benefitMr: '₹२ लाख पर्यंतचे थकीत पीक कर्ज १००% माफ',
    categoryMr: 'शेतकरी कर्जमाफी',
    subsidyTag: '१००% कर्जमाफी',
    descriptionMr: 'शेतकऱ्यांचे २ लाख रुपयांपर्यंतचे थकीत पीक कर्ज माफ करण्यासाठी ही योजना शासनाने लागू केली आहे. नैसर्गिक आपत्ती व नापिकीमुळे कर्जबाजारी झालेल्या शेतकऱ्यांना दिलासा देण्यासाठी ही कर्जमाफी दिली जात आहे.',
    eligibilityMr: ['ज्या शेतकऱ्यांकडे २ लाख रुपयांपर्यंतचे थकीत पीक कर्ज आहे.', 'राष्ट्रीयकृत, जिल्हा मध्यवर्ती किंवा विकास कार्यकारी सेवा सहकारी संस्था (पतसंस्था) मधील कर्ज.'],
    documentsMr: ['आधार कार्ड बँक खात्याशी लिंक असणे', 'कर्ज खात्याचे विवरण', 'ई-केवायसी (eKYC) बायोमेट्रिक प्रमाणीकरण'],
    applyLink: 'https://mjpsky.maharashtra.gov.in',
    videoMinutes: '५ मिनिट'
  },
  {
    id: 'pacs_incentive',
    nameMr: '२. शेतकरी पतसंस्था (PACS) - ५० हजार रुपये प्रोत्साहनपर अनुदान योजना',
    nameEn: 'PACS Regular Loan Repayment Incentive Scheme',
    benefitMr: 'नियमित कर्ज परतफेड करणाऱ्यांना ५० हजार रुपये प्रोत्साहन अनुदान',
    categoryMr: 'पतसंस्था व प्रोत्साहनपर लाभ',
    subsidyTag: '₹५०,००० अनुदान',
    descriptionMr: 'ज्या शेतकऱ्यांनी प्राथमिक कृषी पतपुरवठा सहकारी संस्था (पतसंस्था) किंवा बँकांकडून घेतलेल्या पीक कर्जाची सलग ३ वर्षे नियमित परतफेड केली आहे, त्यांना प्रोत्साहन म्हणून ५० हजार रुपयांचे अनुदान थेट बँक खात्यात दिले जाते.',
    eligibilityMr: ['मागील ३ वर्षांत २ वर्षे तरी पीक कर्जाची नियमित परतफेड केलेली असावी.', 'शेतकरी विविध कार्यकारी सेवा सहकारी संस्था (PACS) किंवा बँकेचा सभासद असावा.'],
    documentsMr: ['आधार कार्ड', '७/१२ आणि ८-अ उतारा', 'पतसंस्था/बँकेचे बेबाकी (No Dues) प्रमाणपत्र / कर्ज परतफेड पावती'],
    applyLink: 'https://mjpsky.maharashtra.gov.in',
    videoMinutes: '४ मिनिट'
  },

  {
    id: 'pm_kisan',
    nameMr: '३. पीएम किसान सन्मान निधी योजना (PM Kisan)',
    nameEn: 'PM Kisan Samman Nidhi',
    benefitMr: '₹६,००० / वर्ष (दर ४ महिन्यांनी ₹२,००० थेट बँक खात्यात)',
    categoryMr: 'थेट आर्थिक साहाय्य',
    subsidyTag: '१००% मोफत थेट मदत',
    descriptionMr: 'शेतकऱ्यांना शेतीसाठी लागणाऱ्या बी-बियाणे, खते खरेदीसाठी केंद्र सरकारकडून दरवर्षी ६ हजार रुपये ३ समान हप्त्यांमध्ये मिळतात. ई-केवायसी (eKYC) व आधार लिंक असणे अनिवार्य आहे.',
    eligibilityMr: ['स्वतःच्या नावावर शेती असणारे सर्व शेतकरी', 'आधार कार्ड बँक खात्याशी लिंक असणे गरजेचे', 'ई-केवायसी (eKYC) पूर्ण असणे आवश्यक'],
    documentsMr: ['७/१२ आणि ८-अ उतारा', 'आधार कार्ड व पॅन कार्ड', 'बँक पासबुक झेरॉक्स'],
    applyLink: 'https://pmkisan.gov.in',
    videoMinutes: '४ मिनिट'
  },
  {
    id: 'mahadbt_drip',
    nameMr: '४. महाडीबीटी ठिबक व तुषार सिंचन अनुदान (MahaDBT Drip)',
    nameEn: 'MahaDBT Micro Irrigation Subsidy',
    benefitMr: '८०% पर्यंत थेट सरकारी अनुदान (Drip / Sprinkler)',
    categoryMr: 'सिंचन व पाणी बचत',
    subsidyTag: '८०% सबसिडी',
    descriptionMr: 'अल्प व अत्यल्प भूधारक शेतकऱ्यांना ठिबक सिंचनासाठी ८०% तर इतर शेतकऱ्यांना ७५% अनुदान थेट खात्यात दिले जाते. ऊस, केळी, द्राक्षे, भाजीपाला यासाठी ५०% पाण्याची बचत होते.',
    eligibilityMr: ['महाराष्ट्रातील शेतजमीन धारक शेतकरी', 'पाण्याचा शाश्वत स्त्रोत (विहीर, कूपनलिका किंवा शेततळे) असणे गरजेचे', 'महाडीबीटी पोर्टलवर ऑनलाईन नोंदणी'],
    documentsMr: ['७/१२, ८-अ उतारा', 'विहीर/बोअरवेल पाणी दाखला', 'ठिबक कंपनीचे अधिकृत कोटेशन', 'आधार कार्ड व बँक पासबुक'],
    applyLink: 'https://mahadbt.maharashtra.gov.in',
    videoMinutes: '६ मिनिट'
  },
  {
    id: 'pik_vima',
    nameMr: '५. १ रुपयात पीक विमा योजना (Pradhan Mantri Fasal Bima)',
    nameEn: '1 Rupee Crop Insurance Scheme',
    benefitMr: 'फक्त ₹१ रुपयात पिकाला नैसर्गिक आपत्तीपासून १००% सुरक्षा कवच',
    categoryMr: 'नैसर्गिक आपत्ती संरक्षण',
    subsidyTag: 'फक्त ₹१ विमा',
    descriptionMr: 'महाराष्ट्र शासनाने शेतकऱ्यांसाठी अवघ्या १ रुपयात पीक विमा योजना लागू केली आहे. दुष्काळ, अतिवृष्टी, गारपीट, कीड-रोग यामुळे नुकसान झाल्यास थेट भरपाई मिळते.',
    eligibilityMr: ['खरीप व रब्बी पिके घेणारे सर्व शेतकरी', 'अधिसूचित महसूल मंडळात पीक पेरा नोंदवलेला असावा'],
    documentsMr: ['ई-पीक पाहणी नोंद असलेला ७/१२', 'आधार कार्ड', 'बँक पासबुक झेरॉक्स', 'स्वयंघोषणापत्र'],
    applyLink: 'https://pmfby.gov.in',
    videoMinutes: '५ मिनिट'
  },
  {
    id: 'kcc_loan',
    nameMr: '६. किसान क्रेडिट कार्ड योजना - KCC (Kisan Credit Card)',
    nameEn: 'Kisan Credit Card at 4% Interest',
    benefitMr: '₹३ लाख पर्यंत बिनव्याजी / केवळ ४% दराने अल्पमुदत पीक कर्ज',
    categoryMr: 'कमी व्याजदर कर्ज',
    subsidyTag: '३ लाख @ ४% व्याज',
    descriptionMr: 'वेळेवर परतफेड केल्यास केंद्र व राज्य शासनाकडून ३% + ३% व्याज सवलत मिळून ₹३ लाखांपर्यंतचे पीक कर्ज पूर्णपणे बिनव्याजी (०% ते ४%) मिळते. कोणत्याही खाजगी सावकाराकडे जाण्याची गरज नाही.',
    eligibilityMr: ['शेती असणारे सर्व शेतकरी, कुक्कुटपालन व दुग्ध उत्पादक', 'क्रेडिट स्कोअर चांगला असणे आवश्यक'],
    documentsMr: ['७/१२ व ८-अ दाखला', 'फेरफार उतारा', 'आधार कार्ड, पॅन कार्ड व २ फोटो', 'राष्ट्रीयकृत किंवा जिल्हा मध्यवर्ती बँकेत अर्ज'],
    applyLink: 'https://www.myscheme.gov.in/schemes/kcc',
    videoMinutes: '४ मिनिट'
  },
  {
    id: 'apeda_export_subsidy',
    nameMr: '७. अपेडा (APEDA) शेतमाल निर्यात वाहतूक अनुदान',
    nameEn: 'APEDA Export Freight Subsidy (Iran & Dubai)',
    benefitMr: 'इराण / दुबई कंटेनर वाहतुकीसाठी ५०% मालवाहतूक अनुदान',
    categoryMr: 'शेतमाल निर्यात प्रोत्साहन',
    subsidyTag: '५०% मालवाहतूक सबसिडी',
    descriptionMr: 'महाराष्ट्र राज्य कृषी पणन मंडळ व APEDA कडून थेट आखाती देशांमध्ये फळे-भाजीपाला विमानाने किंवा समुद्राने निर्यात करणाऱ्या शेतकऱ्यांना व शेतकरी उत्पादक कंपन्यांना (FPO) ५०% भाडे अनुदान मिळते.',
    eligibilityMr: ['केळी, द्राक्षे, आंबा, डाळिंब व भाजीपाला उत्पादक शेतकरी किंवा FPO', 'APEDA RCMC नोंदणी असणे आवश्यक'],
    documentsMr: ['शेतकरी गट / FPO नोंदणी प्रमाणपत्र', 'निर्यात बिल व शिपिंग बिल (Shipping Bill)', 'पॅकिंग हाऊस तपासणी प्रमाणपत्र', 'बँक खात्याचा पुरावा'],
    applyLink: 'https://apeda.gov.in',
    videoMinutes: '७ मिनिट'
  }
];

export const JOD_DHANDA_LIST: JodDhandaItem[] = [
  {
    id: 'dairy',
    titleMr: '१. दुग्ध व्यवसाय (Dudh Dairy)',
    titleEn: 'Dairy Farming',
    iconEmoji: '🐄',
    monthlyIncome: 'नफा: ₹३०,००० / महिना',
    setupCost: 'खर्च: १ गाय ₹८०,००० (८०% अनुदान)',
    loanScheme: 'नाबार्ड डेअरी योजना (NABARD)',
    subsidyPercent: '८०% सबसिडी',
    stepsMr: [
      'उत्पादन: १५ लिटर/दिवस x ३५ रुपये = ₹१५,७५०/महिना (१ गाईचे).',
      '२० ते २५ लिटर देणाऱ्या HF किंवा गीर गाईंची निवड करा.',
      'हिरवा चारा, सायलेज आणि योग्य गोठ्यामुळे दुधाच्या फॅटमध्ये वाढ होते.',
      'नाबार्ड योजनेअंतर्गत ८०% सबसिडी मिळवून गोठा बांधा.'
    ],
    marketTips: 'थेट सोसायट्यांमध्ये किंवा डेअरीमध्ये A2 दूध विका.'
  },
  {
    id: 'poultry',
    titleMr: '२. कुक्कुटपालन (Kombadi Palan)',
    titleEn: 'Poultry Farming',
    iconEmoji: '🐓',
    monthlyIncome: 'नफा: ₹२५,००० / महिना',
    setupCost: 'खर्च: १०० कोंबड्या ₹२५,०००',
    loanScheme: 'मुद्रा कर्ज (Mudra Yojana)',
    subsidyPercent: 'विनातारण कर्ज',
    stepsMr: [
      'उत्पादन: ८० अंडी/दिवस x ८ रुपये = ₹१९,२००/महिना.',
      'गावरान, कावेरी किंवा ग्रामप्रिया जातीच्या कोंबड्या पाळा.',
      'मांस आणि अंडी या दोन्ही बाजूंनी उत्पन्न मिळते.',
      'मुद्रा योजनेअंतर्गत ५० हजारांपर्यंत विनातारण शिशु कर्ज मिळवा.'
    ],
    marketTips: 'गावातील आठवडे बाजार आणि नॉनव्हेज हॉटेल्सना थेट अंडी व चिकन सप्लाय.'
  },
  {
    id: 'goat_farming',
    titleMr: '३. शेळीपालन (Sheli Palan)',
    titleEn: 'Goat Farming',
    iconEmoji: '🐐',
    monthlyIncome: 'नफा: ₹३५,००० / महिना',
    setupCost: 'खर्च: १० शेळ्या ₹६०,०००',
    loanScheme: 'नाबार्ड / अहिल्यादेवी महामंडळ',
    subsidyPercent: '५०% अनुदान',
    stepsMr: [
      'उत्पादन: २ करडू x ८,००० = ₹१६,००० + खत ₹५,००० (वर्षाकाठी मोठी कमाई).',
      'उस्मानाबादी, बोअर किंवा सिरोही शेळ्यांची निवड.',
      'बंदिस्त शेळीपालनामुळे चारा कमी लागतो आणि वजन लवकर वाढते.',
      'अहिल्यादेवी महामंडळामार्फत ५०% अनुदानासाठी अर्ज करा.'
    ],
    marketTips: 'बोकडांची ईदला व सणासुदीला विक्री करून दुप्पट नफा कमवा.'
  },
  {
    id: 'beekeeping',
    titleMr: '४. मधमाशी पालन (Madhmashi Palan)',
    titleEn: 'Beekeeping',
    iconEmoji: '🍯',
    monthlyIncome: 'नफा: ₹२५,००० / महिना',
    setupCost: 'खर्च: १० पेट्या ₹४०,०००',
    loanScheme: 'KVIC हनी मिशन योजना',
    subsidyPercent: '८०% अनुदान',
    stepsMr: [
      'उत्पादन: ३० किलो मध x ८०० रुपये = ₹२४,०००/हंगाम.',
      'मधमाश्यांमुळे पिकांचे परागीभवन होऊन शेतातील उत्पादनही ४०% वाढते.',
      'पेट्या सूर्यफूल, मोहरी किंवा फळबागेत ठेवा.',
      'KVIC मधून ८०% अनुदानावर पेट्या मिळवा.'
    ],
    marketTips: 'सेंद्रिय मध, बी-वॅक्स आणि रॉयल जेली या उत्पादनांना बाजारात प्रचंड मागणी.'
  },
  {
    id: 'mushroom',
    titleMr: '५. अळंबी शेती (Mushroom Farming)',
    titleEn: 'Mushroom Farming',
    iconEmoji: '🍄',
    monthlyIncome: 'नफा: ₹२०,००० / महिना',
    setupCost: 'खर्च: १०x१० खोली ₹३०,०००',
    loanScheme: 'राष्ट्रीय फलोत्पादन अभियान (NHM)',
    subsidyPercent: '५०% अनुदान',
    stepsMr: [
      'उत्पादन: ५० किलो/महिना x २०० रुपये = ₹१०,०००.',
      'गव्हाच्या किंवा भाताच्या काडाचा (भुसा) उपयोग करून ऑयस्टर अळंबी पिकवा.',
      'फक्त २२-२५ दिवसांत पीक तयार होते व कमी जागेत भरपूर नफा मिळतो.',
      'NHM मधून ५०% अनुदानाचा लाभ घ्या.'
    ],
    marketTips: 'हॉटेल्स, चायनीज सेंटर्स आणि आयुर्वेदिक औषध कंपन्यांना सुके व ओले मशरूम विका.'
  },
  {
    id: 'biofloc_fish',
    titleMr: '६. मत्स्यपालन (Biofloc Fish Farming)',
    titleEn: 'Biofloc Fish Farming',
    iconEmoji: '🐟',
    monthlyIncome: 'नफा: ₹४०,००० / महिना',
    setupCost: 'खर्च: १ टँक ₹५०,०००',
    loanScheme: 'PM मत्स्य संपदा योजना (PMMSY)',
    subsidyPercent: '४०% ते ६०% अनुदान',
    stepsMr: [
      'उत्पादन: ५०० किलो x १५० रुपये = ₹७५,००० (प्रति टँक).',
      'बायोफ्लॉक तंत्रज्ञानाने कमी पाण्यात व कमी जागेत जास्त मासे मिळतात.',
      'रोहू, कटला किंवा तिलापिया माशांची पैदास करा.',
      'पंतप्रधान मत्स्य संपदा योजनेतून ६०% पर्यंत अनुदान मिळवा.'
    ],
    marketTips: 'शहरातील मासळी बाजार आणि मोठ्या रेस्टॉरंट्सशी करार करा.'
  },
  {
    id: 'vermicompost',
    titleMr: '७. गांडूळ खत प्रकल्प (Vermicompost)',
    titleEn: 'Vermicomposting',
    iconEmoji: '🪱',
    monthlyIncome: 'नफा: ₹१५,००० / महिना',
    setupCost: 'खर्च: ४ बेड ₹२०,०००',
    loanScheme: 'कृषी विभाग सेंद्रिय शेती योजना',
    subsidyPercent: '१००% मोफत किट',
    stepsMr: [
      'उत्पादन: २ टन खत x १० रुपये किलो = ₹२०,०००.',
      'शेतातील काडीकचरा आणि शेणापासून उच्च दर्जाचे सेंद्रिय खत.',
      'खतासोबतच गांडूळ कल्चर (बीज) विकूनही पैसे मिळवा.',
      'कृषी विभागाकडून गांडूळ बेड व बीज अनुदानावर मिळवा.'
    ],
    marketTips: 'नर्सरी, गार्डन्स आणि सेंद्रिय शेती करणाऱ्या शेतकऱ्यांना थेट विक्री करा.'
  },
  {
    id: 'sericulture',
    titleMr: '८. रेशीम उद्योग (Reshim Udyog)',
    titleEn: 'Sericulture',
    iconEmoji: '🐛',
    monthlyIncome: 'नफा: ₹४०,००० / महिना',
    setupCost: 'खर्च: १ एकर तुती ₹५०,०००',
    loanScheme: 'मनरेगा रेशीम योजना (MNREGA)',
    subsidyPercent: '₹३ लाख पर्यंत अनुदान',
    stepsMr: [
      'उत्पादन: १०० किलो कोष x ४०० रुपये = ₹४०,००० प्रति बॅच.',
      '१ एकर तुती लागवडीतून वर्षाला ४ ते ५ बॅचेस काढता येतात.',
      'रेशीम कीटक पालनासाठी शासनाकडून मोफत प्रशिक्षण आणि मार्गदर्शन.',
      'मनरेगा योजनेतून शेड व मजुरीसाठी ३ लाखांपर्यंत अनुदान.'
    ],
    marketTips: 'रामणगर (कर्नाटक) किंवा जालना येथील बाजारपेठेत कोषाला सर्वाधिक भाव मिळतो.'
  }
];

export const AGRI_VIDEO_LESSONS: AgriVideoLesson[] = [
  {
    id: 'v_drip_tech',
    titleMr: 'ठिबक सिंचन कसे लावावे? २ लाख पाण्याची व खतांची बचत',
    titleEn: 'How to Install Drip Irrigation & Save 2 Lakhs',
    duration: '५ मिनिट',
    views: '१.२ लाख शेतकरी',
    savingsBenefit: 'पाणी ५०% बचत + खते ३०% बचत',
    category: 'सिंचन तंत्रज्ञान',
    summaryMr: 'ठिबक सिंचनाचे व्हेंचुरी, फिल्टर क्लिनिंग आणि प्रेशर रेगुलेटर योग्य कसे वापरावे याचे सविस्तर प्रात्यक्षिक.',
    keyPoints: [
      'व्हेंचुरीद्वारे खत सोडताना पाण्याचा दाब किमान १.५ ते २.० बार असावा.',
      'दर १५ दिवसांनी आम्ल प्रक्रिया (Acid Treatment) करून ड्रिपर्समधील क्षार साफ करावेत.',
      'स्क्रीन व डिस्क फिल्टर आठवड्यातून दोनदा उलट्या प्रवाहाने (Backwash) धुवून घ्यावेत.'
    ],
    thumbnailGradient: 'from-emerald-800 to-teal-950'
  },
  {
    id: 'v_polyhouse_grapes',
    titleMr: 'पॉलिहाऊस व प्लॅस्टिक कव्हर द्राक्ष - १२ महिने अखंड उत्पादन',
    titleEn: 'Polyhouse Plastic Cover Grape Cultivation',
    duration: '८ मिनिट',
    views: '८५ हजार शेतकरी',
    savingsBenefit: 'अवकाळी पावसात १००% पीक रक्षण',
    category: 'संरक्षित शेती',
    summaryMr: 'अवकाळी पाऊस व गारपिटीपासून द्राक्षांचे रक्षण करून उच्च दर्जाचे एक्सपोर्ट बेदाणा व टेबल द्राक्ष बनवण्याचे तंत्र.',
    keyPoints: [
      '१६० मायक्रॉन यूव्ही स्टॅबिलाइज्ड प्लॅस्टिक शीटचा वापर करावा.',
      'छाटणीनंतर घड निर्मितीच्या काळात तापमान व आद्रता नियंत्रित ठेवावी.',
      'युरोपियन मानकानुसार शून्य कीडनाशक अंश (Zero MRL) ठेवणे सोपे जाते.'
    ],
    thumbnailGradient: 'from-purple-900 to-slate-900'
  },
  {
    id: 'v_drone_spraying',
    titleMr: 'आधुनिक कृषी ड्रोन फवारणी - १ एकर फक्त ४ मिनिटांत',
    titleEn: 'Modern Agriculture Drone Spraying - 1 Acre in 4 Mins',
    duration: '१० मिनिट',
    views: '२.४ लाख शेतकरी',
    savingsBenefit: '९०% पाण्याची व ७०% मजुरीची बचत',
    category: 'हायटेक शेती',
    summaryMr: 'ड्रोनद्वारे नॅनो युरिया, बुरशीनाशके व टॉनिक फवारणी कशी करावी? बॅटरी, जीपीएस मॅपिंग आणि शासकीय सबसिडी माहिती.',
    keyPoints: [
      '१ एकरासाठी फक्त १० लिटर पाणी लागते, पारंपरिक पद्धतीत २०० लिटर लागते.',
      'उंच वाढलेल्या उसात व केळीत मजुराशिवाय अचूक फवारणी शक्य.',
      'महिला बचत गट व सुशिक्षित तरुणांना ड्रोन खरेदीवर ₹४ लाख ते ₹१० लाख अनुदान.'
    ],
    thumbnailGradient: 'from-sky-900 to-blue-950'
  },
  {
    id: 'v_iran_export_packing',
    titleMr: 'इराण निर्यात केळी पॅकिंग व APEDA स्टँडर्ड नियम',
    titleEn: 'Iran Banana Export Packing & APEDA Standards',
    duration: '१० मिनिट',
    views: '१.८ लाख शेतकरी',
    savingsBenefit: 'प्रति किलो ₹१० ते ₹१५ जादा नफा',
    category: 'निर्यात मार्गदर्शन',
    summaryMr: 'केळीची घड कापणी, एलम वॉश, फंगिसाइड ट्रीटमेंट, व्हॅक्यूम पॅकिंग व १३ अंश सेल्सिअस तापमान नियंत्रित कंटेनर भरणे.',
    keyPoints: [
      'फिंगर लांबी किमान १८ ते २२ सेमी व कॅलिबर ३८ ते ४४ मिमी असावे.',
      '१३ किलो किंवा ७ किलोच्या कोरोगेटेड बॉक्समध्ये फोम पॅडिंगसह व्हॅक्यूम पॅकिंग.',
      'इराण, दुबई, सौदीला जाणारे कंटेनर २० ते २२ दिवसांचा प्रवास सुरक्षित पूर्ण करतात.'
    ],
    thumbnailGradient: 'from-amber-900 to-yellow-950'
  }
];

export const LIVE_MANDI_RATES: LiveMandiRate[] = [
  { mandi: 'पुणे (Pune)', crop: 'कोथिंबीर (Coriander)', minPrice: 15, maxPrice: 30, avgPrice: 20, trend: 'up' },
  { mandi: 'नाशिक (Nashik)', crop: 'मेथी (Fenugreek)', minPrice: 10, maxPrice: 22, avgPrice: 15, trend: 'stable' },
  { mandi: 'कल्याण (Kalyan)', crop: 'पालक (Spinach)', minPrice: 10, maxPrice: 18, avgPrice: 14, trend: 'down' },
  { mandi: 'सातारा (Satara)', crop: 'शेपू (Dill Leaves)', minPrice: 8, maxPrice: 15, avgPrice: 12, trend: 'stable' },

  { mandi: 'पुणे (Pune)', crop: 'गहू (Wheat)', minPrice: 2400, maxPrice: 3200, avgPrice: 2800, trend: 'stable' },
  { mandi: 'भंडारा (Bhandara)', crop: 'तांदूळ/भात (Rice)', minPrice: 3500, maxPrice: 5500, avgPrice: 4500, trend: 'up' },
  { mandi: 'सोलापूर (Solapur)', crop: 'ज्वारी (Jowar)', minPrice: 3200, maxPrice: 4800, avgPrice: 4000, trend: 'up' },
  { mandi: 'अहमदनगर (Ahmednagar)', crop: 'बाजरी (Bajra)', minPrice: 2000, maxPrice: 2600, avgPrice: 2300, trend: 'stable' },
  { mandi: 'छत्रपती संभाजीनगर (Chhatrapati Sambhajinagar)', crop: 'मका (Maize)', minPrice: 1800, maxPrice: 2200, avgPrice: 2000, trend: 'down' },

  { mandi: 'इंदापूर (Indapur)', crop: 'केळी G9 (Banana)', minPrice: 16, maxPrice: 24, avgPrice: 21, trend: 'up' },
  { mandi: 'बारामती (Baramati)', crop: 'ऊस (Sugarcane)', minPrice: 3000, maxPrice: 3150, avgPrice: 3080, trend: 'up' },
  { mandi: 'नाशिक (Nashik)', crop: 'कांदा (Onion)', minPrice: 18, maxPrice: 32, avgPrice: 26, trend: 'up' },
  { mandi: 'पिंपळगाव (Pimpalgaon)', crop: 'द्राक्ष (Grapes)', minPrice: 35, maxPrice: 65, avgPrice: 52, trend: 'up' },
  { mandi: 'जळगाव (Jalgaon)', crop: 'केळी (Banana Raw)', minPrice: 14, maxPrice: 22, avgPrice: 19, trend: 'stable' },
  { mandi: 'सांगली (Sangli)', crop: 'हळद (Turmeric)', minPrice: 120, maxPrice: 165, avgPrice: 145, trend: 'up' },
  { mandi: 'कोल्हापूर (Kolhapur)', crop: 'गूळ (Jaggery)', minPrice: 38, maxPrice: 52, avgPrice: 46, trend: 'stable' },
  { mandi: 'लातूर (Latur)', crop: 'सोयाबीन (Soybean)', minPrice: 42, maxPrice: 49, avgPrice: 46.5, trend: 'down' }
];

export const FARMING_EQUIPMENT_DATA: FarmingEquipment[] = [
  {
    id: 'eq_1',
    nameMr: 'महिंद्रा ५७५ DI XP Plus + रोटावेटर',
    nameEn: 'Mahindra 575 DI XP Plus + Rotavator',
    category: 'tractor',
    listingType: 'both',
    condition: 'used_good',
    specs: {
      hp: '47 HP',
      modelYear: '2023',
      brand: 'Mahindra',
      attachment: 'Shaktiman 6 Ft Rotavator + 2-MB Plough',
      capacity: 'मध्यम व खोल नांगरणी'
    },
    pricing: {
      rentPerHour: 750,
      rentPerAcre: 850,
      rentPerDay: 4200,
      sellingPrice: 580000
    },
    ownerName: 'बाळासाहेब जगताप',
    phone: '9822145890',
    village: 'काटेवाडी',
    taluka: 'बारामती',
    district: 'पुणे',
    availability: 'available_now',
    imageEmoji: '🚜',
    rating: 4.9,
    badgeMr: 'ड्रायव्हर व डिझेलसह',
    badgeEn: 'Driver & Fuel Included',
    fuelIncluded: true,
    driverIncluded: true,
    notesMr: 'ऊस व केळी रान तयार करण्यासाठी परिपूर्ण. त्वरित उपलब्धता.',
    notesEn: 'Ideal for sugarcane & banana land prep. Immediate booking.'
  },
  {
    id: 'eq_2',
    nameMr: 'डीजेआय ॲग्रास T40 कृषी फवारणी ड्रोन (४०L)',
    nameEn: 'DJI Agras T40 Agri Spraying Drone (40L)',
    category: 'drone',
    listingType: 'rent',
    condition: 'new',
    specs: {
      capacity: '40 Ltr Tank',
      brand: 'DJI Agras / IoTechWorld',
      attachment: 'नॅनो युरिया, बुरशीनाशक व टॉनिक नोझल',
      modelYear: '2024'
    },
    pricing: {
      rentPerAcre: 380,
      rentPerHour: 1200
    },
    ownerName: 'अक्षय शिंदे (प्रमाणित ड्रोन पायलट)',
    phone: '9403215897',
    village: 'पिंपळगाव बसवंत',
    taluka: 'निफाड',
    district: 'नाशिक',
    availability: 'available_now',
    imageEmoji: '🚁',
    rating: 4.95,
    badgeMr: '१ एकर फक्त ५ मिनिटांत',
    badgeEn: '1 Acre in 5 Mins',
    fuelIncluded: true,
    driverIncluded: true,
    notesMr: 'द्राक्ष, कांदा, ऊस पिकात अचूक फवारणी. ९०% पाण्याची बचत.',
    notesEn: 'Precision spray for grapes, onion and cane. 90% water saving.'
  },
  {
    id: 'eq_3',
    nameMr: 'कुबोटा मुकंद कम्बाइन हार्वेस्टर (धान/सोयाबीन/गहू)',
    nameEn: 'Kubota DC-68G Combine Harvester',
    category: 'harvester',
    listingType: 'rent',
    condition: 'used_good',
    specs: {
      hp: '68 HP Turbo',
      brand: 'Kubota / New Holland',
      attachment: 'सोयाबीन, हरभरा, धान व गहू कटर बार',
      modelYear: '2022'
    },
    pricing: {
      rentPerAcre: 1800,
      rentPerHour: 2200
    },
    ownerName: 'विठ्ठलराव देशमुख',
    phone: '9763214580',
    village: 'वरुड',
    taluka: 'वरुड',
    district: 'अमरावती',
    availability: 'available_tomorrow',
    imageEmoji: '🌾',
    rating: 4.85,
    badgeMr: 'शून्य नासाडी कापणी',
    badgeEn: 'Zero Grain Loss',
    fuelIncluded: true,
    driverIncluded: true,
    notesMr: 'ओल्या किंवा वाकलेल्या सोयाबीन व धानाची स्वच्छ मळणी व पोती भरणे.',
    notesEn: 'Clean threshing and bagging for wet/flattened soybean & paddy.'
  },
  {
    id: 'eq_4',
    nameMr: 'जॉन डिअर ५०५०D (४ व्हील ड्राईव्ह 4WD)',
    nameEn: 'John Deere 5050D (4WD Heavy Duty)',
    category: 'tractor',
    listingType: 'sell',
    condition: 'used_good',
    specs: {
      hp: '50 HP 4WD',
      modelYear: '2022',
      brand: 'John Deere',
      attachment: 'पॉवर स्टिअरिंग, ऑइल इमर्स्ड ब्रेक, ड्युअल क्लच'
    },
    pricing: {
      sellingPrice: 620000,
      rentPerDay: 3500
    },
    ownerName: 'प्रमोद गायकवाड',
    phone: '9890124567',
    village: 'राहुरी',
    taluka: 'राहुरी',
    district: 'अहिल्यानगर (अहमदनगर)',
    availability: 'available_now',
    imageEmoji: '🚜',
    rating: 4.8,
    badgeMr: 'कमी चाललेला (१२०० तास)',
    badgeEn: 'Low Run (1200 hrs)',
    notesMr: 'सर्व पेपर्स ओके, १ हात चालवलेला, बँक लोन सुविधा उपलब्ध.',
    notesEn: 'All clear documents, single hand driven, loan assistance.'
  },
  {
    id: 'eq_5',
    nameMr: 'VST शक्ती १३ HP पॉवर टिलर + ट्रेलर',
    nameEn: 'VST Shakti 130 DI Power Tiller',
    category: 'tiller',
    listingType: 'both',
    condition: 'used_good',
    specs: {
      hp: '13 HP Diesel',
      brand: 'VST Shakti',
      attachment: 'रोटरी ब्लेड्स, रिजर (सरी यंत्र), १ टन ट्रॉली',
      modelYear: '2021'
    },
    pricing: {
      rentPerHour: 450,
      rentPerDay: 2000,
      sellingPrice: 125000
    },
    ownerName: 'दत्तात्रय भोसले',
    phone: '9158742301',
    village: 'इस्लामपूर',
    taluka: 'वाळवा',
    district: 'सांगली',
    availability: 'available_now',
    imageEmoji: '⚙️',
    rating: 4.75,
    badgeMr: 'भाजीपाला व आंतरमशागत',
    badgeEn: 'Vegetables & Weeding',
    driverIncluded: false,
    notesMr: 'मिरची, हळद, आले व भाजीपाल्यात तण काढणे व माती लावण्यासाठी सर्वोत्तम.',
    notesEn: 'Best for weeding, earthing up in ginger, turmeric and vegetables.'
  },
  {
    id: 'eq_6',
    nameMr: 'शक्तिमान ६ फूट हेवी ड्युटी रोटावेटर',
    nameEn: 'Shaktiman Champion 6 Ft Rotavator',
    category: 'rotavator',
    listingType: 'sell',
    condition: 'used_good',
    specs: {
      brand: 'Shaktiman',
      attachment: '४८ एल-टाइप बोरोन स्टील ब्लेड्स',
      modelYear: '2023',
      hp: '45+ HP साठी'
    },
    pricing: {
      sellingPrice: 88000,
      rentPerAcre: 650
    },
    ownerName: 'महेश पाटील',
    phone: '9823056712',
    village: 'रावेर',
    taluka: 'रावेर',
    district: 'जळगाव',
    availability: 'available_now',
    imageEmoji: '🔩',
    rating: 4.9,
    badgeMr: 'मूळ पेंट व नवीन ब्लेड्स',
    badgeEn: 'Original Paint & New Blades',
    notesMr: 'केळीचे खोडके व उसाचे पाचट बारीक करण्यासाठी उत्तम कंडिशन.',
    notesEn: 'Excellent condition for banana stubble & cane trash shredding.'
  },
  {
    id: 'eq_7',
    nameMr: 'लेझर लँड लेव्हलर (जमीन सपाटीकरण यंत्र)',
    nameEn: 'Laser Guided Land Leveler (Smart Grade)',
    category: 'specialized',
    listingType: 'rent',
    condition: 'new',
    specs: {
      brand: 'Agrico Spectra Precision',
      attachment: 'ट्रान्समीटर, लेझर रिसीव्हर व ७ फूट बकेट',
      hp: '55+ HP ट्रॅक्टर आवश्यक'
    },
    pricing: {
      rentPerHour: 1100,
      rentPerAcre: 1400
    },
    ownerName: 'सुनील तांबडे',
    phone: '9765412893',
    village: 'करमाळा',
    taluka: 'करमाळा',
    district: 'सोलापूर',
    availability: 'available_now',
    imageEmoji: '📐',
    rating: 4.95,
    badgeMr: '३०% पाण्याची कायमस्वरूपी बचत',
    badgeEn: 'Permanent 30% Water Saving',
    fuelIncluded: true,
    driverIncluded: true,
    notesMr: 'जमीन १ इंचाच्या अचूकतेने सपाट होते. पाणी सर्वत्र सारखे पोहचते.',
    notesEn: 'Flattens farm to 1-inch precision. Even water distribution.'
  },
  {
    id: 'eq_8',
    nameMr: 'मल्चिंग पेपर व ठिबक नळी अंथरणारे यंत्र',
    nameEn: 'Mulch Laying & Drip Layer Machine',
    category: 'implements',
    listingType: 'both',
    condition: 'new',
    specs: {
      brand: 'Kisan Kranti Agro',
      attachment: '२५ ते ४० मायक्रॉन पेपर + डबल लॅटरल रोलर',
      hp: '24 ते 45 HP'
    },
    pricing: {
      rentPerAcre: 700,
      sellingPrice: 42000
    },
    ownerName: 'सागर जगताप',
    phone: '9922334455',
    village: 'मंचर',
    taluka: 'आंबेगाव',
    district: 'पुणे',
    availability: 'available_now',
    imageEmoji: '🌱',
    rating: 4.85,
    badgeMr: '१ एकर मल्चिंग १ तासात',
    badgeEn: '1 Acre Mulching in 1 Hr',
    notesMr: 'टरबूज, मिरची, टोमॅटो व कांदा लागवडीसाठी बेड तयार करून मल्चिंग अंथरणे.',
    notesEn: 'Bed formation + mulch laying for watermelon, chilli, tomato.'
  }
];

export const PROGRESSIVE_FARMERS_DATA: ProgressiveFarmerStory[] = [
  {
    id: 'pf_1',
    farmerName: 'दत्तात्रय ज्ञानदेव कदम',
    village: 'शिर्सुफळ',
    taluka: 'बारामती',
    district: 'पुणे',
    region: 'paschim',
    mainCropMr: 'ऊस (Co 86032 / CoM 0265)',
    mainCropEn: 'Sugarcane (Co 86032 & CoM 0265)',
    variety: 'Co 86032 अमृत',
    acres: 12,
    cropYieldRecordMr: 'एकरी १३२ टन विक्रमी ऊस उत्पादन',
    cropYieldRecordEn: '132 Tons/Acre Record Sugarcane Yield',
    netProfitPerAcreMr: '₹४.२ लाख निव्वळ नफा प्रति एकर',
    netProfitPerAcreEn: '₹4.2 Lakh Net Profit / Acre',
    bestFarmingTechniquesMr: [
      '५ बाय २ फूट पट्टा जोडओळ लागवड पद्धत',
      'दर १५ दिवसांनी २०० लिटर जीवामृत ठिबकमधून देणे',
      'पाचट न जाळता पाचट कुजवणारे जिवाणू वापरून मल्चिंग',
      'सूक्ष्म अन्नद्रव्ये व सिलिकॉन फर्टिगेशन'
    ],
    bestFarmingTechniquesEn: [
      '5x2 ft paired row planting method',
      '200 Ltr Jivamrut fertigation every 15 days',
      'Trash mulching with microbial decomposer (no burning)',
      'Micronutrients & soluble silicon scheduling'
    ],
    produceForSale: [
      {
        itemMr: 'प्रमाणित Co 86032 सिंगल डोळा ऊस रोपे',
        itemEn: 'Certified Co 86032 Single-Eye Cane Seedlings',
        quantityAvailable: '५०,००० रोपे उपलब्ध',
        priceRate: '₹१.८० / रोप',
        qualityGrade: 'अ दर्जा निरोगी रोपे'
      },
      {
        itemMr: 'ऊस बेणे (३ डोळा कांडे)',
        itemEn: 'Sugarcane Setts (3-eye healthy setts)',
        quantityAvailable: '२० टन उपलब्ध',
        priceRate: '₹३,४०० / टन',
        qualityGrade: '१० महिने वयाचे उत्तम बेणे'
      }
    ],
    phone: '9822456710',
    whatsapp: '9822456710',
    avatarEmoji: '🌾',
    image: 'https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=500',
    experienceYears: 18,
    awardsMr: 'महाराष्ट्र राज्य वसंतराव नाईक कृषी भूषण पुरस्कार',
    awardsEn: 'Vasantrao Naik Krishi Bhushan State Awardee',
    storyQuoteMr: 'शेतीत रासायनिक खतांचा अतिरेक थांबवून सेंद्रिय जिवाणू आणि योग्य पाणी व्यवस्थापन केले तर ऊस १०० टनाच्या पुढे सहज जातो!',
    storyQuoteEn: 'Stopping chemical overdose, feeding organic microbes and scheduling drip irrigation takes sugarcane beyond 100 Tons easily!',
    verified: true
  },
  {
    id: 'pf_2',
    farmerName: 'विलास विठ्ठल शिंदे',
    village: 'पिंपळगाव बसवंत',
    taluka: 'निफाड',
    district: 'नाशिक',
    region: 'paschim',
    mainCropMr: 'द्राक्ष (Super Sonaka & Crimson Seedless)',
    mainCropEn: 'Grapes (Super Sonaka & Crimson Seedless)',
    variety: 'सुपर सोनाका व क्रिम्सन',
    acres: 8,
    cropYieldRecordMr: 'एकरी १८ टन एक्सपोर्ट ग्रेड द्राक्षे (१००% रेसिड्यू फ्री)',
    cropYieldRecordEn: '18 Tons/Acre Export Grade Grapes (Zero MRL)',
    netProfitPerAcreMr: '₹८.५ लाख निव्वळ नफा प्रति एकर',
    netProfitPerAcreEn: '₹8.5 Lakh Net Profit / Acre',
    bestFarmingTechniquesMr: [
      'कॅनोपी मॅनेजमेंट व सूक्ष्म हवा खेळती ठेवणे',
      'दशपर्णी अर्क व जैविक ट्रायकोडर्मा द्वारे डाऊनी नियंत्रण',
      'पावसाळ्यात ६० मायक्रॉन प्लॅस्टिक कव्हर आच्छादन',
      'दुबई व नेदरलँड्स थेट कंटेनर पॅकिंग'
    ],
    bestFarmingTechniquesEn: [
      'Canopy management with optimal aeration',
      'Dashparni Ark & Trichoderma bio-control for Downy',
      'Plastic rain shelter covering during monsoons',
      'Direct container packing for Dubai & Netherlands'
    ],
    produceForSale: [
      {
        itemMr: 'एक्सपोर्ट सुपर सोनाका टेबल द्राक्षे',
        itemEn: 'Export Grade Super Sonaka Table Grapes',
        quantityAvailable: '१५ टन उपलब्ध',
        priceRate: '₹११० / किलो (थेट शेतातून)',
        qualityGrade: '१८+ मिमी मणी आकार, २४ ब्रिक्स गोडी'
      },
      {
        itemMr: 'सेंद्रिय सोनेरी बेदाणा (Golden Raisins)',
        itemEn: 'Organic Golden Raisins',
        quantityAvailable: '३ टन उपलब्ध',
        priceRate: '₹३२० / किलो',
        qualityGrade: 'सल्फर फ्री नैसर्गिक सुकवलेला'
      }
    ],
    phone: '9422789123',
    whatsapp: '9422789123',
    avatarEmoji: '🍇',
    image: 'https://images.unsplash.com/photo-1596363505729-4190a9506133?w=500',
    experienceYears: 22,
    awardsMr: 'ग्लोबल गॅप (GlobalGAP) प्रमाणित द्राक्ष बागायतदार',
    awardsEn: 'GlobalGAP Certified Grape Producer',
    storyQuoteMr: 'लोकल दलालांवर अवलंबून न राहता थेट पॅकहाऊस ग्रेडिंग केल्याने द्राक्षात प्रति किलो ₹४० जादा भाव मिळतो.',
    storyQuoteEn: 'Direct farm packhouse grading without middlemen yields Rs.40 extra per kg in international markets.',
    verified: true
  },
  {
    id: 'pf_3',
    farmerName: 'रोहिदास आनंदा पाटील',
    village: 'सावदा - रावेर',
    taluka: 'रावेर',
    district: 'जळगाव',
    region: 'khandesh',
    mainCropMr: 'केळी (Grand Naine G9 Tissue Culture)',
    mainCropEn: 'Banana (Grand Naine G9 Tissue Culture)',
    variety: 'जैन G9 टिशू कल्चर',
    acres: 15,
    cropYieldRecordMr: 'एकरी ३८ टन केळी उत्पादन (३२ ते ३६ किलो घड सरासरी)',
    cropYieldRecordEn: '38 Tons/Acre Banana (32-36 kg Bunch Average)',
    netProfitPerAcreMr: '₹५.८ लाख निव्वळ नफा प्रति एकर',
    netProfitPerAcreEn: '₹5.8 Lakh Net Profit / Acre',
    bestFarmingTechniquesMr: [
      '६ बाय ५ फूट त्रिकोणी लागवड + ठिबक फर्टिगेशन',
      'घड बाहेर पडल्यावर निळ्या पॉलिथिन कव्हरने स्कर्टिंग',
      'पोटॅश व कॅल्शियम नायट्रेटचे काटेकोर शेड्युल',
      'इराण व ओमानला थेट व्हॅक्यूम पॅकिंग कंटेनर सप्लाय'
    ],
    bestFarmingTechniquesEn: [
      '6x5 ft triangular spacing + automated fertigation',
      'Blue polythene skirting cover immediately after shooting',
      'Strict Potassium & Calcium Nitrate feeding schedule',
      'Vacuum-packed reefer containers direct to Iran & Oman'
    ],
    produceForSale: [
      {
        itemMr: 'इराण एक्सपोर्ट क्वालिटी G9 कच्ची केळी',
        itemEn: 'Iran Export Grade G9 Raw Banana',
        quantityAvailable: '४० टन उपलब्ध (२ कंटेनर)',
        priceRate: '₹२२ / किलो (शेतात कटिंग)',
        qualityGrade: '८ ते ९ फण्यांचा घड, ३९ मिमी कॅलिबर'
      },
      {
        itemMr: 'G9 दुय्यम पिलवा (Suckers / रोपे)',
        itemEn: 'Hardened G9 Banana Plants',
        quantityAvailable: '१०,००० रोपे उपलब्ध',
        priceRate: '₹१४ / रोप',
        qualityGrade: 'निरोगी व्हायरसमुक्त रोपे'
      }
    ],
    phone: '9823015499',
    whatsapp: '9823015499',
    avatarEmoji: '🍌',
    image: 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=500',
    experienceYears: 16,
    awardsMr: 'महाराष्ट्र केळी भूषण व APEDA एक्सपोर्ट सन्मान',
    awardsEn: 'Maharashtra Banana Bhushan & APEDA Exporter',
    storyQuoteMr: 'घड निघाल्यावर वेळेवर कव्हरिंग आणि अचूक पोटॅशियम व्यवस्थापन केल्यास केळीचे वजन आणि शायनिंग दुप्पट होते.',
    storyQuoteEn: 'Timely bunch skirting and potassium nutrition doubles bunch weight and skin shine for export.',
    verified: true
  },
  {
    id: 'pf_4',
    farmerName: 'गजानन रामकृष्ण ठाकरे',
    village: 'कारंजा लाड',
    taluka: 'कारंजा',
    district: 'वाशीम',
    region: 'vidarbha',
    mainCropMr: 'सोयाबीन (फुले संगम KDS-726) + हरभरा',
    mainCropEn: 'Soybean (Phule Sangam KDS-726) + Gram',
    variety: 'KDS-726 फुले संगम व दिग्विजय हरभरा',
    acres: 14,
    cropYieldRecordMr: 'एकरी २२ क्विंटल सोयाबीन उत्पादन (BBF तंत्रज्ञान)',
    cropYieldRecordEn: '22 Quintals/Acre Soybean Yield (BBF Broad Bed Method)',
    netProfitPerAcreMr: '₹१.१५ लाख निव्वळ नफा प्रति एकर',
    netProfitPerAcreEn: '₹1.15 Lakh Net Profit / Acre',
    bestFarmingTechniquesMr: [
      'बीबीएफ (BBF - Broad Bed Furrow) गादी वाफा यंत्राने पेरणी',
      'रायझोबियम व पीएसबी जैविक बीजप्रक्रिया',
      'अतिवृष्टीत पाण्याचा निचरा व दुष्काळात ओलावा संवर्धन',
      'स्वतःचे १००% उगवण क्षमतेचे प्रमाणित बियाणे तयार करणे'
    ],
    bestFarmingTechniquesEn: [
      'Broad Bed Furrow (BBF) raised bed mechanical sowing',
      'Rhizobium & PSB biological seed inoculation',
      'Excess water drainage during floods & moisture hold during drought',
      'Farm-produced 100% germination certified seeds'
    ],
    produceForSale: [
      {
        itemMr: 'फुले संगम (KDS 726) प्रमाणित ग्रेडिंग बियाणे',
        itemEn: 'Phule Sangam (KDS 726) Graded Seed',
        quantityAvailable: '८० क्विंटल उपलब्ध',
        priceRate: '₹७,२०० / क्विंटल (३० किलो बॅग)',
        qualityGrade: '९८% उगवण क्षमता, तांबेरा प्रतिकारक'
      },
      {
        itemMr: 'सेंद्रिय गावरान तूर डाळ (Unpolished Toor Dal)',
        itemEn: 'Organic Unpolished Toor Dal',
        quantityAvailable: '१२ क्विंटल उपलब्ध',
        priceRate: '₹१६५ / किलो',
        qualityGrade: 'नैसर्गिक चव, कोणतीही पॉलिश नाही'
      }
    ],
    phone: '9657841244',
    whatsapp: '9657841244',
    avatarEmoji: '🌱',
    experienceYears: 14,
    awardsMr: 'डॉ. पंजाबराव देशमुख कृषीरत्न पुरस्कार',
    awardsEn: 'Dr. Panjabrao Deshmukh Krishi Ratna',
    storyQuoteMr: 'विदर्भातील शेतकऱ्यांनी साध्या पेरणीऐवजी BBF गादीवाफा पद्धत वापरली तर दुष्काळ किंवा अतिवृष्टीतही सोयाबीनचे नुकसान होत नाही.',
    storyQuoteEn: 'Switching from flat sowing to BBF raised beds completely saves soybeans from drought and flooding in Vidarbha.',
    verified: true
  },
  {
    id: 'pf_5',
    farmerName: 'सुभाष मारुती सोळंके',
    village: 'आंबड',
    taluka: 'आंबड',
    district: 'जालना',
    region: 'marathwada',
    mainCropMr: 'डाळिंब (सुपर भगवा) व मोसंबी',
    mainCropEn: 'Pomegranate (Super Bhagwa) & Sweet Lime',
    variety: 'सुपर भगवा सिंदूरी डाळिंब',
    acres: 10,
    cropYieldRecordMr: 'एकरी १४ टन एक्सपोर्ट ग्रेड डाळिंब (शून्य तेल्या रोग)',
    cropYieldRecordEn: '14 Tons/Acre Export Pomegranate (Zero Bacterial Blight)',
    netProfitPerAcreMr: '₹७.२ लाख निव्वळ नफा प्रति एकर',
    netProfitPerAcreEn: '₹7.2 Lakh Net Profit / Acre',
    bestFarmingTechniquesMr: [
      'मृग बहार ऐवजी हस्त बहार नियोजन',
      'बायो-बॅक्टेरिसाइड व तांबेयुक्त बोर्डो मिश्रणाचा नियमित वापर',
      'सेंद्रिय गांडूळ खत + निंबोळी पेंड चा बेस डोस',
      'ठिबकद्वारे पोटॅशियम शोनाईट व बोरॉन फर्टिगेशन'
    ],
    bestFarmingTechniquesEn: [
      'Strategic Hasta Bahar flowering cycle management',
      'Bio-bactericides and regular Bordeaux mixture sprays',
      'Vermicompost + Neem cake balanced basal dose',
      'Potassium Schoenite and Boron fertigation'
    ],
    produceForSale: [
      {
        itemMr: 'सुपर भगवा डाळिंब (सिंदूरी लाल दाणे)',
        itemEn: 'Super Bhagwa Pomegranate (Ruby Red)',
        quantityAvailable: '२० टन उपलब्ध',
        priceRate: '₹१४० / किलो',
        qualityGrade: '२५० ते ३५० ग्रॅम फळ, डागविरहित'
      },
      {
        itemMr: 'सुपर भगवा मातृवृक्षाची गुटी कलमे',
        itemEn: 'True-to-Type Bhagwa Air-Layered Grafts',
        quantityAvailable: '५,००० कलमे उपलब्ध',
        priceRate: '₹३५ / कलम',
        qualityGrade: 'तेल्यामुक्त प्रमाणित मदर प्लांट कलमे'
      }
    ],
    phone: '9423157888',
    whatsapp: '9423157888',
    avatarEmoji: '🍎',
    experienceYears: 19,
    awardsMr: 'मराठवाडा फळबाग भूषण पुरस्कार',
    awardsEn: 'Marathwada Horticulture Excellence Award',
    storyQuoteMr: 'डाळिंबात तेल्या रोगाला घाबरू नका. बोर्डो मिश्रण, झाडांची प्रतिकारशक्ती आणि योग्य छाटणी हीच यशाची त्रिसूत्री आहे.',
    storyQuoteEn: 'Do not fear bacterial blight. Bordeaux spray, plant immunity and canopy pruning guarantee bumper harvest.',
    verified: true
  },
  {
    id: 'pf_6',
    farmerName: 'प्रवीण बापूसाहेब जगताप',
    village: 'सिन्नर',
    taluka: 'सिन्नर',
    district: 'नाशिक',
    region: 'paschim',
    mainCropMr: 'लाल कांदा (भीमा सुपर) व कांदा बीजोत्पादन',
    mainCropEn: 'Red Onion (Bhima Super) & Seed Production',
    variety: 'भीमा सुपर व पंचगंगा',
    acres: 9,
    cropYieldRecordMr: 'एकरी २४० क्विंटल कांदा व एकरी ४.५ क्विंटल कांदा बियाणे',
    cropYieldRecordEn: '240 Quintals/Acre Onion & 4.5 Qtl/Acre Seed Yield',
    netProfitPerAcreMr: '₹३.८ लाख निव्वळ नफा प्रति एकर',
    netProfitPerAcreEn: '₹3.8 Lakh Net Profit / Acre',
    bestFarmingTechniquesMr: [
      'गादी वाफ्यावर ठिबक व तुषार सिंचनाचा योग्य मेळ',
      'कांदा चाळ (Onion Storage Chawl) मध्ये ६ महिने साठवणूक तंत्र',
      'कांदा फुगवणीसाठी १३-०-४५ व पोटॅशचे योग्य डोस',
      'स्वतःचे दर्जेदार कांदा बीजोत्पादन'
    ],
    bestFarmingTechniquesEn: [
      'Raised beds with drip and micro-sprinkler combination',
      'Ventilated onion chawl 6-month storage technique',
      '13-0-45 and Potash fertigation during bulb expansion',
      'Farm-level pure onion seed multiplication'
    ],
    produceForSale: [
      {
        itemMr: 'भीमा सुपर शुद्ध गावरान कांदा बियाणे (Black Seed)',
        itemEn: 'Bhima Super Pure Onion Seed (Black Seed)',
        quantityAvailable: '४०० किलो उपलब्ध',
        priceRate: '₹२,२०० / किलो',
        qualityGrade: '९५% जर्मिनेशन, गोल गर्द लाल कांदा'
      },
      {
        itemMr: 'कांदा रोपे (Ready Nursery Seedlings)',
        itemEn: 'Ready-to-Transplant Onion Seedlings',
        quantityAvailable: '५ एकरासाठी रोपे उपलब्ध',
        priceRate: '₹२,५०० / एकर वाफा',
        qualityGrade: '४५ दिवसांची बळकट निरोगी रोपे'
      }
    ],
    phone: '9822998877',
    whatsapp: '9822998877',
    avatarEmoji: '🧅',
    experienceYears: 15,
    awardsMr: 'नाशिक जिल्हा कांदा उत्पादक रत्न',
    awardsEn: 'Nashik District Onion Icon',
    storyQuoteMr: 'कांदा बाजारभाव कधीही कोसळू शकतात, पण स्वतःची चाळ असेल आणि स्वतःचे बियाणे असेल तर कांदा कधीच तोटा देत नाही.',
    storyQuoteEn: 'Mandi prices fluctuate, but having your own storage chawl and farm seeds ensures consistent onion profitability.',
    verified: true
  }
];

