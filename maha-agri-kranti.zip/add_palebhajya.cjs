const fs = require('fs');

let content = fs.readFileSync('src/data/agriData.ts', 'utf8');

// 1. Add to LIVE_MANDI_RATES
const newRates = `
  { mandi: 'पुणे (Pune)', crop: 'कोथिंबीर (Coriander)', minPrice: 15, maxPrice: 30, avgPrice: 20, trend: 'up' },
  { mandi: 'नाशिक (Nashik)', crop: 'मेथी (Fenugreek)', minPrice: 10, maxPrice: 22, avgPrice: 15, trend: 'stable' },
  { mandi: 'कल्याण (Kalyan)', crop: 'पालक (Spinach)', minPrice: 10, maxPrice: 18, avgPrice: 14, trend: 'down' },
  { mandi: 'सातारा (Satara)', crop: 'शेपू (Dill Leaves)', minPrice: 8, maxPrice: 15, avgPrice: 12, trend: 'stable' },
`;
content = content.replace(
  /export const LIVE_MANDI_RATES: LiveMandiRate\[\] = \[/,
  `export const LIVE_MANDI_RATES: LiveMandiRate[] = [${newRates}`
);

// 2. Add to DISEASES_DATABASE
const newDiseases = `
  {
    id: 'leafy_veg_spot',
    nameMr: 'पालेभाज्यांवरील पानांचे ठिपके (Leaf Spot)',
    nameEn: 'Leafy Vegetables Leaf Spot / Blight',
    cropMr: 'पालेभाज्या (पालक, मेथी, कोथिंबीर)',
    cropEn: 'Leafy Vegetables',
    seasonMr: 'सर्व हंगामात (विशेषत: पावसाळ्यात व दमट हवेत)',
    severityPercent: 45,
    severityLabel: '४५% पानांवर काळे/तपकिरी डाग',
    upcharMr: 'मॅन्कोझेब (Mancozeb) २.५ ग्रॅम किंवा कॉपर ऑक्सिक्लोराईड (COC) २ ग्रॅम / लिटर पाणी फवारणी करावी. फवारणीनंतर किमान ४-५ दिवस भाजी काढू नये.',
    kharchMr: '₹३०० / एकर',
    medicines: [
      { brand: 'Dithane M-45 (Mancozeb)', company: 'Corteva', dose: '2.5 gm/Ltr पाणी', timing: 'सुरुवातीच्या टप्प्यात' },
      { brand: 'Blitox (Copper Oxychloride)', company: 'Tata Rallis', dose: '2 gm/Ltr पाणी', timing: 'रोग वाढल्यास' }
    ],
    imagePlaceholder: '🥬'
  },
  {
    id: 'leafy_veg_aphids',
    nameMr: 'पालेभाज्यांवरील मावा (Aphids)',
    nameEn: 'Leafy Vegetables Aphids',
    cropMr: 'पालेभाज्या (कोथिंबीर, मेथी, मोहरी)',
    cropEn: 'Leafy Vegetables',
    seasonMr: 'हिवाळा आणि उन्हाळा',
    severityPercent: 55,
    severityLabel: '५५% पानांच्या मागील बाजूस हिरवे/काळे कीटक',
    upcharMr: '५% निंबोळी अर्काची फवारणी करावी. प्रादुर्भाव जास्त असल्यास थायोमेथोक्झाम (Thiamethoxam) ०.५ ग्रॅम / लिटर फवारावे.',
    kharchMr: '₹३५० / एकर',
    medicines: [
      { brand: 'Neem Oil 10000 PPM', company: 'Organic', dose: '3 ml/Ltr पाणी', timing: 'सुरुवातीच्या अवस्थेत' },
      { brand: 'Actara (Thiamethoxam)', company: 'Syngenta', dose: '0.5 gm/Ltr पाणी', timing: 'किडीचा प्रादुर्भाव जास्त असल्यास' }
    ],
    imagePlaceholder: '🥬'
  },
`;
content = content.replace(
  /export const DISEASES_DATABASE: DiseaseInfo\[\] = \[/,
  `export const DISEASES_DATABASE: DiseaseInfo[] = [${newDiseases}`
);

// 3. Add to MARKET_CROPS
const newMarketCrops = `
  {
    id: 'mc_kothimbir',
    nameMr: 'कोथिंबीर व मेथी (ताजी/सेंद्रिय)',
    nameEn: 'Fresh Coriander & Fenugreek',
    emoji: '🥬',
    farmerName: 'संदीप काळे',
    location: 'नारायणगाव, पुणे',
    qty: 'रोज ५००+ जुड्या उपलब्ध',
    directPrice: 12,
    apmcPrice: 8,
    contact: '9876543210',
    tag: '⭐ थेट शेतातून ताजी'
  },
  {
    id: 'mc_palak',
    nameMr: 'पालक व शेपू (Fresh Palak)',
    nameEn: 'Fresh Spinach',
    emoji: '🥬',
    farmerName: 'रमेश जाधव',
    location: 'वाई, सातारा',
    qty: 'रोज ३०० जुड्या',
    directPrice: 10,
    apmcPrice: 6,
    contact: '9123456780',
    tag: '✨ हिरवीगार व ताजी'
  },
`;
content = content.replace(
  /export const MARKET_CROPS: MarketCropItem\[\] = \[/,
  `export const MARKET_CROPS: MarketCropItem[] = [${newMarketCrops}`
);

fs.writeFileSync('src/data/agriData.ts', content);
