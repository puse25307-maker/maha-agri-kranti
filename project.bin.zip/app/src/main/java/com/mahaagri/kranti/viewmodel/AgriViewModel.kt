package com.mahaagri.kranti.viewmodel

import android.app.Application
import android.speech.tts.TextToSpeech
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mahaagri.kranti.MahaAgriApplication
import com.mahaagri.kranti.data.datasource.AgriDatabase
import com.mahaagri.kranti.data.local.ScanHistoryEntity
import com.mahaagri.kranti.data.local.UserEquipmentEntity
import com.mahaagri.kranti.data.models.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

data class UiState(
    val currentTab: TabType = TabType.HOME,
    val language: Language = Language.MARATHI,
    val selectedDisease: DiseaseInfo = AgriDatabase.diseases.first(),
    val isScanning: Boolean = false,
    val scanPreviewUri: String? = null,
    val toastMessage: String? = null,
    val equipmentFilter: String = "all", // all, tractor, drone, harvester, rotavator
    val equipmentListingFilter: String = "all", // all, rent, sell
    val mandiSearchQuery: String = "",
    val yojanaSearchQuery: String = "",
    val progressiveRegionFilter: String = "all" // all, paschim, vidarbha, marathwada, khandesh
)

class AgriViewModel(application: Application) : AndroidViewModel(application) {

    private val db = (application as MahaAgriApplication).database
    private val scanDao = db.scanHistoryDao()
    private val equipmentDao = db.userEquipmentDao()

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    val scanHistory: StateFlow<List<ScanHistoryEntity>> = scanDao.getAllHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userEquipment: StateFlow<List<UserEquipmentEntity>> = equipmentDao.getAllEquipment()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(application) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("mr", "IN")
            }
        }
    }

    fun setTab(tab: TabType) {
        _uiState.update { it.copy(currentTab = tab) }
    }

    fun toggleLanguage() {
        _uiState.update {
            val newLang = if (it.language == Language.MARATHI) Language.ENGLISH else Language.MARATHI
            it.copy(language = newLang)
        }
    }

    fun selectDisease(disease: DiseaseInfo) {
        _uiState.update {
            it.copy(
                selectedDisease = disease,
                scanPreviewUri = null
            )
        }
        speakText(
            if (_uiState.value.language == Language.MARATHI)
                "${disease.cropMr} - ${disease.nameMr} रोग निदान पूर्ण झाले."
            else
                "${disease.cropEn} - ${disease.nameEn} diagnosed."
        )
    }

    fun simulateAiScan(imageUri: String? = null, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            _uiState.update { it.copy(isScanning = true, scanPreviewUri = imageUri) }
            kotlinx.coroutines.delay(1200)
            _uiState.update { it.copy(isScanning = false) }

            val scanned = _uiState.value.selectedDisease
            scanDao.insertScan(
                ScanHistoryEntity(
                    cropName = scanned.cropMr,
                    diseaseName = scanned.nameMr,
                    severityPercent = scanned.severityPercent,
                    scannedDate = "आज (Today)",
                    imageUri = imageUri
                )
            )

            speakText(
                if (_uiState.value.language == Language.MARATHI)
                    "एआय रोग निदान पूर्ण झाले. तीव्रता ${scanned.severityPercent} टक्के."
                else
                    "AI Crop Disease scan complete. Severity ${scanned.severityPercent}%."
            )
            onComplete()
        }
    }

    fun addUserEquipment(
        title: String,
        category: String,
        listingType: String,
        rate: String,
        phone: String,
        location: String
    ) {
        viewModelScope.launch {
            val newEquipment = UserEquipmentEntity(
                id = UUID.randomUUID().toString(),
                title = title,
                category = category,
                listingType = listingType,
                rate = rate,
                phone = phone,
                location = location
            )
            equipmentDao.insertEquipment(newEquipment)
            showToast(if (_uiState.value.language == Language.MARATHI) "आपले अवजार यशस्वीरित्या जोडले गेले!" else "Equipment listing published!")
        }
    }

    fun setEquipmentCategoryFilter(category: String) {
        _uiState.update { it.copy(equipmentFilter = category) }
    }

    fun setEquipmentListingFilter(type: String) {
        _uiState.update { it.copy(equipmentListingFilter = type) }
    }

    fun setMandiSearch(query: String) {
        _uiState.update { it.copy(mandiSearchQuery = query) }
    }

    fun setYojanaSearch(query: String) {
        _uiState.update { it.copy(yojanaSearchQuery = query) }
    }

    fun setProgressiveRegion(region: String) {
        _uiState.update { it.copy(progressiveRegionFilter = region) }
    }

    fun showToast(msg: String) {
        _uiState.update { it.copy(toastMessage = msg) }
    }

    fun clearToast() {
        _uiState.update { it.copy(toastMessage = null) }
    }

    fun speakText(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "maha_agri_tts")
    }

    override fun onCleared() {
        tts?.stop()
        tts?.shutdown()
        super.onCleared()
    }
}
