package com.mahaagri.kranti

import android.app.Application
import androidx.room.Room
import com.mahaagri.kranti.data.local.AppRoomDatabase

class MahaAgriApplication : Application() {
    lateinit var database: AppRoomDatabase
        private set

    override fun onCreate() {
        super.onCreate()
        database = Room.databaseBuilder(
            applicationContext,
            AppRoomDatabase::class.java,
            "maha_agri_kranti_db"
        ).fallbackToDestructiveMigration().build()
    }
}
