const fs = require('fs');

let content = fs.readFileSync('src/data/agriData.ts', 'utf8');

// 1. Add to LIVE_MANDI_RATES
const newRates = `
  { mandi: 'पुणे (Pune)', crop: 'गहू (Wheat)', minPrice: 2400, maxPrice: 3200, avgPrice: 2800, trend: 'stable' },
  { mandi: 'भंडारा (Bhandara)', crop: 'तांदूळ/भात (Rice)', minPrice: 3500, maxPrice: 5500, avgPrice: 4500, trend: 'up' },
  { mandi: 'सोलापूर (Solapur)', crop: 'ज्वारी (Jowar)', minPrice: 3200, maxPrice: 4800, avgPrice: 4000, trend: 'up' },
  { mandi: 'अहमदनगर (Ahmednagar)', crop: 'बाजरी (Bajra)', minPrice: 2000, maxPrice: 2600, avgPrice: 2300, trend: 'stable' },
  { mandi: 'छत्रपती संभाजीनगर (Chhatrapati Sambhajinagar)', crop: 'मका (Maize)', minPrice: 1800, maxPrice: 2200, avgPrice: 2000, trend: 'down' },
`;
content = content.replace(
  /export const LIVE_MANDI_RATES: LiveMandiRate\[\] = \[/,
  `export const LIVE_MANDI_RATES: LiveMandiRate[] = [${newRates}`
);

// 2. Add to DISEASES_DATABASE
const newDiseases = `
  {
    id: 'wheat_rust',
    nameMr: 'गहू तांबेरा (Wheat Rust)',
    nameEn: 'Wheat Rust (Brown/Yellow)',
    cropMr: 'गहू (Wheat - Lokwan/HD2189)',
    cropEn: 'Wheat',
    seasonMr: 'रब्बी (थंडीच्या दिवसात)',
    severityPercent: 50,
    severityLabel: '५०% पानांवर पिवळे/तपकिरी डाग',
    upcharMr: 'मॅन्कोझेब (Mancozeb) २.५ ग्रॅम किंवा प्रोपिकोनाझोल (Tilt) १ मिली / लिटर पाणी फवारणी करावी.',
    kharchMr: '₹४०० / एकर',
    medicines: [
      { brand: 'Dithane M-45 (Mancozeb)', company: 'Corteva', dose: '2.5 gm/Ltr पाणी', timing: 'सुरुवातीच्या टप्प्यात' },
      { brand: 'Tilt 25% EC (Propiconazole)', company: 'Syngenta', dose: '1 ml/Ltr पाणी', timing: 'प्रादुर्भाव वाढल्यास' }
    ],
    imagePlaceholder: '🌾'
  },
  {
    id: 'rice_blast',
    nameMr: 'भात करपा रोग (Rice Blast)',
    nameEn: 'Rice Blast Fungus',
    cropMr: 'भात / तांदूळ (Rice - Indrayani/Basmati)',
    cropEn: 'Rice',
    seasonMr: 'खरीप (पावसाळा - दमट हवामान)',
    severityPercent: 65,
    severityLabel: '६५% पानांवर डोळ्यांच्या आकाराचे डाग',
    upcharMr: 'ट्रायसायक्लाझोल (Tricyclazole) ०.६ ग्रॅम किंवा आयसोप्रोथिओलेन (Fuji-One) १.५ मिली / लिटर पाणी फवारावे.',
    kharchMr: '₹५०० / एकर',
    medicines: [
      { brand: 'Baan (Tricyclazole 75% WP)', company: 'Coromandel', dose: '0.6 gm/Ltr पाणी', timing: 'रोग दिसताच फवारा' },
      { brand: 'Fuji-One (Isoprothiolane 40% EC)', company: 'Rallis', dose: '1.5 ml/Ltr पाणी', timing: 'करपा वाढल्यावर' }
    ],
    imagePlaceholder: '🌾'
  },
  {
    id: 'jowar_shoot_fly',
    nameMr: 'ज्वारी खोडमाशी (Shoot Fly)',
    nameEn: 'Jowar Shoot Fly',
    cropMr: 'ज्वारी (Jowar/Sorghum - Maldandi)',
    cropEn: 'Jowar',
    seasonMr: 'रब्बी / खरीप (पेरणीनंतर १ ते ४ आठवडे)',
    severityPercent: 40,
    severityLabel: '४०% मुख्य कोंब सुकलेले (Dead Heart)',
    upcharMr: 'इमिडाक्लोप्रिड (Imidacloprid) बीजप्रक्रिया किंवा क्लोरपायरीफॉस (Chlorpyrifos) २०% EC २ मिली / लिटर पाणी फवारणी.',
    kharchMr: '₹३५० / एकर',
    medicines: [
      { brand: 'Gaucho (Imidacloprid 600 FS)', company: 'Bayer', dose: '10 ml/kg बियाणे', timing: 'पेरणीपूर्वी बीजप्रक्रिया' },
      { brand: 'Dursban 20 EC (Chlorpyrifos)', company: 'Corteva', dose: '2 ml/Ltr पाणी', timing: 'खोडमाशी दिसल्यावर' }
    ],
    imagePlaceholder: '🌾'
  },
  {
    id: 'bajra_ergot',
    nameMr: 'बाजरी अरगट (चिकटा रोग)',
    nameEn: 'Bajra Ergot (Sticky honeydew)',
    cropMr: 'बाजरी (Bajra/Pearl Millet)',
    cropEn: 'Bajra',
    seasonMr: 'खरीप (फुलोरा अवस्थेत पाऊस असल्यास)',
    severityPercent: 55,
    severityLabel: '५५% कणसातून चिकट स्राव',
    upcharMr: 'मॅन्कोझेब (Mancozeb) २.५ ग्रॅम किंवा कार्बेन्डाझिम (Carbendazim) १ ग्रॅम / लिटर पाणी फवारणी.',
    kharchMr: '₹३०० / एकर',
    medicines: [
      { brand: 'SAAF (Mancozeb + Carbendazim)', company: 'UPL', dose: '2 gm/Ltr पाणी', timing: 'फुलोरा अवस्थेत प्रतिबंधात्मक' }
    ],
    imagePlaceholder: '🌾'
  },
  {
    id: 'maize_fall_armyworm',
    nameMr: 'मका लष्करी अळी (Fall Armyworm)',
    nameEn: 'Maize Fall Armyworm (FAW)',
    cropMr: 'मका (Maize/Corn)',
    cropEn: 'Maize',
    seasonMr: 'खरीप व रब्बी (सर्व हंगामात)',
    severityPercent: 70,
    severityLabel: '७०% पोंग्यात अळ्या व खाल्लेली पाने',
    upcharMr: 'स्पायनेटोरम (Delegate) ०.५ मिली किंवा इमामेक्टिन बेंझोएट (Proclaim) ०.४ ग्रॅम / लिटर पाणी पोंग्यात फवारावे.',
    kharchMr: '₹६५० / एकर',
    medicines: [
      { brand: 'Delegate (Spinetoram 11.7% SC)', company: 'Corteva', dose: '0.5 ml/Ltr पाणी', timing: 'अळीचा प्रादुर्भाव वाढल्यावर' },
      { brand: 'Proclaim (Emamectin Benzoate 5% SG)', company: 'Syngenta', dose: '0.4 gm/Ltr पाणी', timing: 'लहान अळ्या दिसल्यास' }
    ],
    imagePlaceholder: '🌽'
  },
`;
content = content.replace(
  /export const DISEASES_DATABASE: DiseaseInfo\[\] = \[/,
  `export const DISEASES_DATABASE: DiseaseInfo[] = [${newDiseases}`
);

// 3. Add to MARKET_CROPS
const newMarketCrops = `
  {
    id: 'mc_wheat',
    nameMr: 'गहू (लोकवन / सिहोर)',
    nameEn: 'Wheat (Lokwan)',
    emoji: '🌾',
    farmerName: 'ज्ञानेश्वर कदम',
    location: 'शिरूर, पुणे',
    qty: '२० क्विंटल उपलब्ध',
    directPrice: 3200,
    apmcPrice: 2800,
    contact: '9856321470',
    tag: '⭐ स्वच्छ गहू'
  },
  {
    id: 'mc_rice',
    nameMr: 'इंद्रायणी तांदूळ (प्रीमियम)',
    nameEn: 'Indrayani Rice',
    emoji: '🌾',
    farmerName: 'सुनील पवार',
    location: 'भोर, पुणे',
    qty: '१० क्विंटल उपलब्ध',
    directPrice: 6500,
    apmcPrice: 5500,
    contact: '9965412380',
    tag: '✨ सुगंधी'
  },
  {
    id: 'mc_jowar',
    nameMr: 'शाळू / मालदांडी ज्वारी',
    nameEn: 'Maldandi Jowar',
    emoji: '🌾',
    farmerName: 'बाळासाहेब सोळुंके',
    location: 'मोहोळ, सोलापूर',
    qty: '१५ क्विंटल उपलब्ध',
    directPrice: 5000,
    apmcPrice: 4200,
    contact: '9012345678',
    tag: '🔥 उत्तम प्रत'
  },
  {
    id: 'mc_maize',
    nameMr: 'मका (पिवळा - पोल्ट्री ग्रेड)',
    nameEn: 'Maize (Yellow Corn)',
    emoji: '🌽',
    farmerName: 'कैलास चौधरी',
    location: 'सिल्लोड, छ. संभाजीनगर',
    qty: '५० क्विंटल',
    directPrice: 2100,
    apmcPrice: 1900,
    contact: '9123456789',
    tag: '⭐ सुकलेला मका'
  },
`;
content = content.replace(
  /export const MARKET_CROPS: MarketCropItem\[\] = \[/,
  `export const MARKET_CROPS: MarketCropItem[] = [${newMarketCrops}`
);

fs.writeFileSync('src/data/agriData.ts', content);
