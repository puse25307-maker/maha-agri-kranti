package com.mahaagri.kranti.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mahaagri.kranti.data.datasource.AgriDatabase
import com.mahaagri.kranti.data.models.Language
import com.mahaagri.kranti.ui.theme.*

@Composable
fun ProgressiveFarmersScreen(
    lang: Language,
    selectedRegion: String,
    onSelectRegion: (String) -> Unit,
    onCallFarmer: (String) -> Unit
) {
    val regions = listOf(
        "all" to if (lang == Language.MARATHI) "सर्व महाराष्ट्र" else "All Maha",
        "paschim" to if (lang == Language.MARATHI) "पश्चिम महाराष्ट्र" else "Western Maha",
        "vidarbha" to if (lang == Language.MARATHI) "विदर्भ" else "Vidarbha",
        "marathwada" to if (lang == Language.MARATHI) "मराठवाडा" else "Marathwada",
        "khandesh" to if (lang == Language.MARATHI) "खानदेश" else "Khandesh"
    )

    val list = AgriDatabase.progressiveFarmers.filter {
        selectedRegion == "all" || it.region == selectedRegion
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
    ) {
        // Header
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = if (lang == Language.MARATHI) "प्रगतशील शेतकरी व विक्रमी पिके 🏆" else "Progressive Farmers & Crop Records 🏆",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    color = Slate900
                )
                Text(
                    text = if (lang == Language.MARATHI)
                        "महाराष्ट्रातील पुरस्कार प्राप्त शेतकऱ्यांचे उत्पादन रहस्य, तंत्रज्ञान व थेट दर्जेदार रोपे/उत्पादन खरेदी."
                    else
                        "Award-winning crop yields, secrets, techniques & direct purchase from farmers.",
                    fontSize = 11.sp,
                    color = Slate600,
                    lineHeight = 15.sp
                )

                // Region filter
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(regions) { (key, label) ->
                        val isSelected = selectedRegion == key
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) Green800 else Slate100)
                                .clickable { onSelectRegion(key) }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = label,
                                color = if (isSelected) Color.White else Slate800,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }

        // Farmer Cards
        items(list) { farmer ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = farmer.avatarEmoji, fontSize = 32.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = farmer.farmerName,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Slate900
                                )
                                Text(
                                    text = "${farmer.village}, ${farmer.taluka} (${farmer.district})",
                                    fontSize = 10.sp,
                                    color = Slate500
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Green100)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(text = "प्रमाणित", fontSize = 9.sp, fontWeight = FontWeight.Black, color = Green800)
                        }
                    }

                    // Highlights
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Amber100.copy(alpha = 0.4f))
                            .padding(10.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = "मुख्य पीक: ${farmer.mainCropMr}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Slate900
                            )
                            Text(
                                text = "विक्रमी उत्पादन: ${farmer.cropYieldRecordMr}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = Green800
                            )
                            Text(
                                text = "निव्वळ नफा: ${farmer.netProfitPerAcreMr}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Amber700
                            )
                        }
                    }

                    // Best Techniques
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(text = "उत्पादन वाढीचे मुख्य तंत्रज्ञान:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Slate700)
                        farmer.bestFarmingTechniquesMr.forEach { tech ->
                            Text(text = "• $tech", fontSize = 10.sp, color = Slate600, lineHeight = 14.sp)
                        }
                    }

                    // Quote
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Slate50)
                            .padding(8.dp)
                    ) {
                        Text(
                            text = "\"${farmer.storyQuoteMr}\"",
                            fontSize = 10.sp,
                            color = Slate700,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Button(
                        onClick = { onCallFarmer(farmer.phone) },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Green800),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Phone, contentDescription = null, tint = Amber500, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (lang == Language.MARATHI) "शेतकऱ्यांशी संपर्क करा (${farmer.phone})" else "Call Farmer",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
