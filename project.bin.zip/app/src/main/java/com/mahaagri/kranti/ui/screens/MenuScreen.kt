package com.mahaagri.kranti.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mahaagri.kranti.data.models.Language
import com.mahaagri.kranti.data.models.TabType
import com.mahaagri.kranti.ui.theme.*

data class MenuItem(
    val tab: TabType,
    val titleMr: String,
    val titleEn: String,
    val descMr: String,
    val emoji: String,
    val iconBg: Color
)

@Composable
fun MenuScreen(
    lang: Language,
    onNavigate: (TabType) -> Unit
) {
    val menuItems = listOf(
        MenuItem(TabType.MATI_PIK, "माती व खते नियोजन", "Soil & Fertilizer", "माती परीक्षण NPK व खत मात्रा", "🧪", Green100),
        MenuItem(TabType.US_BELT, "ऊस पट्टा व साखर कारखाने", "Sugarcane Belt", "कारखाना FRP दर व Co-86032", "🎋", Amber100),
        MenuItem(TabType.YOJANA, "सरकारी कृषी योजना", "Govt Schemes", "MahaDBT, सौर पंप, पिक विमा", "🏛️", Blue100),
        MenuItem(TabType.JOD_DHANDA, "शेतीपूरक जोडधंदे", "Agri Allied Business", "डेअरी, शेळीपालन, कुक्कुटपालन", "🐄", Amber100),
        MenuItem(TabType.EXPORT, "थेट निर्यात (दुबई/इराण)", "Export Hub", "ग्लोबल गॅप व केळी-द्राक्ष निर्यात", "🚢", Teal100),
        MenuItem(TabType.DOCTOR, "कृषी तज्ज्ञ डॉक्टर फोन", "Doctor Helpline", "वरिष्ठ कृषी शास्त्रज्ञ थेट सल्ला", "👨‍⚕️", Green100),
        MenuItem(TabType.SHALA, "कृषी ज्ञान शाळा", "Agri Academy", "मास्टरक्लास व्हिडिओ व ऑडिओ", "🎓", Amber100),
        MenuItem(TabType.CONNECT, "महाराष्ट्र शेतकरी कनेक्ट", "Maha Connect", "पश्चिम, विदर्भ, मराठवाडा शेतकरी", "🤝", Blue100),
        MenuItem(TabType.EQUIPMENT, "कृषी अवजारे हब", "Equipment Hub", "ट्रॅक्टर, ड्रोन व रोटाव्हेटर", "🚜", Amber100),
        MenuItem(TabType.PROGRESSIVE_FARMERS, "प्रगतशील शेतकरी", "Top Farmers", "विक्रमी उत्पादन व तंत्रज्ञान", "🏆", Green100)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Text(
            text = if (lang == Language.MARATHI) "सर्व कृषी सेवा मेनू (All Services) ≡" else "All Agri Services ≡",
            fontSize = 16.sp,
            fontWeight = FontWeight.Black,
            color = Slate900,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(menuItems) { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .clickable { onNavigate(item.tab) },
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(item.iconBg),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = item.emoji, fontSize = 20.sp)
                        }

                        Text(
                            text = if (lang == Language.MARATHI) item.titleMr else item.titleEn,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            color = Slate900,
                            lineHeight = 15.sp
                        )

                        Text(
                            text = item.descMr,
                            fontSize = 10.sp,
                            color = Slate500,
                            lineHeight = 13.sp
                        )
                    }
                }
            }
        }
    }
}
