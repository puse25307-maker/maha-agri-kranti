const fs = require('fs');

function replaceInFile(file) {
  let content = fs.readFileSync(file, 'utf8');
  content = content.replace(/👨‍⚕️/g, '🌱');
  fs.writeFileSync(file, content);
}

replaceInFile('src/components/Tab9DoctorHelpline.tsx');
replaceInFile('src/components/TabHome.tsx');

