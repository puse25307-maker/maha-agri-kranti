package com.mahaagri.kranti.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mahaagri.kranti.data.datasource.AgriDatabase
import com.mahaagri.kranti.data.local.UserEquipmentEntity
import com.mahaagri.kranti.data.models.FarmingEquipment
import com.mahaagri.kranti.data.models.Language
import com.mahaagri.kranti.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EquipmentHubScreen(
    lang: Language,
    selectedCategory: String,
    selectedListingType: String,
    userListings: List<UserEquipmentEntity>,
    onSelectCategory: (String) -> Unit,
    onSelectListingType: (String) -> Unit,
    onAddEquipment: (title: String, category: String, type: String, rate: String, phone: String, loc: String) -> Unit,
    onCallPhone: (String) -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var inputTitle by remember { mutableStateOf("") }
    var inputCategory by remember { mutableStateOf("tractor") }
    var inputType by remember { mutableStateOf("rent") }
    var inputRate by remember { mutableStateOf("") }
    var inputPhone by remember { mutableStateOf("") }
    var inputLocation by remember { mutableStateOf("") }

    val categories = listOf(
        "all" to if (lang == Language.MARATHI) "सर्व अवजारे" else "All",
        "tractor" to if (lang == Language.MARATHI) "ट्रॅक्टर" else "Tractors",
        "drone" to if (lang == Language.MARATHI) "ॲग्री ड्रोन" else "Drones",
        "rotavator" to if (lang == Language.MARATHI) "रोटाव्हेटर" else "Rotavators",
        "harvester" to if (lang == Language.MARATHI) "हार्वेस्टर" else "Harvesters"
    )

    val filteredList = AgriDatabase.equipmentList.filter { item ->
        val matchesCategory = selectedCategory == "all" || item.category == selectedCategory
        val matchesType = selectedListingType == "all" || item.listingType == selectedListingType || item.listingType == "both"
        matchesCategory && matchesType
    }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = Green800,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                icon = { Icon(Icons.Default.Add, contentDescription = null, tint = Amber500) },
                text = { Text(text = if (lang == Language.MARATHI) "अवजार जोडा" else "Add Equipment", fontWeight = FontWeight.Bold) }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
        ) {
            // Header bar
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (lang == Language.MARATHI) "कृषी अवजारे भाडे व विक्री हब 🚜" else "Equipment Rental & Sale Hub 🚜",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        color = Slate900
                    )

                    // Filter category row
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(categories) { (key, label) ->
                            val isSelected = selectedCategory == key
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isSelected) Green800 else Slate100)
                                    .clickable { onSelectCategory(key) }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSelected) Color.White else Slate800,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Black else FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }

            // User-added Offline Listings if any
            if (userListings.isNotEmpty()) {
                item {
                    Text(
                        text = if (lang == Language.MARATHI) "आपली जोडलेली अवजारे (My Listings):" else "My Saved Listings:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        color = Green800
                    )
                }

                items(userListings) { userItem ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Amber100.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = userItem.title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Slate900)
                                Text(text = "${userItem.location} • दर: ${userItem.rate}", fontSize = 10.sp, color = Slate600)
                            }
                            Button(
                                onClick = { onCallPhone(userItem.phone) },
                                colors = ButtonDefaults.buttonColors(containerColor = Green800),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Phone, contentDescription = null, tint = Amber500, modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }

            // Equipment List
            items(filteredList) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = item.imageEmoji, fontSize = 28.sp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = if (lang == Language.MARATHI) item.nameMr else item.nameEn,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Slate900
                                    )
                                    Text(
                                        text = "${item.village}, ${item.taluka} (${item.district})",
                                        fontSize = 10.sp,
                                        color = Slate500
                                    )
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Amber100)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (item.listingType == "rent") "भाड्याने" else "विक्री",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Slate900
                                )
                            }
                        }

                        // Pricing & specs
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(Slate50)
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = "भाडे दर:", fontSize = 9.sp, color = Slate500)
                                Text(
                                    text = if (item.rentPerHour != null) "₹${item.rentPerHour} / तास" else "₹${item.rentPerAcre} / एकर",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Green800
                                )
                            }

                            Column {
                                Text(text = "मालक:", fontSize = 9.sp, color = Slate500)
                                Text(text = item.ownerName, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Slate800)
                            }
                        }

                        if (item.notesMr != null) {
                            Text(text = "💡 ${item.notesMr}", fontSize = 10.sp, color = Slate600, lineHeight = 13.sp)
                        }

                        Button(
                            onClick = { onCallPhone(item.phone) },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Green800),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Phone, contentDescription = null, tint = Amber500, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (lang == Language.MARATHI) "मालकाशी संपर्क करा (${item.phone})" else "Call Owner (${item.phone})",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Equipment Dialog
    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text(text = if (lang == Language.MARATHI) "नवीन अवजार जोडा" else "Add New Equipment") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = inputTitle,
                        onValueChange = { inputTitle = it },
                        label = { Text("अवजाराचे नाव (उदा. महिंद्रा ५७५)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = inputRate,
                        onValueChange = { inputRate = it },
                        label = { Text("दर (उदा. ₹६५०/तास किंवा ₹८०,०००)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = inputPhone,
                        onValueChange = { inputPhone = it },
                        label = { Text("मोबाईल नंबर") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = inputLocation,
                        onValueChange = { inputLocation = it },
                        label = { Text("गाव व तालुका") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (inputTitle.isNotBlank() && inputPhone.isNotBlank()) {
                            onAddEquipment(inputTitle, inputCategory, inputType, inputRate, inputPhone, inputLocation)
                            showAddDialog = false
                            inputTitle = ""
                            inputRate = ""
                            inputPhone = ""
                            inputLocation = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Green800)
                ) {
                    Text(text = "जतन करा (Save)")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text(text = "रद्द करा (Cancel)")
                }
            }
        )
    }
}
