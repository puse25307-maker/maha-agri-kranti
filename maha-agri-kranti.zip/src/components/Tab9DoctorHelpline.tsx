import React, { useState } from 'react';
import { 
  PhoneCall, 
  ShieldAlert, 
  Clock, 
  MapPin, 
  Radio, 
  CheckCircle2, 
  Volume2, 
  X,
  Sparkles
} from 'lucide-react';
import { speakMarathi } from '../utils/speech';

export const Tab9DoctorHelpline: React.FC = () => {
  const [callAlert, setCallAlert] = useState<string | null>(null);
  const [sosSent, setSosSent] = useState<boolean>(false);

  const handleCall = (title: string, number: string) => {
    setCallAlert(`📞 ${title} यांच्याशी संपर्क जोडला जात आहे... फोन: ${number}`);
    speakMarathi(`${title} यांना कॉल लावला जात आहे.`);
    setTimeout(() => setCallAlert(null), 5000);
  };

  const handleSOS = () => {
    setSosSent(true);
    speakMarathi('आपत्कालीन पीक रोग अलर्ट! नाशिक व बारामती कृषी विज्ञान केंद्रातील तज्ज्ञ डॉक्टर १० मिनिटांत आपल्याला थेट संपर्क करतील.');
    setTimeout(() => setSosSent(false), 6000);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Call Alert */}
      {callAlert && (
        <div className="fixed top-16 left-3 right-3 z-50 bg-slate-950 text-amber-300 p-3 rounded-2xl shadow-2xl border-2 border-[#FFC107] text-xs font-bold animate-bounce flex items-center justify-between">
          <span>{callAlert}</span>
          <button onClick={() => setCallAlert(null)} className="text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-gradient-to-br from-[#1B5E20] via-emerald-800 to-slate-900 text-white p-3.5 rounded-2xl shadow-lg border border-emerald-500">
        <div className="flex items-center justify-between mb-1">
          <span className="bg-[#FFC107] text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
            🌱 कृषी डॉक्टर व २४x७ हेल्पलाईन
          </span>
          <span className="text-[10px] text-amber-300 font-bold">
            विनामूल्य शासकीय सेवा
          </span>
        </div>
        <h2 className="text-base font-black text-white leading-tight">
          पिकावर अचानक रोग पडला? २४ तास मोफत कृषी डॉक्टर मदत!
        </h2>
        <p className="text-[11px] text-emerald-100 mt-0.5">
          किसान कॉल सेंटर व बारामती/नाशिक कृषी विज्ञान केंद्र
        </p>
      </div>

      {/* 1. BIG RED CARD: Govt Toll Free 24x7 "1800-180-1551" */}
      <div className="bg-gradient-to-br from-red-600 via-red-700 to-rose-900 text-white p-4 rounded-2xl shadow-xl border-2 border-amber-400 relative overflow-hidden">
        <div className="flex items-center justify-between mb-2">
          <span className="bg-white text-red-700 text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1 shadow">
            <span className="w-2 h-2 rounded-full bg-red-600 animate-ping"></span>
            २४x७ २४ तास शासकीय टोल फ्री
          </span>
          <span className="text-[10px] font-bold text-amber-300">
            Kisan Call Center
          </span>
        </div>

        <div className="text-center my-3">
          <span className="text-xs font-bold text-red-100 block">राष्ट्रीय किसान कॉल सेंटर (KCC)</span>
          <h3 className="text-2xl font-black text-amber-300 tracking-wider my-1">
            1800-180-1551
          </h3>
          <p className="text-[11px] text-white/90">
            कोणत्याही नेटवर्कवरून पूर्णपणे मोफत • मराठीत कृषी शास्त्रज्ञांचा थेट सल्ला
          </p>
        </div>

        <button
          onClick={() => handleCall('राष्ट्रीय किसान कॉल सेंटर', '1800-180-1551')}
          className="w-full bg-amber-400 hover:bg-amber-500 text-slate-950 font-black py-3 rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all"
        >
          <PhoneCall className="w-4 h-4 fill-slate-950" />
          <span>📞 थेट FREE कॉल करा (Call 1800-180-1551)</span>
        </button>
      </div>

      {/* 2. SOS Emergency Crop Attack Button */}
      <div className="bg-amber-50 border-2 border-dashed border-amber-400 p-3.5 rounded-2xl flex items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-1 text-xs font-black text-amber-950">
            <ShieldAlert className="w-4 h-4 text-red-600" />
            <span>इमर्जन्सी पीक रोग अलर्ट (SOS Rescue)</span>
          </div>
          <p className="text-[10px] text-slate-600 mt-0.5">
            अचानक मोठ्या प्रमाणावर कीड/बुरशी हल्ला झाल्यास डॉक्टर तातडीने संपर्क करतील
          </p>
        </div>
        <button
          onClick={handleSOS}
          className={`px-3 py-2 rounded-xl text-xs font-black shrink-0 transition-all ${
            sosSent ? 'bg-emerald-700 text-white' : 'bg-red-600 hover:bg-red-700 text-white shadow-md animate-pulse'
          }`}
        >
          {sosSent ? '✅ पाठवले!' : '🚨 SOS अलर्ट'}
        </button>
      </div>

      {/* 3. Regional Agricultural Research Stations Helplines */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
            🏛️ प्रमुख कृषी विज्ञान केंद्र व संशोधन संस्था (KVK Helpline):
          </h3>
          <span className="text-[10px] text-emerald-800 font-bold">थेट संपर्क</span>
        </div>

        <div className="space-y-2 text-xs">
          {[
            {
              title: 'कृषी विज्ञान केंद्र (KVK) शारदानगर, बारामती',
              desc: 'ऊस, केळी, दुग्धव्यवसाय व सूक्ष्म सिंचन तज्ज्ञ विभाग',
              phone: '02112-255207',
              loc: 'बारामती, पुणे'
            },
            {
              title: 'राष्ट्रीय द्राक्ष संशोधन केंद्र (NRC Grapes), पुणे',
              desc: 'द्राक्ष डाऊनी, भुरी, मिलीबग व युरोप एक्सपोर्ट गाइड',
              phone: '020-26956000',
              loc: 'मांजरी, पुणे'
            },
            {
              title: 'कृषी विज्ञान केंद्र (KVK), यशवंतराव चव्हाण मुक्त विद्यापीठ, नाशिक',
              desc: 'कांदा, टोमॅटो, भाजीपाला व फळबाग रोग नियंत्रण',
              phone: '0253-2231714',
              loc: 'गंगापूर रोड, नाशिक'
            },
            {
              title: 'महात्मा फुले कृषी विद्यापीठ (MPKV), राहुरी',
              desc: 'हवामान अंदाज, बियाणे उपलब्धता व विद्यापीठ शिफारशी',
              phone: '02426-243208',
              loc: 'राहुरी, अहिल्यानगर'
            },
            {
              title: 'केळी संशोधन केंद्र (Banana Research Station), जळगाव',
              desc: 'टिशू कल्चर, खत व्यवस्थापन व सिगाटोका विशेष सेल',
              phone: '0257-2250100',
              loc: 'जळगाव, खान्देश'
            }
          ].map((center, idx) => (
            <div
              key={idx}
              className="bg-white p-3 rounded-2xl shadow-md border border-slate-200 hover:border-emerald-500 transition-all flex items-start justify-between gap-2"
            >
              <div>
                <h4 className="font-black text-xs text-slate-950">{center.title}</h4>
                <p className="text-[10px] text-slate-600 font-medium mt-0.5">{center.desc}</p>
                <span className="text-[9px] text-emerald-800 font-bold block mt-1">📍 {center.loc}</span>
              </div>

              <button
                onClick={() => handleCall(center.title, center.phone)}
                className="bg-[#1B5E20] hover:bg-emerald-800 text-amber-300 font-black px-3 py-1.5 rounded-xl text-xs flex items-center gap-1 shadow active:scale-95 shrink-0"
              >
                <PhoneCall className="w-3.5 h-3.5 text-amber-400" />
                <span>CALL</span>
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
