package com.mahaagri.kranti.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mahaagri.kranti.data.datasource.AgriDatabase
import com.mahaagri.kranti.data.models.Language
import com.mahaagri.kranti.ui.theme.*

@Composable
fun MahaBazaarScreen(
    lang: Language,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    onCallBuyer: (String) -> Unit
) {
    val mandiList = AgriDatabase.mandiRates.filter {
        searchQuery.isBlank() || it.crop.contains(searchQuery, ignoreCase = true) || it.mandi.contains(searchQuery, ignoreCase = true)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = if (lang == Language.MARATHI) "महा बाजार भाव व थेट खरेदी-विक्री 🛍️" else "Maha Mandi Rates & Direct Sell 🛍️",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    color = Slate900
                )

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchChange,
                    placeholder = { Text("पीक किंवा बाजार समिती शोधा (उदा. केळी, कांदा, नाशिक)") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Slate500) },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    )
                )
            }
        }

        // Live APMC Mandi Rates
        item {
            Text(
                text = if (lang == Language.MARATHI) "आजचे लाईव्ह बाजारभाव (प्रति क्विंटल दर):" else "Today's APMC Mandi Rates (Per Qtl):",
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                color = Green800
            )
        }

        items(mandiList) { rate ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = rate.crop, fontSize = 13.sp, fontWeight = FontWeight.Black, color = Slate900)
                        Text(text = "मंडी: ${rate.mandi}", fontSize = 10.sp, color = Slate500)
                        Text(text = "किमान ₹${rate.minPrice} - कमाल ₹${rate.maxPrice}", fontSize = 9.sp, color = Slate600)
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(text = "₹${rate.avgPrice}", fontSize = 14.sp, fontWeight = FontWeight.Black, color = Green800)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = when (rate.trend) {
                                    "up" -> "तेजी ▲"
                                    "down" -> "मंदी ▼"
                                    else -> "स्थिर ▬"
                                },
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (rate.trend == "up") Green700 else if (rate.trend == "down") Red600 else Slate600
                            )
                        }
                    }
                }
            }
        }
    }
}
