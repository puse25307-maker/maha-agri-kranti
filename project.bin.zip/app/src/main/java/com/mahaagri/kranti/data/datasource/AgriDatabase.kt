package com.mahaagri.kranti.data.datasource

import com.mahaagri.kranti.data.models.*

object AgriDatabase {

    val diseases = listOf(
        DiseaseInfo(
            id = "banana_sigatoka",
            nameMr = "केळी सिगाटोका (काळे व तपकिरी ठिपके)",
            nameEn = "Banana Black Sigatoka Fungus",
            cropMr = "केळी (Banana G9)",
            cropEn = "Banana",
            seasonMr = "खरीप - पावसात व दमट हवेत जास्त प्रादुर्भाव",
            severityPercent = 45,
            severityLabel = "४५% पान खराब (मध्यम धोका)",
            upcharMr = "टिल्ट (Tilt) २५% EC १ मिली / लिटर पाणी + बाविस्टीन (Bavistin) १ ग्रॅम / लिटर - ७ दिवसांच्या अंतराने २ फवारण्या कराव्यात.",
            kharchMr = "₹४५० / एकर",
            medicines = listOf(
                Medicine("Tilt 25% EC (Propiconazole)", "Syngenta", "1 ml/Ltr पाणी", "सकाळी किंवा संध्याकाळी"),
                Medicine("Bavistin 50% WP (Carbendazim)", "Crystal Crop", "1 gm/Ltr पाणी", "पहिल्या फवारणीनंतर ७ दिवसांनी"),
                Medicine("Silwet Gold (Sticker)", "Chemtura", "0.3 ml/Ltr", "पावसात धुवून न जाण्यासाठी")
            ),
            imagePlaceholder = "🍌"
        ),
        DiseaseInfo(
            id = "grape_downy",
            nameMr = "द्राक्ष डाऊनी मिल्ड्यू (केवडा रोग)",
            nameEn = "Grape Downy Mildew (Plasmopara)",
            cropMr = "द्राक्ष (Grapes - Thomson Seedless)",
            cropEn = "Grapes",
            seasonMr = "ऑगस्ट-ऑक्टोबर छाटणी नंतर (पावसाळा)",
            severityPercent = 60,
            severityLabel = "६०% पान व घड बाधित (तात्काळ फवारणी आवश्यक)",
            upcharMr = "अलियेट (Aliette) २ ग्रॅम + एक्रोबॅट (Acrobat) १ ग्रॅम / लिटर पाणी. पाण्याचा निचरा योग्य ठेवावा.",
            kharchMr = "₹६८० / एकर",
            medicines = listOf(
                Medicine("Aliette (Fosetyl-Al)", "Bayer CropScience", "2 gm/Ltr पाणी", "धुके किंवा रिमझिम पाऊस असताना"),
                Medicine("Acrobat (Dimethomorph)", "BASF", "1 gm/Ltr पाणी", "घड अवस्थेत सुरक्षित")
            ),
            imagePlaceholder = "🍇"
        ),
        DiseaseInfo(
            id = "sugarcane_rust",
            nameMr = "ऊस तांबेरा व पोक्का बोईंग",
            nameEn = "Sugarcane Rust & Pokkah Boeng",
            cropMr = "ऊस (Sugarcane 86032 / 265)",
            cropEn = "Sugarcane",
            seasonMr = "जुलै-सप्टेंबर (जास्त आद्रता)",
            severityPercent = 30,
            severityLabel = "३०% पानांवर तांबडे डाग (नियंत्रणात)",
            upcharMr = "साफ (SAAF) २ ग्रॅम / लिटर किंवा कस्टोडिया (Custodia) १.५ मिली फवारणी + युरियाचा अतिरेक टाळावा.",
            kharchMr = "₹३८० / एकर",
            medicines = listOf(
                Medicine("SAAF (Mancozeb + Carbendazim)", "UPL Limited", "2 gm/Ltr पाणी", "पाने पिवळी पडताना"),
                Medicine("Custodia", "ADAMA", "1.5 ml/Ltr पाणी", "वाढ जोमात असताना")
            ),
            imagePlaceholder = "🎋"
        ),
        DiseaseInfo(
            id = "chilli_murda",
            nameMr = "मिरची चुरडा-मुरडा (थ्रिप्स व माइट्स)",
            nameEn = "Chilli Leaf Curl & Thrips",
            cropMr = "मिरची (Chilli - G-4 / Teja)",
            cropEn = "Chilli",
            seasonMr = "उन्हाळी व हिवाळी कोरडे हवामान",
            severityPercent = 50,
            severityLabel = "५०% पाने चुरडली आहेत",
            upcharMr = "पेगासस (Pegasus) १.२ ग्रॅम किंवा डेलिगेट (Delegate) ०.९ मिली / लिटर पाणी. निंबोळी अर्क ५ मिली वापरावा.",
            kharchMr = "₹५२० / एकर",
            medicines = listOf(
                Medicine("Pegasus (Diafenthiuron)", "Syngenta", "1.2 gm/Ltr", "माइट्स व पांढरी माशीसाठी"),
                Medicine("Delegate (Spinetoram)", "Corteva", "0.9 ml/Ltr", "थ्रिप्स नियंत्रणासाठी")
            ),
            imagePlaceholder = "🌶️"
        ),
        DiseaseInfo(
            id = "pomegranate_telya",
            nameMr = "डाळिंब तेल्या रोग (Bacterial Blight)",
            nameEn = "Pomegranate Bacterial Blight",
            cropMr = "डाळिंब (भगवा / Super Bhagwa)",
            cropEn = "Pomegranate",
            seasonMr = "मृग बहार व हस्त बहार (पावसाळा)",
            severityPercent = 40,
            severityLabel = "४०% फळांवर काळे तेलकट ठिपके",
            upcharMr = "बॅक्टोनाशक किंवा स्ट्रेप्टोमायसीन ०.५ ग्रॅम + कॉपर ऑक्सिक्लोराईड २ ग्रॅम / लिटर पाणी + बोर्डो मिश्रण १%.",
            kharchMr = "₹५८० / एकर",
            medicines = listOf(
                Medicine("Bactonashak (Streptomycin Sulphate)", "Tagros", "0.5 gm/Ltr", "पाऊस उघडल्यानंतर"),
                Medicine("Blitox 50 (Copper Oxychloride)", "Tata Rallis", "2 gm/Ltr", "फळांवर डाग दिसताच")
            ),
            imagePlaceholder = "🍎"
        ),
        DiseaseInfo(
            id = "cotton_pink_bollworm",
            nameMr = "कापूस गुलाबी बोंडअळी व रसशोषक किडी",
            nameEn = "Cotton Pink Bollworm & Jassids",
            cropMr = "कापूस (Bt Cotton - Vidarbha/Marathwada)",
            cropEn = "Cotton",
            seasonMr = "सप्टेंबर-नोव्हेंबर (बोंड भरताना)",
            severityPercent = 55,
            severityLabel = "५५% बोंडे पोखरली (गंभीर धोका)",
            upcharMr = "इमामेक्टिन बेन्झोएट ५% SG ०.५ ग्रॅम किंवा प्रोक्लेम ५ ग्रॅम / १० लिटर + फेरोमोन ट्रॅप ५ प्रति एकर लावा.",
            kharchMr = "₹४२० / एकर",
            medicines = listOf(
                Medicine("Proclaim (Emamectin Benzoate)", "Syngenta", "0.5 gm/Ltr", "संध्याकाळच्या वेळी फवारणी"),
                Medicine("Ampligo (Chlorantraniliprole)", "Syngenta", "0.4 ml/Ltr", "अळीचा तीव्र प्रादुर्भाव असताना")
            ),
            imagePlaceholder = "☁️"
        )
    )

    val doctors = listOf(
        DoctorExpert(
            id = "dr_anil_pawar",
            name = "डॉ. अनिल पवार (PhD)",
            degree = "PhD (Horticulture) MPKV राहुरी",
            specialtyMr = "केळी तज्ज्ञ - G9 टिशू कल्चर व निर्यात सल्लागार",
            specialtyEn = "Banana & Export Specialist",
            locationMr = "बारामती - इंदापूर (पुणे)",
            experience = "१५ वर्षे अनुभव (३०००+ शेतकरी)",
            phone = "9021458701",
            rating = 4.9,
            isAvailable = true,
            avatar = "👨‍🌾"
        ),
        DoctorExpert(
            id = "dr_sunil_deshmukh",
            name = "डॉ. सुनील देशमुख (PhD)",
            degree = "PhD (Plant Pathology) NRC Grapes",
            specialtyMr = "द्राक्ष रोग व ग्लोबल गॅप (GlobalGAP) युरोप निर्यात",
            specialtyEn = "Grapes & Disease Expert",
            locationMr = "पिंपळगाव बसवंत, नाशिक",
            experience = "१८ वर्षे अनुभव",
            phone = "9422789102",
            rating = 4.95,
            isAvailable = true,
            avatar = "🍇"
        ),
        DoctorExpert(
            id = "dr_ramesh_patil",
            name = "डॉ. रमेश पाटील (MSc Agri)",
            degree = "MSc (Agronomy) VSI पुणे",
            specialtyMr = "ऊस उत्पादन तंत्रज्ञान - १५०+ टन एकरी फॉर्म्युला",
            specialtyEn = "Sugarcane Specialist",
            locationMr = "इंदापूर - बारामती पट्टा",
            experience = "१६ वर्षे अनुभव (VSI गोल्ड मेडलिस्ट)",
            phone = "9158674204",
            rating = 4.9,
            isAvailable = true,
            avatar = "🎋"
        )
    )

    val equipmentList = listOf(
        FarmingEquipment(
            id = "eq_1",
            nameMr = "महिंद्रा ५७५ DI XP Plus ट्रॅक्टर",
            nameEn = "Mahindra 575 DI XP Plus (47 HP)",
            category = "tractor",
            listingType = "rent",
            condition = "used_good",
            brand = "Mahindra",
            hp = "47 HP",
            rentPerHour = 650,
            rentPerAcre = 1100,
            ownerName = "बाळासाहेब पाटील",
            phone = "9822456789",
            village = "निमसाखर",
            taluka = "इंदापूर",
            district = "पुणे",
            availability = "available_now",
            imageEmoji = "🚜",
            rating = 4.9,
            badgeMr = "रोटाव्हेटरसह उपलब्ध",
            badgeEn = "With Rotavator",
            fuelIncluded = false,
            driverIncluded = true,
            notesMr = "रोटाव्हेटर व २-बॉटम नांगर सोबत उपलब्ध आहे. ऑपरेटर अनुभवी आहे."
        ),
        FarmingEquipment(
            id = "eq_2",
            nameMr = "अ‍ॅग्रीकल्चरल स्प्रेईंग १०L ॲग्री ड्रोन",
            nameEn = "10L Smart Spraying Agri Drone",
            category = "drone",
            listingType = "rent",
            condition = "new",
            brand = "Garuda Aerospace",
            rentPerAcre = 350,
            ownerName = "अमोल शिंदे (प्रमाणित ड्रोन पायलट)",
            phone = "9403125478",
            village = "पिंपळगाव बसवंत",
            taluka = "निफाड",
            district = "नाशिक",
            availability = "available_now",
            imageEmoji = "🛸",
            rating = 4.95,
            badgeMr = "१० मिनिटांत १ एकर फवारणी",
            badgeEn = "10 Mins / Acre",
            fuelIncluded = true,
            driverIncluded = true,
            notesMr = "द्राक्ष, कांदा व डाळिंब बागेत ९०% पाण्याची बचत व १००% अचूक फवारणी."
        ),
        FarmingEquipment(
            id = "eq_3",
            nameMr = "शक्तीमान रोटाव्हेटर (७ फूट)",
            nameEn = "Shaktiman Regular Light 7ft Rotavator",
            category = "rotavator",
            listingType = "both",
            condition = "used_good",
            brand = "Shaktiman",
            rentPerHour = 400,
            sellingPrice = 78000,
            ownerName = "दीपक जाधव",
            phone = "9763214589",
            village = "राहुरी",
            taluka = "राहुरी",
            district = "अहिल्यानगर (अहमदनगर)",
            availability = "available_now",
            imageEmoji = "⚙️",
            rating = 4.8,
            badgeMr = "विक्री / भाडे दोन्ही",
            badgeEn = "Rent or Buy",
            driverIncluded = false
        )
    )

    val progressiveFarmers = listOf(
        ProgressiveFarmerStory(
            id = "pf_1",
            farmerName = "दत्तात्रय तुकाराम कदम",
            village = "शेळगाव (इंदापूर)",
            taluka = "इंदापूर",
            district = "पुणे",
            region = "paschim",
            mainCropMr = "G9 टिशू कल्चर केळी (थेट दुबई निर्यात)",
            mainCropEn = "G9 Tissue Culture Banana",
            variety = "Grand Naine (G9)",
            acres = 8.5,
            cropYieldRecordMr = "४२ किलो सरासरी घड वजन (४० टन / एकर विक्रमी उत्पादन)",
            cropYieldRecordEn = "42 kg avg bunch, 40 Tons/Acre record",
            netProfitPerAcreMr = "₹३,८०,००० / एकर निव्वळ नफा",
            netProfitPerAcreEn = "₹3,80,000 / Acre Net Profit",
            bestFarmingTechniquesMr = listOf(
                "६ × ६ फूट अंतर व दुहेरी इनलाईन ठिबक (Inline Drip)",
                "केळीच्या घडाला ३५ मायक्रॉन ब्लू स्कर्टिंग बॅग कव्हरिंग",
                "महिन्यातून दोन वेळा जीवामृत व स्लरी व्हेंच्युरीद्वारे देणे",
                "दुबई निर्यातदारांशी थेट करार (₹१३५/बॉक्स हमीभाव)"
            ),
            bestFarmingTechniquesEn = listOf(
                "6x6 ft spacing with double inline drip",
                "35 micron blue skirting bunch covering",
                "Bi-monthly Jivamrut slurry fertigation",
                "Direct Dubai export forward contract"
            ),
            produceForSale = listOf(
                ProduceForSale("G9 एक्सपोर्ट ग्रेड केळी घड", "Export Grade Banana", "२५ टन तयार", "₹१३५ / बॉक्स (१३ kg)", "A+ दुबई ग्रेड")
            ),
            phone = "9822987410",
            whatsapp = "9822987410",
            avatarEmoji = "🍌",
            experienceYears = 14,
            awardsMr = "महाराष्ट्र शासन 'कृषी भूषण' २०२३",
            awardsEn = "Maha Govt Krishi Bhushan 2023",
            storyQuoteMr = "पारंपारिक शेती सोडून आधुनिक बॅगिंग व ठिबक तंत्रज्ञान वापरल्यास केळी सोन्यासारखा नफा देते!",
            storyQuoteEn = "Switching from flood irrigation to drip & bagging makes banana farming gold!"
        ),
        ProgressiveFarmerStory(
            id = "pf_2",
            farmerName = "प्रशांत विलासराव पाटील",
            village = "बावची (इस्लामपूर)",
            taluka = "वाळवा",
            district = "सांगली",
            region = "paschim",
            mainCropMr = "ऊस (Co-86032) विक्रमी १५२ टन / एकर",
            mainCropEn = "Sugarcane (Co-86032)",
            variety = "Co-86032 (Nira)",
            acres = 12.0,
            cropYieldRecordMr = "१५२.४ टन / एकर (VSI राज्यस्तरीय प्रथम पुरस्कार)",
            cropYieldRecordEn = "152.4 Tons/Acre (VSI 1st Award)",
            netProfitPerAcreMr = "₹३,२०,००० / एकर निव्वळ नफा",
            netProfitPerAcreEn = "₹3,20,000 / Acre Net Profit",
            bestFarmingTechniquesMr = listOf(
                "५ फूट पट्टा पद्धत (Single Eye Bud Planting)",
                "ऊस पाचट न जाळता मल्चिंग व कुजवणारे जिवाणू वापर",
                "पाचव्या महिन्यात बाळ बांधणी व आठव्या महिन्यात मोठी बांधणी",
                "पोटॅश व सिलिकॉनची योग्य पानांवरील फवारणी"
            ),
            bestFarmingTechniquesEn = listOf(
                "5-feet paired row single eye bud planting",
                "Trash mulching with decomposing bacteria",
                "Timely earthing up at 5th and 8th months",
                "Foliar spray of Potassium & Silicon"
            ),
            produceForSale = listOf(
                ProduceForSale("Co-86032 शुद्ध एक डोळा बेणे रोपे", "Pure Single Bud Seedlings", "५०,००० रोपे", "₹२.५० / रोप", "VSI प्रमाणित")
            ),
            phone = "9422014589",
            whatsapp = "9422014589",
            avatarEmoji = "🎋",
            experienceYears = 18,
            awardsMr = "वसंतदादा शुगर इन्स्टिट्यूट ऊस भूषण २०२४",
            awardsEn = "VSI Sugarcane Bhushan 2024",
            storyQuoteMr = "पाचट जाळणे बंद करा; जमिनीचा सेंद्रिय कर्ब १% वर नेल्यास १५० टन ऊस सहज निघतो!",
            storyQuoteEn = "Stop burning trash; raise soil organic carbon to 1% to hit 150 Tons sugarcane!"
        )
    )

    val mandiRates = listOf(
        LiveMandiRate("इंदापूर / बारामती", "केळी (G9)", 1400, 2200, 1850, "up"),
        LiveMandiRate("पिंपळगाव (नाशिक)", "द्राक्ष (सोनाका)", 6500, 12000, 9200, "up"),
        LiveMandiRate("लासलगाव (नाशिक)", "उन्हाळी कांदा", 1300, 2450, 1950, "stable"),
        LiveMandiRate("सोलापूर APMC", "डाळिंब (भगवा)", 8000, 18500, 14000, "up"),
        LiveMandiRate("अकोला APMC", "कापूस (मध्यम धागा)", 6800, 7650, 7200, "down"),
        LiveMandiRate("लातूर APMC", "सोयाबीन (पिवळा)", 4100, 4750, 4420, "stable")
    )

    val yojanaList = listOf(
        SarkariYojana(
            id = "pm_kusum_solar",
            nameMr = "पीएम-कुसुम सौर कृषी पंप योजना (९०% अनुदान)",
            nameEn = "PM-KUSUM Solar Agri Pump (90% Subsidy)",
            benefitMr = "३ HP, ५ HP व ७.५ HP सौर पंप ९०% अनुदानावर (शेतकऱ्याला फक्त १०% भरायचे)",
            categoryMr = "सौर ऊर्जा व सिंचन",
            subsidyTag = "९०% थेट सरकारी अनुदान",
            descriptionMr = "शेतकऱ्यांना दिवसा खात्रीशीर मोफत वीज मिळण्यासाठी केंद्र व महाराष्ट्र शासनाची संयुक्त योजना. ३ ते ७.५ एचपी सौर पंप थेट शेतात बसवून दिला जातो.",
            eligibilityMr = listOf(
                "शेतकऱ्याच्या नावावर ७/१२ व ८-अ उतारा असावा",
                "शेतात विहीर, कूपनलिका (बोअरवेल) किंवा शेततळे पाण्याचा स्त्रोत असावा",
                "पारंपारिक विजेचे कनेक्शन नसलेले शेतकरी प्रथम प्राधान्य"
            ),
            documentsMr = listOf("७/१२ व ८-अ उतारा", "आधार कार्ड", "बँक पासबुक झेरॉक्स", "पाण्याचा स्त्रोत स्वयंघोषणापत्र"),
            applyLink = "https://www.mahadiscom.in/solar_mskvy/index_mr.html",
            videoMinutes = "४ मिनिटे"
        ),
        SarkariYojana(
            id = "namo_shetkari",
            nameMr = "नमो शेतकरी महासन्मान निधी योजना",
            nameEn = "Namo Shetkari Maha Samman Nidhi",
            benefitMr = "वार्षिक ₹६,००० थेट बँक खात्यात (PM किसान चे ₹६,००० + नमो शेतकरी चे ₹६,००० = एकूण ₹१२,०००)",
            categoryMr = "थेट आर्थिक मदत",
            subsidyTag = "दर ४ महिन्यांनी ₹२,००० हप्ता",
            descriptionMr = "महाराष्ट्र शासनाकडून PM-KISAN पात्र शेतकऱ्यांना वर्षाला अतिरिक्त ₹६,००० दिले जातात. एकूण दरवर्षी ₹१२,००० थेट DBT द्वारे खात्यात जमा होतात.",
            eligibilityMr = listOf(
                "PM किसान योजनेचे पात्र लाभार्थी असावेत",
                "आधार ई-केवायसी (e-KYC) पूर्ण असावे",
                "बँक खाते आधार लिंक (NPCI Active) असणे आवश्यक"
            ),
            documentsMr = listOf("आधार कार्ड", "PM किसान रजिस्ट्रेशन नंबर", "आधार लिंक बँक खाते"),
            applyLink = "https://mahadbt.maharashtra.gov.in/",
            videoMinutes = "३ मिनिटे"
        )
    )

    val sugarKarkhanas = listOf(
        SugarKarkhana("k1", "कर्मयोगी शंकरराव पाटील सहकारी साखर कारखाना", "इंदापूर (पुणे)", 3250, 14, 150, "४.९ ★", true),
        SugarKarkhana("k2", "छत्रपती सहकारी साखर कारखाना", "भवानीनगर (इंदापूर)", 3180, 15, 120, "४.८ ★", false),
        SugarKarkhana("k3", "सोमेश्वर सहकारी साखर कारखाना", "सोमेश्वरनगर (बारामती)", 3420, 10, 200, "५.० ★", true),
        SugarKarkhana("k4", "विठ्ठलराव शिंदे सहकारी साखर कारखाना", "माढा (सोलापूर)", 3310, 14, 140, "४.९ ★", false)
    )

    val jodDhandaItems = listOf(
        JodDhandaItem(
            id = "dairy",
            titleMr = "एचएफ / गिर गाय दुग्धव्यवसाय (Smart Dairy)",
            titleEn = "High Yield Dairy Farm",
            iconEmoji = "🐄",
            monthlyIncome = "₹५०,००० ते ₹१,२०,००० / महिना (१० गायी)",
            setupCost = "₹३.५ ते ६ लाख",
            loanScheme = "नाबार्ड (NABARD) डेअरी व्हेंचर कॅपिटल स्कीम",
            subsidyPercent = "२५% ते ३३.३% अनुदान",
            stepsMr = listOf(
                "चांगल्या वंशावळीची (HF/गिर) २०+ लिटर देणारी जनावरे निवडणे",
                "मुक्त संचार गोठा पद्धत (Loose Housing) वापरणे",
                "मका सायलेज (Silage) मुरघास व हायड्रॉपोनिक्स हिरवा चारा"
            ),
            marketTips = "स्थानिक डेअरी ऐवजी शहरात 'A2 गिर मिल्क' पॅक करून विकल्यास ₹७० ते ८० / लिटर दर मिळतो."
        ),
        JodDhandaItem(
            id = "goat",
            titleMr = "उस्मानाबादी / बोअर शेळीपालन (बंदिस्त पद्धत)",
            titleEn = "Stall Fed Goat Farming",
            iconEmoji = "🐐",
            monthlyIncome = "₹४०,००० ते ₹८०,००० / महिना (२० शेळ्या + १ बोकड)",
            setupCost = "₹२ ते ३ लाख",
            loanScheme = "अहिल्यादेवी होळकर शेळी मेंढी विकास महामंडळ",
            subsidyPercent = "५०% ते ७५% अनुदान",
            stepsMr = listOf(
                "उस्मानाबादी किंवा सिरोही जातीची २ वर्षात २ वेळा विणारी जात निवडणे",
                "उंचावरचा जाळीदार शेड (Slatted Floor) तयार करणे",
                "दसरा, दिवाळी व ईद हंगामात वजनानुसार विक्री करणे"
            ),
            marketTips = "बोकड जिवंत वजनावर ₹३५० ते ४५० / किलो दराने विकल्यास दुप्पट नफा मिळतो."
        )
    )
}
