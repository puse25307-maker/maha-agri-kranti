import React, { useState } from 'react';
import { 
  Camera, 
  ShoppingBag, 
  Landmark, 
  Factory, 
  Sprout, 
  TrendingUp, 
  PhoneCall, 
  ArrowRight, 
  Leaf, 
  Sun,
  Droplets,
  Sparkles,
  Award,
  ChevronRight,
  ShieldCheck,
  Zap,
  Globe2,
  Tractor
} from 'lucide-react';
import { Language, TabType } from '../types';
import { speakText } from '../utils/speech';

interface TabHomeProps {
  lang: Language;
  onNavigate: (tab: TabType) => void;
}

export const TabHome: React.FC<TabHomeProps> = ({ lang, onNavigate }) => {
  const [callAlert, setCallAlert] = useState<string | null>(null);

  const quickActions = [
    {
      id: 'rog_doctor' as TabType,
      titleMr: 'रोग डॉक्टर AI',
      titleEn: 'Crop Doctor AI',
      descMr: 'पानाचा फोटो काढून ९५% अचूक रोग व औषध उपाय ओळखा',
      descEn: 'Instant 95% leaf disease detection & spray dosage',
      icon: Camera,
      badgeMr: 'कॅमेरा स्कॅन',
      badgeEn: 'AI Scan',
      gradient: 'from-emerald-500/10 to-emerald-700/10 border-emerald-300/80',
      iconBg: 'bg-emerald-600 text-white',
      accentColor: 'text-emerald-800'
    },
    {
      id: 'sustainable' as TabType,
      titleMr: 'शाश्वत विकास',
      titleEn: 'Sustainable Agri',
      descMr: 'सौर पंप ९०% अनुदान, ठिबक पाणी बचत व सेंद्रिय शेती',
      descEn: 'Solar pumps 90% subsidy, drip saving & green carbon',
      icon: Leaf,
      badgeMr: 'SDG हरित शेती',
      badgeEn: 'Eco Green',
      gradient: 'from-amber-500/10 to-teal-500/10 border-teal-300/80',
      iconBg: 'bg-teal-700 text-amber-300',
      accentColor: 'text-teal-900'
    },
    {
      id: 'maha_bazaar' as TabType,
      titleMr: 'महा बाजार भाव',
      titleEn: 'Maha Mandi Rates',
      descMr: 'थेट शेतकरी दर, APMC बाजारभाव व थेट विक्री',
      descEn: 'Live APMC rates & direct buyer connect',
      icon: ShoppingBag,
      badgeMr: 'आजचे दर',
      badgeEn: 'Live Rates',
      gradient: 'from-amber-500/10 to-orange-500/10 border-amber-300/80',
      iconBg: 'bg-amber-600 text-white',
      accentColor: 'text-amber-900'
    },
    {
      id: 'yojana' as TabType,
      titleMr: 'सरकारी योजना',
      titleEn: 'Govt Schemes',
      descMr: 'नमो शेतकरी, पिक विमा, ट्रॅक्टर व सौर पंप अनुदान',
      descEn: 'Namo Shetkari, crop insurance & subsidies',
      icon: Landmark,
      badgeMr: '१००% अनुदान',
      badgeEn: '100% Subsidy',
      gradient: 'from-blue-500/10 to-indigo-500/10 border-blue-300/80',
      iconBg: 'bg-blue-700 text-white',
      accentColor: 'text-blue-900'
    }
  ];

  const handleCallDoctor = () => {
    const textMr = 'कृषी तज्ज्ञ डॉ. विलास शिंदे, नाशिक यांच्याशी संपर्क जोडला जात आहे.';
    const textEn = 'Connecting to Senior Agri Expert Dr. Vilas Shinde, Nashik.';
    
    setCallAlert(lang === 'mr' ? `📞 ${textMr}` : `📞 ${textEn}`);
    speakText(lang === 'mr' ? textMr : textEn, lang);
    setTimeout(() => setCallAlert(null), 4000);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Toast Alert */}
      {callAlert && (
        <div className="bg-emerald-950 text-white text-xs p-3.5 rounded-2xl shadow-xl flex items-center gap-2 border border-emerald-500 animate-fade-in">
          <PhoneCall className="w-4 h-4 text-amber-300 animate-bounce shrink-0" />
          <span className="font-bold">{callAlert}</span>
        </div>
      )}

      {/* Welcoming Gradient Hero Card */}
      <div className="bg-gradient-to-br from-[#104716] via-[#1B5E20] to-[#0A3810] text-white p-4.5 rounded-3xl shadow-lg relative overflow-hidden border border-emerald-500/30">
        <div className="absolute top-0 right-0 -mr-8 -mt-8 w-36 h-36 bg-amber-400/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-8 -mb-8 w-36 h-36 bg-emerald-400/20 rounded-full blur-3xl pointer-events-none" />

        <div className="flex justify-between items-start relative z-10">
          <div>
            <div className="flex items-center gap-1.5 flex-wrap mb-2">
              <span className="inline-flex items-center gap-1 bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 text-[10px] font-black px-2.5 py-0.5 rounded-full shadow-sm uppercase tracking-wide">
                🌱 {lang === 'mr' ? 'शाश्वत व आधुनिक कृषी' : 'Sustainable & Smart Agri'}
              </span>
              <span className="inline-flex items-center gap-1 bg-amber-500/25 border border-amber-400/50 text-amber-300 text-[10px] font-black px-2.5 py-0.5 rounded-full shadow-sm">
                🚩 {lang === 'mr' ? 'जय महाराष्ट्र' : 'Jai Maharashtra'}
              </span>
            </div>
            <h2 className="text-xl font-black text-white leading-tight">
              {lang === 'mr' ? 'नमस्कार शेतकरी मित्र! 🙏' : 'Hello Farmer Friend! 🙏'}
            </h2>
            <p className="text-xs text-emerald-100/90 mt-1 max-w-[270px]">
              {lang === 'mr' 
                ? 'रोग निदान, शाश्वत हरित शेती, थेट बाजारभाव आणि शासकीय योजना एकाच ठिकाणी.'
                : 'Disease diagnosis, sustainable eco-farming, direct mandi rates & government schemes in one place.'}
            </p>
          </div>
          <div className="w-13 h-13 rounded-2xl bg-white/15 border border-white/20 backdrop-blur-md flex items-center justify-center text-3xl shadow-md shrink-0">
            🌾
          </div>
        </div>

        {/* Primary CTA Buttons (Leaf AI Scan + Sustainable Agri) */}
        <div className="grid grid-cols-2 gap-2 mt-4 relative z-10">
          <button
            onClick={() => onNavigate('rog_doctor')}
            className="bg-white hover:bg-emerald-50 text-[#1B5E20] font-black py-2.5 px-3 rounded-2xl text-xs flex items-center justify-between shadow-md active:scale-[0.98] transition-all border border-white"
          >
            <div className="flex items-center gap-1.5 truncate">
              <Camera className="w-4 h-4 text-[#1B5E20] shrink-0" />
              <span className="truncate">{lang === 'mr' ? 'पानाचा रोग तपासा' : 'Leaf AI Scan'}</span>
            </div>
            <ArrowRight className="w-3.5 h-3.5 text-[#1B5E20] shrink-0" />
          </button>

          <button
            onClick={() => onNavigate('sustainable')}
            className="bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-black py-2.5 px-3 rounded-2xl text-xs flex items-center justify-between shadow-md active:scale-[0.98] transition-all border border-amber-300"
          >
            <div className="flex items-center gap-1.5 truncate">
              <Leaf className="w-4 h-4 text-emerald-950 shrink-0" />
              <span className="truncate">{lang === 'mr' ? 'शाश्वत शेती' : 'Green Farming'}</span>
            </div>
            <ArrowRight className="w-3.5 h-3.5 text-slate-950 shrink-0" />
          </button>
        </div>
      </div>

      {/* Sustainable Development (शाश्वत विकास) Spotlight Card */}
      <div 
        onClick={() => onNavigate('sustainable')}
        className="bg-gradient-to-r from-teal-900 via-emerald-900 to-[#104716] text-white p-3.5 rounded-3xl shadow-md border border-teal-500/40 relative overflow-hidden cursor-pointer hover:brightness-105 transition-all group"
      >
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-black shadow-sm">
              <Sun className="w-4 h-4" />
            </div>
            <div>
              <span className="bg-white/20 text-emerald-100 text-[9px] font-black px-2 py-0.2 rounded-full uppercase">
                {lang === 'mr' ? 'पर्यावरणपूरक शेती' : 'Eco-Friendly Farming'}
              </span>
              <h3 className="text-xs font-black text-white leading-tight mt-0.5">
                {lang === 'mr' ? 'शाश्वत विकास केंद्र (Sustainable Hub)' : 'Sustainable Agri & Carbon Credits'}
              </h3>
            </div>
          </div>
          <span className="text-[10px] bg-amber-400 text-slate-950 font-black px-2 py-0.5 rounded-full shadow-sm">
            {lang === 'mr' ? '९०% अनुदान' : '90% Subsidy'}
          </span>
        </div>

        <p className="text-[11px] text-emerald-100/90 leading-snug">
          {lang === 'mr'
            ? 'पीएम-कुसुम सौर पंप, ठिबक पाणी बचत, सेंद्रिय जीवामृत व कार्बन क्रेडिट्स द्वारे अधिक नफा मिळवा.'
            : 'Explore PM-KUSUM solar pumps, 60% drip water savings, residue-free Jivamrut & carbon revenues.'}
        </p>

        <div className="mt-2.5 pt-2 border-t border-white/15 flex items-center justify-between text-xs font-bold text-amber-300">
          <div className="flex items-center gap-3 text-[10px] text-emerald-200">
            <span>☀️ सौर ऊर्जा</span>
            <span>💧 ठिबक सिंचन</span>
            <span>🌱 सेंद्रिय खत</span>
          </div>
          <span className="flex items-center gap-1 group-hover:translate-x-1 transition-transform">
            {lang === 'mr' ? 'पहा' : 'Explore'} <ChevronRight className="w-3.5 h-3.5" />
          </span>
        </div>
      </div>

      {/* Equipment Rental/Sale & Progressive Farmers Spotlight Duo */}
      <div className="grid grid-cols-2 gap-2.5">
        {/* Farming Equipment Hub */}
        <div
          onClick={() => onNavigate('equipment')}
          className="bg-gradient-to-br from-amber-500/15 via-orange-500/10 to-amber-100/40 p-3 rounded-3xl border-2 border-amber-300 shadow-sm cursor-pointer hover:shadow-md transition-all active:scale-[0.98] flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="w-8 h-8 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-black shadow-sm">
                <Tractor className="w-4 h-4" />
              </div>
              <span className="text-[9px] font-black bg-amber-200 text-amber-950 px-1.5 py-0.5 rounded-md">
                {lang === 'mr' ? 'भाडे / विक्री' : 'Rent / Sale'}
              </span>
            </div>
            <h4 className="font-black text-xs text-slate-900 leading-tight">
              {lang === 'mr' ? 'कृषी अवजारे हब' : 'Equipment Hub'}
            </h4>
            <p className="text-[10px] text-slate-600 mt-1 leading-snug">
              {lang === 'mr' ? 'ट्रॅक्टर, ड्रोन व हार्वेस्टर भाड्याने मिळवा किंवा विका' : 'Rent/sell tractors, drones & harvesters'}
            </p>
          </div>
          <div className="mt-2.5 pt-2 border-t border-amber-200/80 flex items-center justify-between text-[10px] font-black text-amber-900">
            <span>{lang === 'mr' ? 'अवजारे शोधा' : 'Browse'}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </div>
        </div>

        {/* Progressive Farmers Stories & Crops */}
        <div
          onClick={() => onNavigate('progressive_farmers')}
          className="bg-gradient-to-br from-emerald-500/15 via-teal-500/10 to-emerald-100/40 p-3 rounded-3xl border-2 border-emerald-300 shadow-sm cursor-pointer hover:shadow-md transition-all active:scale-[0.98] flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="w-8 h-8 rounded-xl bg-[#1B5E20] text-amber-300 flex items-center justify-center font-black shadow-sm">
                <Award className="w-4 h-4" />
              </div>
              <span className="text-[9px] font-black bg-emerald-200 text-emerald-950 px-1.5 py-0.5 rounded-md">
                {lang === 'mr' ? 'टॉप शेतकरी' : 'Top Farmers'}
              </span>
            </div>
            <h4 className="font-black text-xs text-slate-900 leading-tight">
              {lang === 'mr' ? 'प्रगतशील शेतकरी' : 'Top Farmers & Crops'}
            </h4>
            <p className="text-[10px] text-slate-600 mt-1 leading-snug">
              {lang === 'mr' ? 'कोणती पिके घेतात? विक्रमी नफा व थेट माल खरेदी' : 'Crop records, best secrets & direct buy'}
            </p>
          </div>
          <div className="mt-2.5 pt-2 border-t border-emerald-200/80 flex items-center justify-between text-[10px] font-black text-[#1B5E20]">
            <span>{lang === 'mr' ? 'माहिती पहा' : 'View Stories'}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </div>
        </div>
      </div>

      {/* Main 4 Quick Action Cards */}
      <div>
        <div className="flex items-center justify-between mb-2 px-1">
          <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            {lang === 'mr' ? 'महत्त्वाच्या कृषी सेवा' : 'Key Agri Services'}
          </h3>
          <button
            onClick={() => onNavigate('menu')}
            className="text-[11px] font-bold text-emerald-800 hover:text-emerald-950 flex items-center gap-0.5"
          >
            {lang === 'mr' ? 'सर्व मेनू' : 'All Menu'} <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          {quickActions.map((action) => {
            const Icon = action.icon;
            return (
              <button
                key={action.id}
                onClick={() => onNavigate(action.id)}
                className={`p-3.5 rounded-3xl text-left border shadow-sm transition-all active:scale-[0.98] bg-white hover:shadow-md ${action.gradient} flex flex-col justify-between`}
              >
                <div>
                  <div className="flex justify-between items-center mb-2.5">
                    <div className={`p-2.5 rounded-2xl shadow-sm ${action.iconBg}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className="text-[9px] font-black bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full border border-slate-200">
                      {lang === 'mr' ? action.badgeMr : action.badgeEn}
                    </span>
                  </div>
                  <h4 className="font-black text-xs text-slate-900 leading-tight">
                    {lang === 'mr' ? action.titleMr : action.titleEn}
                  </h4>
                  <p className="text-[10px] text-slate-500 mt-1 leading-snug line-clamp-2">
                    {lang === 'mr' ? action.descMr : action.descEn}
                  </p>
                </div>
                <div className={`mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] font-black ${action.accentColor}`}>
                  <span>{lang === 'mr' ? 'उघडा' : 'Open'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Live Market Highlights */}
      <div className="bg-white p-4 rounded-3xl shadow-sm border border-slate-200/80 space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <TrendingUp className="w-4 h-4 text-emerald-700" />
            <h3 className="text-xs font-black text-slate-900">
              {lang === 'mr' ? 'आजचे प्रमुख बाजारभाव (Live Mandi)' : 'Today\'s Mandi Highlights'}
            </h3>
          </div>
          <button
            onClick={() => onNavigate('maha_bazaar')}
            className="text-[11px] font-bold text-emerald-800"
          >
            {lang === 'mr' ? 'सर्व बाजारभाव →' : 'All Rates →'}
          </button>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between items-center p-2.5 rounded-2xl bg-gradient-to-r from-amber-50/60 to-emerald-50/60 border border-amber-200/60 text-xs">
            <div className="flex items-center gap-2.5">
              <span className="text-2xl">🍌</span>
              <div>
                <span className="font-black text-slate-900 block leading-tight">
                  {lang === 'mr' ? 'केळी (G9 Grand Naine)' : 'Banana (G9 Grand Naine)'}
                </span>
                <span className="text-[10px] text-slate-500">
                  {lang === 'mr' ? 'इंदापूर / जळगाव थेट निर्यात' : 'Indapur / Jalgaon Direct Export'}
                </span>
              </div>
            </div>
            <div className="text-right">
              <span className="font-black text-emerald-900 block text-xs">₹१२५ / kg</span>
              <span className="text-[10px] text-emerald-700 font-bold bg-emerald-100 px-1.5 py-0.2 rounded">
                {lang === 'mr' ? 'दुबई थेट मागणी' : 'Dubai Export'}
              </span>
            </div>
          </div>

          <div className="flex justify-between items-center p-2.5 rounded-2xl bg-gradient-to-r from-purple-50/60 to-indigo-50/60 border border-purple-200/60 text-xs">
            <div className="flex items-center gap-2.5">
              <span className="text-2xl">🍇</span>
              <div>
                <span className="font-black text-slate-900 block leading-tight">
                  {lang === 'mr' ? 'द्राक्षे (सोनाका / थॉम्सन)' : 'Grapes (Sonaka / Thomson)'}
                </span>
                <span className="text-[10px] text-slate-500">
                  {lang === 'mr' ? 'पिंपळगाव APMC नाशिक' : 'Pimpalgaon APMC Nashik'}
                </span>
              </div>
            </div>
            <div className="text-right">
              <span className="font-black text-indigo-900 block text-xs">₹१२० / kg</span>
              <span className="text-[10px] text-indigo-700 font-bold bg-indigo-100 px-1.5 py-0.2 rounded">
                {lang === 'mr' ? 'उच्चांकी दर' : 'Peak Rate'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Free Doctor Helpline Banner */}
      <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-100 border border-emerald-200 p-4 rounded-3xl flex items-center justify-between gap-3 shadow-sm">
        <div className="space-y-0.5">
          <span className="text-[10px] font-black text-emerald-800 uppercase tracking-wide block">
            👨‍⚕️ {lang === 'mr' ? 'मोफत कृषी तज्ज्ञ सल्ला' : 'Free Agri Expert Consultation'}
          </span>
          <h4 className="text-xs font-black text-slate-900 leading-tight">
            {lang === 'mr' ? 'पिकांवरील समस्या? तज्ज्ञांना थेट विचारा' : 'Crop problems? Consult our experts'}
          </h4>
          <p className="text-[11px] text-slate-600">
            {lang === 'mr' ? 'विनामूल्य फोन मार्गदर्शन व अचूक फवारणी सल्ला' : 'Zero cost instant telephonic guidance'}
          </p>
        </div>
        <button
          onClick={handleCallDoctor}
          className="bg-[#1B5E20] hover:bg-emerald-900 text-white font-black px-3.5 py-2.5 rounded-2xl text-xs flex items-center gap-1.5 shadow-sm shrink-0 active:scale-95 transition-all"
        >
          <PhoneCall className="w-3.5 h-3.5 text-amber-300" />
          <span>{lang === 'mr' ? 'कॉल करा' : 'Call Free'}</span>
        </button>
      </div>
    </div>
  );
};

