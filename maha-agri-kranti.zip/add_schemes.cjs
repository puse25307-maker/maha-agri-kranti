const fs = require('fs');

let content = fs.readFileSync('src/data/agriData.ts', 'utf8');

const newSchemes = `
  {
    id: 'loan_waiver_mjpsky',
    nameMr: '१. महात्मा जोतीराव फुले शेतकरी कर्जमुक्ती योजना',
    nameEn: 'Mahatma Jyotirao Phule Farmer Loan Waiver',
    benefitMr: '₹२ लाख पर्यंतचे थकीत पीक कर्ज १००% माफ',
    categoryMr: 'शेतकरी कर्जमाफी',
    subsidyTag: '१००% कर्जमाफी',
    descriptionMr: 'शेतकऱ्यांचे २ लाख रुपयांपर्यंतचे थकीत पीक कर्ज माफ करण्यासाठी ही योजना शासनाने लागू केली आहे. नैसर्गिक आपत्ती व नापिकीमुळे कर्जबाजारी झालेल्या शेतकऱ्यांना दिलासा देण्यासाठी ही कर्जमाफी दिली जात आहे.',
    eligibilityMr: ['ज्या शेतकऱ्यांकडे २ लाख रुपयांपर्यंतचे थकीत पीक कर्ज आहे.', 'राष्ट्रीयकृत, जिल्हा मध्यवर्ती किंवा विकास कार्यकारी सेवा सहकारी संस्था (पतसंस्था) मधील कर्ज.'],
    documentsMr: ['आधार कार्ड बँक खात्याशी लिंक असणे', 'कर्ज खात्याचे विवरण', 'ई-केवायसी (eKYC) बायोमेट्रिक प्रमाणीकरण'],
    applyLink: 'https://mjpsky.maharashtra.gov.in',
    videoMinutes: '५ मिनिट'
  },
  {
    id: 'pacs_incentive',
    nameMr: '२. शेतकरी पतसंस्था (PACS) - ५० हजार रुपये प्रोत्साहनपर अनुदान योजना',
    nameEn: 'PACS Regular Loan Repayment Incentive Scheme',
    benefitMr: 'नियमित कर्ज परतफेड करणाऱ्यांना ५० हजार रुपये प्रोत्साहन अनुदान',
    categoryMr: 'पतसंस्था व प्रोत्साहनपर लाभ',
    subsidyTag: '₹५०,००० अनुदान',
    descriptionMr: 'ज्या शेतकऱ्यांनी प्राथमिक कृषी पतपुरवठा सहकारी संस्था (पतसंस्था) किंवा बँकांकडून घेतलेल्या पीक कर्जाची सलग ३ वर्षे नियमित परतफेड केली आहे, त्यांना प्रोत्साहन म्हणून ५० हजार रुपयांचे अनुदान थेट बँक खात्यात दिले जाते.',
    eligibilityMr: ['मागील ३ वर्षांत २ वर्षे तरी पीक कर्जाची नियमित परतफेड केलेली असावी.', 'शेतकरी विविध कार्यकारी सेवा सहकारी संस्था (PACS) किंवा बँकेचा सभासद असावा.'],
    documentsMr: ['आधार कार्ड', '७/१२ आणि ८-अ उतारा', 'पतसंस्था/बँकेचे बेबाकी (No Dues) प्रमाणपत्र / कर्ज परतफेड पावती'],
    applyLink: 'https://mjpsky.maharashtra.gov.in',
    videoMinutes: '४ मिनिट'
  },
`;

content = content.replace(
  /export const SARKARI_YOJANA_LIST: SarkariYojana\[\] = \[/,
  `export const SARKARI_YOJANA_LIST: SarkariYojana[] = [\n${newSchemes}`
);

// Renumber the existing ones 
content = content.replace('१. पीएम किसान', '३. पीएम किसान');
content = content.replace('२. महाडीबीटी', '४. महाडीबीटी');
content = content.replace('३. १ रुपयात', '५. १ रुपयात');
content = content.replace('४. किसान क्रेडिट', '६. किसान क्रेडिट');
content = content.replace('५. अपेडा', '७. अपेडा');

fs.writeFileSync('src/data/agriData.ts', content);
