import React, { useState } from 'react';
import { 
  Factory, 
  Users, 
  FileCheck, 
  PhoneCall, 
  Send, 
  Calendar, 
  CheckCircle2, 
  Sparkles, 
  TrendingUp, 
  Receipt,
  X,
  Volume2
} from 'lucide-react';
import { SUGAR_KARKHANE, FRUIT_PROCESSING_KARKHANE } from '../data/agriData';
import { SugarKarkhana, ProcessingKarkhana } from '../types';
import { speakMarathi } from '../utils/speech';

export const Tab5UsBelt: React.FC = () => {
  // Form 1 State
  const [tons, setTons] = useState<number>(50);
  const [selectedKarkhanaId, setSelectedKarkhanaId] = useState<string>('malegaon');
  const [farmerName, setFarmerName] = useState<string>('सचिन दत्तात्रय पाटील');
  const [farmerAadhar, setFarmerAadhar] = useState<string>('८५४२-xxxx-१२०४');
  const [caneSlipReceipt, setCaneSlipReceipt] = useState<any | null>(null);

  // Form 2 State (Labor booking)
  const [laborCount, setLaborCount] = useState<number>(15);
  const [laborDays, setLaborDays] = useState<number>(2);
  const [laborWage, setLaborWage] = useState<number>(500);
  const [bookingDate, setBookingDate] = useState<string>('२०२६-०९-०१');
  const [laborBookedSuccess, setLaborBookedSuccess] = useState<string | null>(null);

  const selectedKarkhana = SUGAR_KARKHANE.find((k) => k.id === selectedKarkhanaId) || SUGAR_KARKHANE[0];
  const calculatedTotal = tons * selectedKarkhana.ratePerTon;
  const calculatedFrpBonus = tons * selectedKarkhana.frpBonus;
  const grandTotal = calculatedTotal + calculatedFrpBonus;

  const handleSendCaneToKarkhana = (e: React.FormEvent) => {
    e.preventDefault();
    const slip = {
      slipNumber: `MK-SUGAR-${Math.floor(100000 + Math.random() * 900000)}`,
      date: new Date().toLocaleDateString('mr-IN'),
      farmerName,
      farmerAadhar,
      karkhana: selectedKarkhana.nameMr,
      tons,
      ratePerTon: selectedKarkhana.ratePerTon,
      frpBonusPerTon: selectedKarkhana.frpBonus,
      baseAmount: calculatedTotal,
      frpBonusTotal: calculatedFrpBonus,
      grandTotal,
      paymentDays: selectedKarkhana.paymentDays,
    };
    setCaneSlipReceipt(slip);
    speakMarathi(`अभिनंदन! तुमचे ${tons} टन ऊस नोंदणी सोमेश्वर/माळेगाव कारखान्यात यशस्वी झाली आहे. एकूण बिल ${grandTotal} रुपये अवघ्या ${selectedKarkhana.paymentDays} दिवसांत जमा होईल.`);
  };

  const handleBookLabor = (e: React.FormEvent) => {
    e.preventDefault();
    const totalWage = laborCount * laborDays * laborWage;
    setLaborBookedSuccess(`✅ अभिनंदन! ${laborCount} मजुरांची टोळी ${laborDays} दिवसांसाठी बुक झाली आहे. (एकूण मजुरी: ₹${totalWage})`);
    speakMarathi(`${laborCount} मजुरांची ऊस तोडणी टोळी बुक झाली आहे. मुकादम आज संध्याकाळी शेतावर संपर्क करेल.`);
  };

  const handleCallProcessor = (proc: ProcessingKarkhana) => {
    speakMarathi(`${proc.name} यांच्या खरेदी व्यवस्थापकाशी थेट संपर्क जोडला जात आहे.`);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Header Banner */}
      <div className="bg-gradient-to-br from-[#1B5E20] via-emerald-800 to-slate-900 text-white p-3.5 rounded-2xl shadow-lg border border-emerald-500">
        <div className="flex items-center justify-between mb-1">
          <span className="bg-[#FFC107] text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
            🏭 ऊस पट्टा व कारखाने थेट
          </span>
          <span className="text-[10px] text-amber-300 font-bold">
            १०-१५ दिवसांत FRP बिल थेट खात्यात
          </span>
        </div>
        <h2 className="text-base font-black text-white leading-tight">
          ऊस थेट साखर कारखान्याला पाठवा — सर्वोच्च FRP दर मिळवा!
        </h2>
        <p className="text-[11px] text-emerald-100 mt-0.5">
          बारामती, इंदापूर, सांगली, कोल्हापूर पट्ट्यातील सर्वोत्तम कारखाने
        </p>
      </div>

      {/* FORM 1: Cane to Karkhana Direct Calculation & Slip */}
      <div className="bg-white p-4 rounded-2xl shadow-md border border-slate-200">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
            <Factory className="w-4 h-4 text-[#1B5E20]" />
            फॉर्म १: ऊस वजन नोंदणी व थेट बिल कॅल्क्युलेटर
          </h3>
          <span className="text-[9px] bg-emerald-100 text-emerald-900 font-bold px-2 py-0.5 rounded-full">
            FRP हमी भाव
          </span>
        </div>

        <form onSubmit={handleSendCaneToKarkhana} className="space-y-3 text-xs">
          <div>
            <label className="font-bold text-slate-700 block mb-1">साखर कारखाना निवडा (Select Factory):</label>
            <select
              value={selectedKarkhanaId}
              onChange={(e) => setSelectedKarkhanaId(e.target.value)}
              className="w-full p-2.5 bg-emerald-50/50 border border-emerald-300 rounded-xl font-bold text-xs text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none cursor-pointer"
            >
              {SUGAR_KARKHANE.map((k) => (
                <option key={k.id} value={k.id}>
                  {k.nameMr} — ₹{k.ratePerTon}/टन (बिल {k.paymentDays} दिवस | +₹{k.frpBonus} FRP)
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="font-bold text-slate-700 block mb-1">ऊस वजन (टन Ton):</label>
              <input
                type="number"
                min="1"
                max="500"
                value={tons}
                onChange={(e) => setTons(parseFloat(e.target.value) || 0)}
                className="w-full p-2.5 border border-slate-300 rounded-xl font-black text-emerald-800 text-sm focus:ring-1 focus:ring-emerald-500"
              />
            </div>
            <div>
              <label className="font-bold text-slate-700 block mb-1">प्रति टन चालू दर:</label>
              <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-black text-slate-900 text-sm">
                ₹{selectedKarkhana.ratePerTon} <span className="text-[10px] text-slate-500 font-normal">+ ₹{selectedKarkhana.frpBonus} FRP</span>
              </div>
            </div>
          </div>

          {/* Live Total Calculation Card */}
          <div className="bg-gradient-to-r from-emerald-900 to-slate-900 text-white p-3 rounded-xl border border-emerald-600 space-y-1.5">
            <div className="flex justify-between items-center text-[11px]">
              <span className="text-emerald-200">मूळ ऊस किंमत ({tons} टन x ₹{selectedKarkhana.ratePerTon}):</span>
              <span className="font-bold">₹{calculatedTotal.toLocaleString('en-IN')}</span>
            </div>
            <div className="flex justify-between items-center text-[11px]">
              <span className="text-amber-300">+ FRP अतिरिक्त बोनस (+₹{selectedKarkhana.frpBonus}/टन):</span>
              <span className="font-bold text-amber-300">₹{calculatedFrpBonus.toLocaleString('en-IN')}</span>
            </div>
            <div className="pt-1.5 border-t border-emerald-700 flex justify-between items-center text-xs">
              <span className="font-black text-white">एकूण मिळणारी रक्कम:</span>
              <span className="font-black text-amber-300 text-base">₹{grandTotal.toLocaleString('en-IN')}</span>
            </div>
            <div className="text-[9px] text-emerald-300 text-center font-semibold">
              ⚡ कारखान्याकडून बिल अवघ्या {selectedKarkhana.paymentDays} दिवसांत बँक खात्यात जमा होईल.
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-[#1B5E20] hover:bg-emerald-800 text-amber-300 font-black py-3 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all border border-emerald-400"
          >
            <Send className="w-4 h-4 text-amber-400" />
            <span>कारखान्याला पाठवा — बिल {selectedKarkhana.paymentDays} दिवसांत मिळवा</span>
          </button>
        </form>
      </div>

      {/* FORM 2: Yellow Card - Labor Booking (मजूर टोळी बुक करा) */}
      <div className="bg-gradient-to-br from-amber-400 via-amber-300 to-yellow-400 p-4 rounded-2xl shadow-lg border-2 border-amber-500 text-slate-950">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <span className="text-2xl">👷‍♂️</span>
            <div>
              <span className="text-[9px] font-black bg-red-600 text-white px-2 py-0.5 rounded-full uppercase tracking-wider">
                तोडणी टोळी बुकिंग
              </span>
              <h3 className="text-xs font-black text-slate-950 mt-0.5">
                फॉर्म २: मजूर टोळी बुक करा — १५ मजूर २ दिवस ₹५००/मजूर
              </h3>
            </div>
          </div>
        </div>

        <form onSubmit={handleBookLabor} className="space-y-2.5 text-xs">
          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className="font-bold text-slate-900 block text-[10px] mb-1">मजूर संख्या:</label>
              <input
                type="number"
                min="1"
                value={laborCount}
                onChange={(e) => setLaborCount(parseInt(e.target.value) || 0)}
                className="w-full p-2 bg-white rounded-lg font-bold text-slate-950 border border-amber-400 text-xs"
              />
            </div>
            <div>
              <label className="font-bold text-slate-900 block text-[10px] mb-1">दिवस:</label>
              <input
                type="number"
                min="1"
                value={laborDays}
                onChange={(e) => setLaborDays(parseInt(e.target.value) || 0)}
                className="w-full p-2 bg-white rounded-lg font-bold text-slate-950 border border-amber-400 text-xs"
              />
            </div>
            <div>
              <label className="font-bold text-slate-900 block text-[10px] mb-1">दर/मजूर (₹):</label>
              <input
                type="number"
                value={laborWage}
                onChange={(e) => setLaborWage(parseInt(e.target.value) || 0)}
                className="w-full p-2 bg-white rounded-lg font-bold text-slate-950 border border-amber-400 text-xs"
              />
            </div>
          </div>

          <div className="bg-white/80 p-2.5 rounded-xl border border-amber-400 flex items-center justify-between text-xs font-black">
            <span>अंदाजे एकूण तोडणी मजुरी:</span>
            <span className="text-red-700 text-sm font-black">
              ₹{(laborCount * laborDays * laborWage).toLocaleString('en-IN')}
            </span>
          </div>

          {laborBookedSuccess && (
            <div className="p-2 bg-emerald-800 text-white rounded-xl text-[10px] font-bold">
              {laborBookedSuccess}
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-slate-950 hover:bg-slate-900 text-amber-300 font-black py-2.5 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95"
          >
            <Users className="w-4 h-4 text-amber-400" />
            <span>मजूर टोळी बुक करा (Book Labor Gang)</span>
          </button>
        </form>
      </div>

      {/* 3. Fruit & Agro Processing Karkhane List */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
            🍇 फळे व अन्न प्रक्रिया कारखाने (Export & Processing Hubs):
          </h3>
          <span className="text-[10px] text-emerald-800 font-bold">
            अ‍ॅडव्हान्स ७०%
          </span>
        </div>

        <div className="space-y-2">
          {FRUIT_PROCESSING_KARKHANE.map((factory) => (
            <div
              key={factory.id}
              className="bg-white p-3 rounded-2xl shadow-md border border-slate-200 hover:border-emerald-500 transition-all"
            >
              <div className="flex items-start justify-between gap-2 mb-1">
                <div>
                  <h4 className="font-black text-xs text-slate-950">{factory.name}</h4>
                  <span className="text-[9px] text-slate-500 font-medium">{factory.location}</span>
                </div>
                <span className="text-[8px] bg-emerald-100 text-emerald-900 font-black px-1.5 py-0.5 rounded">
                  {factory.cert}
                </span>
              </div>

              <div className="text-[10px] text-slate-700 space-y-0.5 my-1.5">
                <p><strong>विशेष पीक:</strong> {factory.specialty}</p>
                <p className="text-emerald-800 font-bold"><strong>पेमेंट अटी:</strong> {factory.paymentTerms}</p>
              </div>

              <div className="flex items-center justify-between pt-1.5 border-t border-slate-100">
                <span className="text-[9px] text-slate-500 font-bold">
                  फोन: {factory.phone}
                </span>
                <button
                  onClick={() => handleCallProcessor(factory)}
                  className="bg-[#1B5E20] hover:bg-emerald-800 text-amber-300 font-black px-3 py-1 rounded-lg text-[10px] flex items-center gap-1 shadow active:scale-95"
                >
                  <PhoneCall className="w-3 h-3 text-amber-400" />
                  <span>CALL</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Slip Receipt Modal */}
      {caneSlipReceipt && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl border-2 border-emerald-600 overflow-hidden">
            <div className="bg-[#1B5E20] text-white p-3 flex items-center justify-between">
              <h3 className="font-bold text-xs text-amber-300 flex items-center gap-1">
                <Receipt className="w-4 h-4" /> अधिकृत ऊस वजन पावती (Cane Slip)
              </h3>
              <button onClick={() => setCaneSlipReceipt(null)} className="text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 space-y-2 text-xs">
              <div className="text-center pb-2 border-b border-dashed border-slate-300">
                <h4 className="font-black text-sm text-slate-950">{caneSlipReceipt.karkhana}</h4>
                <p className="text-[10px] text-slate-500">पावती क्र: {caneSlipReceipt.slipNumber} • दिनांक: {caneSlipReceipt.date}</p>
              </div>

              <div className="space-y-1 text-slate-800">
                <div className="flex justify-between">
                  <span>शेतकऱ्याचे नाव:</span>
                  <span className="font-bold">{caneSlipReceipt.farmerName}</span>
                </div>
                <div className="flex justify-between">
                  <span>एकूण वजन:</span>
                  <span className="font-bold text-emerald-800">{caneSlipReceipt.tons} टन</span>
                </div>
                <div className="flex justify-between">
                  <span>कारखाना भाव:</span>
                  <span className="font-bold">₹{caneSlipReceipt.ratePerTon}/टन</span>
                </div>
                <div className="flex justify-between">
                  <span>FRP अतिरिक्त:</span>
                  <span className="font-bold text-amber-800">+₹{caneSlipReceipt.frpBonusPerTon}/टन</span>
                </div>
                <div className="flex justify-between pt-2 border-t border-slate-200 text-sm font-black">
                  <span>एकूण देय रक्कम:</span>
                  <span className="text-emerald-800 font-black">₹{caneSlipReceipt.grandTotal.toLocaleString('en-IN')}</span>
                </div>
              </div>

              <div className="bg-emerald-50 p-2.5 rounded-xl border border-emerald-200 text-[10px] text-emerald-950 font-bold text-center mt-2">
                ✅ हे बिल {caneSlipReceipt.paymentDays} दिवसांत आपल्या बँक खात्यात थेट जमा होईल.
              </div>

              <button
                onClick={() => setCaneSlipReceipt(null)}
                className="w-full bg-[#1B5E20] text-white py-2 rounded-xl font-bold text-xs mt-2"
              >
                पावती जतन केली (Done)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
