import React, { useState } from 'react';
import { Volume2, VolumeX, MapPin, Languages } from 'lucide-react';
import { Language } from '../types';
import { speakText, stopSpeech, isSpeaking } from '../utils/speech';

interface HeaderProps {
  lang: Language;
  onToggleLang: () => void;
  onSpeakWelcome?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ lang, onToggleLang }) => {
  const [playingVoice, setPlayingVoice] = useState(false);
  const [selectedCity, setSelectedCity] = useState<'Nashik' | 'Baramati' | 'Indapur' | 'Jalgaon' | 'Sangli'>('Nashik');

  const weatherData: Record<string, { temp: string; forecastMr: string; forecastEn: string; nameMr: string; nameEn: string }> = {
    Nashik: { temp: '३१°C', forecastMr: 'पावसाची शक्यता ☔', forecastEn: 'Rain Likely ☔', nameMr: 'नाशिक', nameEn: 'Nashik' },
    Baramati: { temp: '३३°C', forecastMr: 'हलका पाऊस 🌦️', forecastEn: 'Light Rain 🌦️', nameMr: 'बारामती', nameEn: 'Baramati' },
    Indapur: { temp: '३४°C', forecastMr: 'दमट हवामान ⛅', forecastEn: 'Humid ⛅', nameMr: 'इंदापूर', nameEn: 'Indapur' },
    Jalgaon: { temp: '३६°C', forecastMr: 'उष्ण व कोरडे ☀️', forecastEn: 'Hot & Dry ☀️', nameMr: 'जळगाव', nameEn: 'Jalgaon' },
    Sangli: { temp: '३२°C', forecastMr: 'उत्तम हवामान 🌤️', forecastEn: 'Clear Sky 🌤️', nameMr: 'सांगली', nameEn: 'Sangli' }
  };

  const handleVoiceWelcome = () => {
    if (playingVoice || isSpeaking()) {
      stopSpeech();
      setPlayingVoice(false);
    } else {
      setPlayingVoice(true);
      const curr = weatherData[selectedCity];
      const speechMr = `नमस्कार शेतकरी मित्रांनो! हरित कृषी क्रांती अ‍ॅपमध्ये आपले स्वागत आहे. ${curr.nameMr} चे तापमान ${curr.temp} असून ${curr.forecastMr} आहे.`;
      const speechEn = `Welcome to Harit Krushi Kranti agri app. Temperature in ${curr.nameEn} is ${curr.temp} with ${curr.forecastEn}.`;
      
      speakText(
        lang === 'mr' ? speechMr : speechEn,
        lang,
        () => setPlayingVoice(false),
        () => setPlayingVoice(false)
      );
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-gradient-to-r from-[#144818] via-[#1B5E20] to-[#0A3810] text-white shadow-md border-b border-emerald-700/50">
      <div className="px-3.5 py-2.5 flex items-center justify-between gap-2">
        {/* App Logo & Name */}
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-400 to-emerald-400 text-slate-950 flex items-center justify-center text-lg shrink-0 shadow-md font-bold">
            🌱
          </div>
          <div>
            <h1 className="font-black text-sm tracking-tight text-white leading-tight flex items-center gap-1.5">
              <span>{lang === 'mr' ? 'MAHA AGRI KRANTI' : 'MAHA AGRI KRANTI'}</span>
              <span className="bg-amber-400 text-slate-950 text-[9px] font-black px-1.5 py-0.2 rounded-full uppercase">
                PWA
              </span>
            </h1>
            <p className="text-[10px] text-emerald-100/90 font-medium">
              {lang === 'mr' ? 'हरित कृषी क्रांती • शाश्वत शेती' : 'Harit Krushi Kranti • Smart Agri'}
            </p>
          </div>
        </div>

        {/* Action Controls: Weather, Language Switcher & Audio */}
        <div className="flex items-center gap-1.5">
          {/* Location & Weather Pill */}
          <div className="flex items-center gap-1 bg-emerald-950/70 border border-emerald-600/60 rounded-xl px-2 py-1 text-xs">
            <MapPin className="w-3 h-3 text-amber-300 shrink-0" />
            <select
              value={selectedCity}
              onChange={(e) => setSelectedCity(e.target.value as any)}
              className="bg-transparent text-emerald-100 font-bold text-[11px] focus:outline-none cursor-pointer"
              aria-label="District selector"
            >
              <option value="Nashik" className="text-slate-900 font-semibold">{lang === 'mr' ? 'नाशिक' : 'Nashik'}</option>
              <option value="Baramati" className="text-slate-900 font-semibold">{lang === 'mr' ? 'बारामती' : 'Baramati'}</option>
              <option value="Indapur" className="text-slate-900 font-semibold">{lang === 'mr' ? 'इंदापूर' : 'Indapur'}</option>
              <option value="Jalgaon" className="text-slate-900 font-semibold">{lang === 'mr' ? 'जळगाव' : 'Jalgaon'}</option>
              <option value="Sangli" className="text-slate-900 font-semibold">{lang === 'mr' ? 'सांगली' : 'Sangli'}</option>
            </select>
            <span className="text-amber-300 font-black text-[11px] pl-1 border-l border-emerald-700">
              {weatherData[selectedCity].temp}
            </span>
          </div>

          {/* Bilingual Language Switcher Button (Marathi ↔ English) */}
          <button
            onClick={onToggleLang}
            className="flex items-center gap-1 px-2 py-1 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-[11px] shadow-sm transition-all active:scale-95 border border-amber-300"
            title={lang === 'mr' ? 'Switch to English' : 'मराठीत बदला'}
          >
            <Languages className="w-3.5 h-3.5 text-slate-950" />
            <span>{lang === 'mr' ? 'ENG' : 'मराठी'}</span>
          </button>

          {/* Voice Speaker */}
          <button
            onClick={handleVoiceWelcome}
            title={lang === 'mr' ? 'माहिती ऐका' : 'Listen speech'}
            className={`p-1.5 rounded-xl transition-all flex items-center justify-center shrink-0 ${
              playingVoice
                ? 'bg-amber-400 text-slate-950 ring-2 ring-white animate-pulse'
                : 'bg-emerald-950/70 text-emerald-100 hover:bg-emerald-800 border border-emerald-600/60'
            }`}
          >
            {playingVoice ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>
    </header>
  );
};


