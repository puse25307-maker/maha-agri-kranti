package com.mahaagri.kranti.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mahaagri.kranti.data.models.Language
import com.mahaagri.kranti.data.models.TabType
import com.mahaagri.kranti.ui.theme.*

@Composable
fun HomeScreen(
    lang: Language,
    onNavigate: (TabType) -> Unit,
    onCallExpert: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
    ) {
        // Welcome Hero Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Green900)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(Green900, Green800, Color(0xFF0A3810))
                            )
                        )
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Amber500)
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = if (lang == Language.MARATHI) "🌱 शाश्वत व आधुनिक कृषी" else "🌱 Smart Agri",
                                        color = Slate900,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color.White.copy(alpha = 0.15f))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "🚩 जय महाराष्ट्र",
                                        color = Amber500,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = if (lang == Language.MARATHI) "नमस्कार शेतकरी मित्र! 🙏" else "Hello Farmer Friend! 🙏",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black
                            )

                            Text(
                                text = if (lang == Language.MARATHI)
                                    "रोग निदान, शाश्वत हरित शेती, थेट बाजारभाव आणि शासकीय योजना एकाच ठिकाणी."
                                else
                                    "Disease diagnosis, eco-farming, direct mandi rates & schemes in one place.",
                                color = Green100,
                                fontSize = 11.sp,
                                lineHeight = 15.sp,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.White.copy(alpha = 0.12f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "🌾", fontSize = 24.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 2 Main Hero CTAs
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onNavigate(TabType.ROG_DOCTOR) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CameraAlt,
                                    contentDescription = "Scan",
                                    tint = Green800,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = if (lang == Language.MARATHI) "पानाचा रोग तपासा" else "Leaf AI Scan",
                                    color = Green800,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }

                        Button(
                            onClick = { onNavigate(TabType.SUSTAINABLE) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Amber500)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Eco,
                                    contentDescription = "Green",
                                    tint = Slate900,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = if (lang == Language.MARATHI) "शाश्वत शेती" else "Green Agri",
                                    color = Slate900,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }
            }
        }

        // Sustainable Hub Spotlight
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigate(TabType.SUSTAINABLE) },
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Teal900)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(Teal900, Green900)
                            )
                        )
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Amber500),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.WbSunny, contentDescription = null, tint = Slate900, modifier = Modifier.size(18.dp))
                            }
                            Column {
                                Text(
                                    text = if (lang == Language.MARATHI) "पर्यावरणपूरक शेती" else "Eco Farming",
                                    color = Teal100,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (lang == Language.MARATHI) "शाश्वत विकास केंद्र (Sustainable Hub)" else "Sustainable Agri & Carbon",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Amber500)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(text = "९०% अनुदान", color = Slate900, fontSize = 9.sp, fontWeight = FontWeight.Black)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = if (lang == Language.MARATHI)
                            "पीएम-कुसुम सौर पंप, ठिबक पाणी बचत, सेंद्रिय जीवामृत व कार्बन क्रेडिट्स द्वारे अधिक नफा मिळवा."
                        else
                            "PM-KUSUM solar pump subsidy, drip water savings & organic Jivamrut formula.",
                        color = Green100,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }
        }

        // Equipment Hub + Progressive Farmers Duo
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Equipment Hub Card
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigate(TabType.EQUIPMENT) },
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Amber100.copy(alpha = 0.5f)),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Amber500, Amber600)))
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Amber500),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "🚜", fontSize = 18.sp)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = if (lang == Language.MARATHI) "कृषी अवजारे हब" else "Equipment Hub",
                            color = Slate900,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = if (lang == Language.MARATHI) "ट्रॅक्टर, ड्रोन व रोटाव्हेटर भाडे / विक्री" else "Rent/sell tractors & drones",
                            color = Slate600,
                            fontSize = 10.sp,
                            lineHeight = 13.sp,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }

                // Progressive Farmers Card
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigate(TabType.PROGRESSIVE_FARMERS) },
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Green50),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Green600, Green800)))
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Green800),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "🏆", fontSize = 18.sp)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = if (lang == Language.MARATHI) "प्रगतशील शेतकरी" else "Top Farmers",
                            color = Slate900,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = if (lang == Language.MARATHI) "विक्रमी उत्पादन फॉर्म्युला व थेट खरेदी" else "Crop secrets & direct buy",
                            color = Slate600,
                            fontSize = 10.sp,
                            lineHeight = 13.sp,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }
            }
        }

        // Live Mandi Highlights
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.TrendingUp, contentDescription = null, tint = Green800, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (lang == Language.MARATHI) "आजचे प्रमुख बाजारभाव (Live)" else "Live Mandi Rates",
                                color = Slate900,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Text(
                            text = if (lang == Language.MARATHI) "सर्व पहा →" else "All Rates →",
                            color = Green800,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { onNavigate(TabType.MAHA_BAZAAR) }
                        )
                    }

                    // Item 1
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Amber100.copy(alpha = 0.4f))
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "🍌", fontSize = 20.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = if (lang == Language.MARATHI) "केळी (G9 Grand Naine)" else "Banana G9",
                                    color = Slate900,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "इंदापूर / जळगाव निर्यात",
                                    color = Slate500,
                                    fontSize = 10.sp
                                )
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "₹१२५ / kg", color = Green800, fontSize = 12.sp, fontWeight = FontWeight.Black)
                            Text(text = "दुबई मागणी", color = Green700, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Item 2
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Slate100)
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "🍇", fontSize = 20.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = if (lang == Language.MARATHI) "द्राक्षे (सोनाका / थॉम्सन)" else "Grapes (Sonaka)",
                                    color = Slate900,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "पिंपळगाव APMC नाशिक",
                                    color = Slate500,
                                    fontSize = 10.sp
                                )
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "₹१२० / kg", color = Blue700, fontSize = 12.sp, fontWeight = FontWeight.Black)
                            Text(text = "उच्चांकी दर", color = Blue700, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Free Doctor Call Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Green50),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Green600, Green700)))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (lang == Language.MARATHI) "👨‍⚕️ मोफत कृषी तज्ज्ञ सल्ला" else "👨‍⚕️ Free Expert Consultation",
                            color = Green800,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = if (lang == Language.MARATHI) "पिकांवर रोग आहे? थेट विचारा" else "Crop issues? Ask experts",
                            color = Slate900,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = onCallExpert,
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Green800)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Phone, contentDescription = null, tint = Amber500, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = if (lang == Language.MARATHI) "कॉल करा" else "Call", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
