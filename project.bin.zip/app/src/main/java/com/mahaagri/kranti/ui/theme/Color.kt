package com.mahaagri.kranti.ui.theme

import androidx.compose.ui.graphics.Color

val Green900 = Color(0xFF104716)
val Green800 = Color(0xFF1B5E20)
val Green700 = Color(0xFF2E7D32)
val Green600 = Color(0xFF388E3C)
val Green100 = Color(0xFFDCFCE7)
val Green50 = Color(0xFFF0FDF4)

val Amber500 = Color(0xFFFFC107)
val Amber600 = Color(0xFFFFB300)
val Amber700 = Color(0xFFFFA000)
val Amber100 = Color(0xFFFEF3C7)

val Teal900 = Color(0xFF134E4A)
val Teal700 = Color(0xFF0F766E)
val Teal100 = Color(0xFFCCFBF1)

val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate500 = Color(0xFF64748B)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)

val BackgroundLight = Color(0xFFFBFDFB)
val SurfaceCard = Color(0xFFFFFFFF)
val Red600 = Color(0xFFDC2626)
val Blue700 = Color(0xFF1D4ED8)
val Blue100 = Color(0xFFDBEAFE)
