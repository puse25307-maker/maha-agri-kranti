const fs = require('fs');

function replaceInFile(file) {
  let content = fs.readFileSync(file, 'utf8');
  content = content.replace(/👨‍🌾/g, '🌱');
  content = content.replace(/👩‍🔬/g, '🌱');
  fs.writeFileSync(file, content);
}

replaceInFile('src/data/agriData.ts');
replaceInFile('src/components/Tab3MaharashtraConnect.tsx');
replaceInFile('src/components/TabEquipmentHub.tsx');
replaceInFile('src/components/TabProgressiveFarmers.tsx');

