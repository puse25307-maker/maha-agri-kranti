// Utility for Marathi & English Text-to-Speech playback

let currentUtterance: SpeechSynthesisUtterance | null = null;
let voicesLoaded = false;

// Pre-load voices if possible
if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
  window.speechSynthesis.onvoiceschanged = () => {
    voicesLoaded = true;
  };
}

export const speakText = (text: string, lang: 'mr' | 'en' = 'mr', onEnd?: () => void, onError?: () => void): boolean => {
  if (!('speechSynthesis' in window)) {
    console.warn('Speech synthesis not supported in this browser.');
    return false;
  }

  // Cancel any active speech
  window.speechSynthesis.cancel();

  // Advanced Marathi text cleaner for better pronunciation
  const cleanText = text
    .replace(/[#*_~`]/g, '')
    .replace(/₹/g, lang === 'mr' ? ' रुपये ' : ' Rupees ')
    .replace(/kg/gi, lang === 'mr' ? ' किलो ' : ' Kilogram ')
    .replace(/Ton/gi, lang === 'mr' ? ' टन ' : ' Ton ')
    .replace(/Acre/gi, lang === 'mr' ? ' एकर ' : ' Acre ')
    .replace(/Lakh/gi, lang === 'mr' ? ' लाख ' : ' Lakh ')
    .replace(/Rs/gi, lang === 'mr' ? ' रुपये ' : ' Rupees ')
    .replace(/Ltr/gi, lang === 'mr' ? ' लिटर ' : ' Liter ')
    .replace(/gm/gi, lang === 'mr' ? ' ग्रॅम ' : ' Gram ')
    .replace(/ml/gi, lang === 'mr' ? ' मिली ' : ' ML ')
    .replace(/%/g, lang === 'mr' ? ' टक्के ' : ' Percent ')
    .replace(/\-/g, lang === 'mr' ? ' ते ' : ' to '); // Dash translated to "Te" in Marathi for ranges

  const utterance = new SpeechSynthesisUtterance(cleanText);
  // Slightly slower rate for clear Marathi pronunciation
  utterance.rate = lang === 'mr' ? 0.85 : 0.95;
  utterance.pitch = 1.0;
  // Volume to max
  utterance.volume = 1.0;

  const voices = window.speechSynthesis.getVoices();

  if (lang === 'en') {
    const enVoice = voices.find(v => v.lang.includes('en-IN')) || voices.find(v => v.lang.includes('en-GB')) || voices.find(v => v.lang.includes('en-US')) || voices.find(v => v.lang.startsWith('en'));
    if (enVoice) utterance.voice = enVoice;
    utterance.lang = 'en-IN';
  } else {
    // Prefer explicitly Marathi voice
    const marathiVoice = voices.find(v => v.lang.includes('mr-IN') || v.lang.includes('mr_IN') || v.lang.toLowerCase().includes('marathi'));
    const hindiVoice = voices.find(v => v.lang.includes('hi-IN') || v.lang.toLowerCase().includes('hindi'));
    const indianVoice = voices.find(v => v.lang.includes('en-IN'));

    if (marathiVoice) {
      utterance.voice = marathiVoice;
      utterance.lang = 'mr-IN';
    } else if (hindiVoice) {
      utterance.voice = hindiVoice;
      utterance.lang = 'mr-IN'; // Force Marathi pronunciation if available in OS
    } else if (indianVoice) {
      utterance.voice = indianVoice;
      utterance.lang = 'mr-IN';
    } else {
      utterance.lang = 'mr-IN';
    }
  }

  utterance.onend = () => {
    currentUtterance = null;
    if (onEnd) onEnd();
  };

  utterance.onerror = (e) => {
    if (e.error !== 'not-allowed' && e.error !== 'interrupted' && e.error !== 'canceled') {
      console.warn('Speech synthesis error:', e.error || 'Unknown error');
    }
    currentUtterance = null;
    if (onError) onError();
  };

  currentUtterance = utterance;

  // Use a tiny timeout to avoid Chrome/Android race conditions where cancel() kills the new utterance
  setTimeout(() => {
    window.speechSynthesis.speak(utterance);
  }, 50);
  
  return true;
};

export const speakMarathi = (text: string, onEnd?: () => void, onError?: () => void): boolean => {
  return speakText(text, 'mr', onEnd, onError);
};

export const stopSpeech = () => {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
    currentUtterance = null;
  }
};

export const isSpeaking = (): boolean => {
  if (!('speechSynthesis' in window)) return false;
  return window.speechSynthesis.speaking;
};

