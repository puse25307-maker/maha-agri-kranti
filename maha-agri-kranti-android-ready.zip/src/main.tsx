import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Register PWA Service Worker for offline capability
if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register('/sw.js')
      .then((registration) => {
        console.log('MAHA AGRI KRANTI PWA ServiceWorker registered:', registration.scope);
      })
      .catch((error) => {
        console.warn('ServiceWorker registration failed:', error);
      });
  });
} else if ('serviceWorker' in navigator) {
  // Also register in dev mode if supported
  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register('/sw.js')
      .then((registration) => {
        console.log('MAHA AGRI KRANTI ServiceWorker registered in dev:', registration.scope);
      })
      .catch((err) => {
        console.log('SW register note:', err);
      });
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
