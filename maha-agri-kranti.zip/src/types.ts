export type Language = 'mr' | 'en';

export type TabType = 
  | 'home'
  | 'rog_doctor' 
  | 'mati_pik' 
  | 'connect' 
  | 'maha_bazaar' 
  | 'us_belt' 
  | 'yojana' 
  | 'sustainable'
  | 'equipment'
  | 'progressive_farmers'
  | 'jod_dhanda' 
  | 'export' 
  | 'doctor' 
  | 'shala'
  | 'menu';

export interface FarmingEquipment {
  id: string;
  nameMr: string;
  nameEn: string;
  category: 'tractor' | 'harvester' | 'drone' | 'tiller' | 'rotavator' | 'implements' | 'specialized';
  listingType: 'rent' | 'sell' | 'both';
  condition: 'new' | 'used_good' | 'used_fair';
  specs: {
    hp?: string;
    modelYear?: string;
    brand: string;
    attachment?: string;
    capacity?: string;
  };
  pricing: {
    rentPerHour?: number;
    rentPerDay?: number;
    rentPerAcre?: number;
    sellingPrice?: number;
  };
  ownerName: string;
  phone: string;
  village: string;
  taluka: string;
  district: string;
  availability: 'available_now' | 'booked_today' | 'available_tomorrow';
  imageEmoji: string;
  rating: number;
  badgeMr: string;
  badgeEn: string;
  fuelIncluded?: boolean;
  driverIncluded?: boolean;
  notesMr?: string;
  notesEn?: string;
}

export interface ProgressiveFarmerStory {
  id: string;
  farmerName: string;
  village: string;
  taluka: string;
  district: string;
  region: 'paschim' | 'vidarbha' | 'marathwada' | 'khandesh' | 'konkan';
  mainCropMr: string;
  mainCropEn: string;
  variety: string;
  acres: number;
  cropYieldRecordMr: string;
  cropYieldRecordEn: string;
  netProfitPerAcreMr: string;
  netProfitPerAcreEn: string;
  bestFarmingTechniquesMr: string[];
  bestFarmingTechniquesEn: string[];
  produceForSale: {
    itemMr: string;
    itemEn: string;
    quantityAvailable: string;
    priceRate: string;
    qualityGrade: string;
  }[];
  phone: string;
  whatsapp: string;
  avatarEmoji: string;
  experienceYears: number;
  awardsMr: string;
  awardsEn: string;
  storyQuoteMr: string;
  storyQuoteEn: string;
  verified: boolean;
  image?: string;
}

export interface DiseaseInfo {
  id: string;
  nameMr: string;
  nameEn: string;
  cropMr: string;
  cropEn: string;
  seasonMr: string;
  severityPercent: number;
  severityLabel: string;
  upcharMr: string;
  kharchMr: string;
  medicines: {
    brand: string;
    company: string;
    dose: string;
    timing: string;
  }[];
  imagePlaceholder: string;
}

export interface DoctorExpert {
  id: string;
  name: string;
  degree: string;
  specialtyMr: string;
  specialtyEn: string;
  locationMr: string;
  experience: string;
  phone: string;
  rating: number;
  isAvailable: boolean;
  avatar: string;
}

export interface SugarcaneVariety {
  code: string;
  name: string;
  yieldTon: string;
  sugarPercent: string;
  popularity: string;
  waterRequirement: string;
  highlightMr: string;
  maturationDays: string;
}

export interface RegionFarmer {
  id: string;
  name: string;
  taluka: string;
  district: string;
  region: 'paschim' | 'vidarbha' | 'marathwada' | 'khandesh';
  cropMr: string;
  acres: number;
  phone: string;
  verified: boolean;
  avatar: string;
  notes: string;
}

export interface MarketCropItem {
  id: string;
  nameMr: string;
  nameEn: string;
  emoji: string;
  farmerName: string;
  location: string;
  qty: string;
  directPrice: number;
  apmcPrice: number;
  contact: string;
  image?: string;
  tag?: string;
}

export interface SugarKarkhana {
  id: string;
  nameMr: string;
  location: string;
  ratePerTon: number;
  paymentDays: number;
  frpBonus: number;
  rating: string;
  isBest?: boolean;
}

export interface ProcessingKarkhana {
  id: string;
  name: string;
  location: string;
  specialty: string;
  paymentTerms: string;
  phone: string;
  cert: string;
}

export interface SarkariYojana {
  id: string;
  nameMr: string;
  nameEn: string;
  benefitMr: string;
  categoryMr: string;
  subsidyTag: string;
  descriptionMr: string;
  eligibilityMr: string[];
  documentsMr: string[];
  applyLink: string;
  videoMinutes: string;
}

export interface JodDhandaItem {
  id: string;
  titleMr: string;
  titleEn: string;
  iconEmoji: string;
  monthlyIncome: string;
  setupCost: string;
  loanScheme: string;
  subsidyPercent: string;
  stepsMr: string[];
  marketTips: string;
  image?: string;
}

export interface AgriVideoLesson {
  id: string;
  titleMr: string;
  titleEn: string;
  duration: string;
  views: string;
  savingsBenefit: string;
  category: string;
  summaryMr: string;
  keyPoints: string[];
  thumbnailGradient: string;
}

export interface LiveMandiRate {
  mandi: string;
  crop: string;
  minPrice: number;
  maxPrice: number;
  avgPrice: number;
  trend: 'up' | 'down' | 'stable';
}
