import React, { useEffect, useState } from 'react';
import { Download, X, CheckCircle2, Smartphone, Share, PlusSquare } from 'lucide-react';
import { Language } from '../types';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

interface PWAInstallBarProps {
  lang: Language;
}

export const PWAInstallBar: React.FC<PWAInstallBarProps> = ({ lang }) => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstallable, setIsInstallable] = useState(false);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);
  const [showIosGuide, setShowIosGuide] = useState(false);

  useEffect(() => {
    // Check if already in standalone PWA mode
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches || 
      (window.navigator as unknown as { standalone?: boolean }).standalone === true;

    if (isStandalone) {
      setIsInstalled(true);
      return;
    }

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      setIsInstallable(true);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setIsInstallable(false);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    // Detect iOS safari
    const isIos = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as unknown as { MSStream?: unknown }).MSStream;
    if (isIos && !isStandalone) {
      setIsInstallable(true);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      await deferredPrompt.prompt();
      const choiceResult = await deferredPrompt.userChoice;
      if (choiceResult.outcome === 'accepted') {
        setIsInstalled(true);
      }
      setDeferredPrompt(null);
      setIsInstallable(false);
    } else {
      // Show iOS or general Add to Home Screen info modal
      setShowIosGuide(true);
    }
  };

  if (isInstalled || isDismissed) {
    return null;
  }

  return (
    <>
      {/* Top Sticky or Floating Install Ribbon */}
      <div className="bg-gradient-to-r from-[#1B5E20] via-emerald-800 to-[#1B5E20] text-white px-3.5 py-2.5 shadow-lg border-b border-amber-400/40 flex items-center justify-between text-xs sticky top-0 z-40">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-black shadow-sm text-sm shrink-0 border border-amber-200">
            🌱
          </div>
          <div>
            <div className="font-black text-amber-300 flex items-center gap-1">
              <span>MAHA AGRI KRANTI</span>
              <span className="text-[9px] bg-amber-500/30 text-amber-200 border border-amber-400/40 px-1.5 py-0.2 rounded font-bold">
                PWA
              </span>
            </div>
            <p className="text-[10.5px] text-emerald-100 font-medium">
              {lang === 'mr'
                ? 'मोफत ॲप इन्स्टॉल करा (ऑफलाईन चालेल)'
                : 'Install native app (Works Offline)'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={handleInstallClick}
            className="bg-gradient-to-r from-amber-400 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 text-slate-950 font-black px-3 py-1.5 rounded-full text-xs shadow-md active:scale-95 transition-transform flex items-center gap-1.5 cursor-pointer border border-amber-200"
          >
            <Download className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>{lang === 'mr' ? 'इन्स्टॉल' : 'Install'}</span>
          </button>
          <button
            onClick={() => setIsDismissed(true)}
            className="text-emerald-300 hover:text-white p-1 rounded-full hover:bg-black/20 transition-colors"
            title="Dismiss"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* iOS / General Install Guide Modal */}
      {showIosGuide && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border-2 border-amber-400 text-white rounded-3xl p-5 max-w-sm w-full shadow-2xl">
            <div className="flex justify-between items-start mb-3">
              <div className="flex items-center gap-2">
                <span className="text-2xl">🌱</span>
                <div>
                  <h3 className="font-black text-amber-300 text-base">
                    MAHA AGRI KRANTI
                  </h3>
                  <p className="text-[11px] text-slate-300">
                    {lang === 'mr' ? 'होम स्क्रीनवर ॲप जोडा' : 'Add App to Home Screen'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowIosGuide(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 my-4 text-xs">
              <div className="flex items-start gap-2.5 bg-slate-800/80 p-2.5 rounded-xl border border-slate-700">
                <span className="bg-amber-400 text-slate-950 font-black w-5 h-5 rounded-full flex items-center justify-center shrink-0 text-[10px]">
                  1
                </span>
                <div>
                  <span className="font-bold text-white">
                    {lang === 'mr' ? 'ब्राउझरचा शेअर (Share) बटण दाबा' : 'Tap Browser Share icon'}
                  </span>
                  <div className="text-[11px] text-slate-300 flex items-center gap-1 mt-0.5">
                    <Share className="w-3.5 h-3.5 text-amber-300 inline" /> {lang === 'mr' ? 'खाली किंवा वरच्या मेन्यूमध्ये' : 'At bottom or top menu'}
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-2.5 bg-slate-800/80 p-2.5 rounded-xl border border-slate-700">
                <span className="bg-amber-400 text-slate-950 font-black w-5 h-5 rounded-full flex items-center justify-center shrink-0 text-[10px]">
                  2
                </span>
                <div>
                  <span className="font-bold text-white">
                    {lang === 'mr' ? '"Add to Home Screen" निवडा' : 'Select "Add to Home Screen"'}
                  </span>
                  <div className="text-[11px] text-slate-300 flex items-center gap-1 mt-0.5">
                    <PlusSquare className="w-3.5 h-3.5 text-emerald-400 inline" /> {lang === 'mr' ? 'होम स्क्रीनवर आयकॉन तयार होईल' : 'App icon will appear on home screen'}
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-2.5 bg-emerald-950/70 p-2.5 rounded-xl border border-emerald-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <p className="text-[11px] text-emerald-200">
                  {lang === 'mr'
                    ? 'यानंतर ॲप नेट नसतानाही थेट मोबाईल ॲपप्रमाणे चालू शकेल!'
                    : 'The app will launch like a native application with offline support!'}
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowIosGuide(false)}
              className="w-full bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 font-black py-2.5 rounded-xl text-xs hover:brightness-105"
            >
              {lang === 'mr' ? 'समजले (Got it)' : 'Got it'}
            </button>
          </div>
        </div>
      )}
    </>
  );
};
