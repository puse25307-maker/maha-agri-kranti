import React, { useState } from 'react';
import { 
  Tractor, 
  Search, 
  Filter, 
  PhoneCall, 
  MessageCircle, 
  Volume2, 
  Sparkles, 
  PlusCircle, 
  X, 
  CheckCircle2, 
  MapPin, 
  Tag, 
  SlidersHorizontal,
  Zap,
  Info,
  Calendar,
  DollarSign
} from 'lucide-react';
import { FARMING_EQUIPMENT_DATA } from '../data/agriData';
import { FarmingEquipment, Language } from '../types';
import { speakText } from '../utils/speech';

interface TabEquipmentHubProps {
  lang: Language;
}

export const TabEquipmentHub: React.FC<TabEquipmentHubProps> = ({ lang }) => {
  const [equipmentList, setEquipmentList] = useState<FarmingEquipment[]>(FARMING_EQUIPMENT_DATA);
  const [listingTypeFilter, setListingTypeFilter] = useState<'all' | 'rent' | 'sell'>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [districtFilter, setDistrictFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);
  const [selectedItemForDetails, setSelectedItemForDetails] = useState<FarmingEquipment | null>(null);

  // Form states for adding equipment
  const [formData, setFormData] = useState({
    name: '',
    category: 'tractor' as FarmingEquipment['category'],
    listingType: 'rent' as 'rent' | 'sell' | 'both',
    brand: '',
    hp: '',
    attachment: '',
    rentPerHour: '',
    rentPerAcre: '',
    sellingPrice: '',
    ownerName: '',
    phone: '',
    village: '',
    taluka: '',
    district: 'पुणे',
    fuelIncluded: true,
    driverIncluded: true
  });

  const categories = [
    { id: 'all', labelMr: '🚜 सर्व अवजारे', labelEn: '🚜 All Equipment' },
    { id: 'tractor', labelMr: '🚜 ट्रॅक्टर (Tractors)', labelEn: '🚜 Tractors' },
    { id: 'drone', labelMr: '🚁 ड्रोन फवारणी (Drones)', labelEn: '🚁 Agri Drones' },
    { id: 'harvester', labelMr: '🌾 कम्बाइन हार्वेस्टर', labelEn: '🌾 Harvesters' },
    { id: 'tiller', labelMr: '⚙️ पॉवर टिलर', labelEn: '⚙️ Power Tillers' },
    { id: 'rotavator', labelMr: '🔩 रोटावेटर व नांगर', labelEn: '🔩 Rotavators' },
    { id: 'specialized', labelMr: '📐 लेझर लेव्हलर / विशेष', labelEn: '📐 Laser / Specialized' },
    { id: 'implements', labelMr: '🌱 मल्चिंग / इतर अवजारे', labelEn: '🌱 Implements' },
  ];

  const districts = [
    'all',
    'पुणे',
    'नाशिक',
    'कोल्हापूर',
    'सांगली',
    'सोलापूर',
    'जळगाव',
    'अहिल्यानगर (अहमदनगर)',
    'अमरावती',
    'जालना',
    'छत्रपती संभाजीनगर',
    'लातूर'
  ];

  const filteredItems = equipmentList.filter((item) => {
    // Listing type match
    const matchesType = listingTypeFilter === 'all' 
      ? true 
      : item.listingType === 'both' || item.listingType === listingTypeFilter;

    // Category match
    const matchesCategory = categoryFilter === 'all' || item.category === categoryFilter;

    // District match
    const matchesDistrict = districtFilter === 'all' || item.district === districtFilter;

    // Query match
    const query = searchQuery.toLowerCase().trim();
    const matchesQuery = query === '' || 
      item.nameMr.toLowerCase().includes(query) ||
      item.nameEn.toLowerCase().includes(query) ||
      item.ownerName.toLowerCase().includes(query) ||
      item.taluka.toLowerCase().includes(query) ||
      item.district.toLowerCase().includes(query) ||
      item.specs.brand.toLowerCase().includes(query);

    return matchesType && matchesCategory && matchesDistrict && matchesQuery;
  });

  const handleCall = (item: FarmingEquipment) => {
    const text = lang === 'mr' 
      ? `📞 ${item.ownerName} (${item.taluka}, ${item.district}) यांना थेट फोन लावला जात आहे: ${item.phone}`
      : `📞 Calling equipment owner ${item.ownerName}: ${item.phone}`;
    setNotification(text);
    speakText(lang === 'mr' ? `${item.ownerName} यांच्याशी संपर्क सुरू आहे.` : `Contacting owner ${item.ownerName}`, lang);
    setTimeout(() => setNotification(null), 4000);
  };

  const handleWhatsApp = (item: FarmingEquipment) => {
    const text = lang === 'mr'
      ? `💬 ${item.ownerName} यांच्यासोबत WhatsApp वर ${item.nameMr} बुकिंग चॅट उघडले आहे!`
      : `💬 Opening WhatsApp chat with ${item.ownerName} for ${item.nameEn}!`;
    setNotification(text);
    speakText(lang === 'mr' ? `व्हॉट्सअ‍ॅप बुकिंग सुरू झाले आहे.` : `WhatsApp booking opened.`, lang);
    setTimeout(() => setNotification(null), 4000);
  };

  const handleSpeakDetails = (item: FarmingEquipment) => {
    const speechMr = `${item.nameMr}. मालक ${item.ownerName}, तालुका ${item.taluka}, जिल्हा ${item.district}. ` +
      (item.pricing.rentPerHour ? `भाडे ₹${item.pricing.rentPerHour} प्रति तास. ` : '') +
      (item.pricing.rentPerAcre ? `एकरी भाडे ₹${item.pricing.rentPerAcre}. ` : '') +
      (item.pricing.sellingPrice ? `विक्री किंमत ₹${item.pricing.sellingPrice.toLocaleString('en-IN')}. ` : '') +
      `${item.badgeMr}.`;

    const speechEn = `${item.nameEn}. Owner ${item.ownerName}, ${item.taluka}, ${item.district}. ` +
      (item.pricing.rentPerHour ? `Rental ₹${item.pricing.rentPerHour} per hour. ` : '') +
      (item.pricing.rentPerAcre ? `Rental ₹${item.pricing.rentPerAcre} per acre. ` : '') +
      (item.pricing.sellingPrice ? `Selling Price ₹${item.pricing.sellingPrice.toLocaleString('en-IN')}. ` : '');

    speakText(lang === 'mr' ? speechMr : speechEn, lang);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.ownerName || !formData.phone) return;

    const newEq: FarmingEquipment = {
      id: `eq_custom_${Date.now()}`,
      nameMr: formData.name,
      nameEn: formData.name,
      category: formData.category,
      listingType: formData.listingType,
      condition: 'used_good',
      specs: {
        hp: formData.hp ? `${formData.hp} HP` : undefined,
        brand: formData.brand || 'Custom',
        attachment: formData.attachment || undefined,
        modelYear: '2023'
      },
      pricing: {
        rentPerHour: formData.rentPerHour ? parseFloat(formData.rentPerHour) : undefined,
        rentPerAcre: formData.rentPerAcre ? parseFloat(formData.rentPerAcre) : undefined,
        sellingPrice: formData.sellingPrice ? parseFloat(formData.sellingPrice) : undefined,
      },
      ownerName: formData.ownerName,
      phone: formData.phone,
      village: formData.village || 'गाव',
      taluka: formData.taluka || 'तालुका',
      district: formData.district,
      availability: 'available_now',
      imageEmoji: formData.category === 'drone' ? '🚁' : formData.category === 'harvester' ? '🌾' : formData.category === 'tiller' ? '⚙️' : '🚜',
      rating: 5.0,
      badgeMr: 'नवीन शेतकरी नोंदणी',
      badgeEn: 'Newly Listed by Farmer',
      fuelIncluded: formData.fuelIncluded,
      driverIncluded: formData.driverIncluded,
      notesMr: 'शेतकऱ्याने थेट नोंदवलेले अवजार. थेट संपर्क करा.',
      notesEn: 'Directly listed by farmer. Contact directly.'
    };

    setEquipmentList([newEq, ...equipmentList]);
    setShowAddModal(false);
    const successMsg = lang === 'mr'
      ? `✅ अभिनंदन! तुमचे अवजार '${formData.name}' भाडे व विक्री यादीत जोडले गेले आहे!`
      : `✅ Success! Your equipment '${formData.name}' has been listed!`;
    setNotification(successMsg);
    speakText(lang === 'mr' ? `तुमचे अवजार यशस्वीरित्या जोडले आहे.` : `Equipment listed successfully.`, lang);

    // Reset
    setFormData({
      name: '',
      category: 'tractor',
      listingType: 'rent',
      brand: '',
      hp: '',
      attachment: '',
      rentPerHour: '',
      rentPerAcre: '',
      sellingPrice: '',
      ownerName: '',
      phone: '',
      village: '',
      taluka: '',
      district: 'पुणे',
      fuelIncluded: true,
      driverIncluded: true
    });

    setTimeout(() => setNotification(null), 4500);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Toast Notification */}
      {notification && (
        <div className="fixed top-16 left-3 right-3 z-50 bg-slate-950 text-amber-300 p-3 rounded-2xl shadow-2xl border-2 border-[#FFC107] text-xs font-bold animate-bounce flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
            <span>{notification}</span>
          </div>
          <button onClick={() => setNotification(null)} className="text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Hero Header Banner */}
      <div className="bg-gradient-to-br from-[#1B5E20] via-emerald-800 to-teal-900 rounded-3xl p-5 text-white shadow-xl border-2 border-[#FFC107] relative overflow-hidden">
        <div className="absolute top-0 right-0 -mr-6 -mt-6 w-32 h-32 bg-amber-400/20 rounded-full blur-2xl pointer-events-none" />
        
        <div className="flex items-center justify-between mb-2">
          <div className="inline-flex items-center gap-1.5 bg-amber-400 text-slate-950 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider">
            <Tractor className="w-3.5 h-3.5" />
            <span>{lang === 'mr' ? 'कृषी यांत्रिकीकरण हब' : 'Agri Machinery Hub'}</span>
          </div>
          <span className="text-xs bg-emerald-950/70 border border-emerald-400/50 px-2.5 py-0.5 rounded-full text-emerald-200 font-bold">
            {lang === 'mr' ? '५५०+ अवजारे उपलब्ध' : '550+ Available'}
          </span>
        </div>

        <h2 className="text-xl sm:text-2xl font-black text-white leading-snug">
          {lang === 'mr' ? '🚜 कृषी अवजारे भाडे व खरेदी-विक्री केंद्र' : '🚜 Farm Equipment Rent & Selling Hub'}
        </h2>
        <p className="text-xs sm:text-sm text-emerald-100 mt-1 max-w-xl font-medium">
          {lang === 'mr' 
            ? 'ट्रॅक्टर, ड्रोन फवारणी, कम्बाइन हार्वेस्टर, रोटावेटर व पॉवर टिलर थेट मालकाकडून स्वस्त भाड्याने मिळवा किंवा विका.'
            : 'Rent or buy Tractors, Agri Spraying Drones, Combine Harvesters, and Rotavators directly from verified farmers.'}
        </p>

        {/* Action button: List your own equipment */}
        <div className="mt-4 flex flex-wrap gap-2 pt-2 border-t border-emerald-700/60">
          <button
            onClick={() => setShowAddModal(true)}
            className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-slate-950 px-4 py-2.5 rounded-2xl font-black text-xs sm:text-sm shadow-lg transition-all active:scale-95"
          >
            <PlusCircle className="w-4 h-4 text-slate-950" />
            <span>{lang === 'mr' ? 'तुमचे अवजार भाड्याने द्या / विका' : 'List Equipment for Rent/Sale'}</span>
          </button>

          <button
            onClick={() => {
              const text = lang === 'mr' 
                ? 'कृषी अवजारे हब: येथे तुम्ही ट्रॅक्टर, ड्रोन, हार्वेस्टर आणि रोटावेटर एका क्लिकवर भाड्याने बुक करू शकता किंवा जुनी-नवीन अवजारे थेट खरेदी-विक्री करू शकता.'
                : 'Agri Equipment Hub allows you to rent tractors, spraying drones, and harvesters at lowest rates or buy-sell directly.';
              speakText(text, lang);
            }}
            className="inline-flex items-center justify-center gap-1.5 bg-emerald-950/80 hover:bg-emerald-900 border border-amber-400/60 text-amber-300 px-3.5 py-2.5 rounded-2xl font-bold text-xs"
          >
            <Volume2 className="w-4 h-4" />
            <span>{lang === 'mr' ? 'माहिती ऐका' : 'Listen'}</span>
          </button>
        </div>
      </div>

      {/* Main Filter Tabs: All, Rent, Sell */}
      <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-sm space-y-3">
        {/* Listing Type Toggle */}
        <div className="flex bg-slate-100 p-1 rounded-xl">
          <button
            onClick={() => setListingTypeFilter('all')}
            className={`flex-1 py-2 text-xs font-black rounded-lg transition-all ${
              listingTypeFilter === 'all'
                ? 'bg-[#1B5E20] text-white shadow'
                : 'text-slate-700 hover:text-slate-900'
            }`}
          >
            {lang === 'mr' ? 'सर्व अवजारे' : 'All Listings'} ({equipmentList.length})
          </button>
          <button
            onClick={() => setListingTypeFilter('rent')}
            className={`flex-1 py-2 text-xs font-black rounded-lg transition-all ${
              listingTypeFilter === 'rent'
                ? 'bg-amber-500 text-slate-950 shadow'
                : 'text-slate-700 hover:text-slate-900'
            }`}
          >
            {lang === 'mr' ? '🌾 भाड्याने हवे (Rent)' : '🌾 For Rent'}
          </button>
          <button
            onClick={() => setListingTypeFilter('sell')}
            className={`flex-1 py-2 text-xs font-black rounded-lg transition-all ${
              listingTypeFilter === 'sell'
                ? 'bg-blue-600 text-white shadow'
                : 'text-slate-700 hover:text-slate-900'
            }`}
          >
            {lang === 'mr' ? '💰 खरेदी-विक्री (Sale)' : '💰 For Sale'}
          </button>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={lang === 'mr' ? 'अवजार, ट्रॅक्टर मॉडेल, तालुका किंवा मालकाचे नाव शोधा...' : 'Search equipment, tractor model, taluka or owner...'}
            className="w-full pl-9 pr-8 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="absolute right-2.5 top-2.5 text-slate-400">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Category Filter Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setCategoryFilter(cat.id)}
              className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
                categoryFilter === cat.id
                  ? 'bg-emerald-800 text-white shadow-sm'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {lang === 'mr' ? cat.labelMr : cat.labelEn}
            </button>
          ))}
        </div>

        {/* District Filter Dropdown */}
        <div className="flex items-center gap-2 pt-1 border-t border-slate-100">
          <MapPin className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
          <span className="text-[11px] font-bold text-slate-600 shrink-0">
            {lang === 'mr' ? 'जिल्हा निवडा:' : 'Select District:'}
          </span>
          <select
            value={districtFilter}
            onChange={(e) => setDistrictFilter(e.target.value)}
            className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 font-bold text-slate-800 focus:outline-none"
          >
            {districts.map((dist) => (
              <option key={dist} value={dist}>
                {dist === 'all' ? (lang === 'mr' ? 'सर्व महाराष्ट्र (All)' : 'All Maharashtra') : dist}
              </option>
            ))}
          </select>
          <span className="text-[10px] text-slate-400 ml-auto font-medium">
            {filteredItems.length} {lang === 'mr' ? 'अवजारे सापडली' : 'found'}
          </span>
        </div>
      </div>

      {/* Equipment Listings Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {filteredItems.length === 0 ? (
          <div className="col-span-full bg-white p-8 rounded-3xl text-center border border-slate-200 space-y-3">
            <Tractor className="w-12 h-12 text-slate-300 mx-auto" />
            <p className="font-bold text-slate-700 text-sm">
              {lang === 'mr' ? 'या फिल्टरनुसार सध्या कोणतेही अवजार उपलब्ध नाही.' : 'No equipment found for selected filter.'}
            </p>
            <button
              onClick={() => {
                setListingTypeFilter('all');
                setCategoryFilter('all');
                setDistrictFilter('all');
                setSearchQuery('');
              }}
              className="text-xs font-bold text-emerald-700 underline"
            >
              {lang === 'mr' ? 'सर्व फिल्टर्स रिसेट करा' : 'Reset all filters'}
            </button>
          </div>
        ) : (
          filteredItems.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-3xl p-4 border border-slate-200 shadow-sm hover:shadow-md transition-all space-y-3 relative overflow-hidden flex flex-col justify-between"
            >
              {/* Header tags */}
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-3xl bg-amber-50 p-2 rounded-2xl border border-amber-200">
                      {item.imageEmoji}
                    </span>
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className={`text-[10px] font-black px-2 py-0.5 rounded-full uppercase ${
                          item.listingType === 'rent'
                            ? 'bg-amber-100 text-amber-900 border border-amber-300'
                            : item.listingType === 'sell'
                            ? 'bg-blue-100 text-blue-900 border border-blue-300'
                            : 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                        }`}>
                          {item.listingType === 'rent'
                            ? (lang === 'mr' ? 'भाड्याने' : 'Rent')
                            : item.listingType === 'sell'
                            ? (lang === 'mr' ? 'विक्रीसाठी' : 'For Sale')
                            : (lang === 'mr' ? 'भाडे व विक्री' : 'Rent & Sale')}
                        </span>
                        
                        {item.availability === 'available_now' && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-emerald-50 text-emerald-700 px-1.5 py-0.5 rounded-full">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                            {lang === 'mr' ? 'उपलब्ध' : 'Available'}
                          </span>
                        )}
                      </div>
                      
                      <h3 className="font-black text-sm text-slate-900 mt-1 leading-snug">
                        {lang === 'mr' ? item.nameMr : item.nameEn}
                      </h3>
                    </div>
                  </div>

                  <button
                    onClick={() => handleSpeakDetails(item)}
                    className="p-2 bg-slate-50 hover:bg-amber-50 rounded-xl text-slate-600 hover:text-amber-700 border border-slate-200 transition-all shrink-0"
                    title={lang === 'mr' ? 'माहिती ऐका' : 'Listen info'}
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>

                {/* Specs Box */}
                <div className="bg-slate-50 p-2.5 rounded-2xl border border-slate-100 text-xs space-y-1.5">
                  <div className="flex items-center justify-between text-slate-600">
                    <span className="font-medium">{lang === 'mr' ? 'ब्रँड व मॉडेल:' : 'Brand:'}</span>
                    <span className="font-bold text-slate-800">{item.specs.brand} {item.specs.hp ? `(${item.specs.hp})` : ''}</span>
                  </div>
                  {item.specs.attachment && (
                    <div className="flex items-center justify-between text-slate-600">
                      <span className="font-medium">{lang === 'mr' ? 'जोडणी अवजार:' : 'Attachment:'}</span>
                      <span className="font-bold text-slate-800 truncate max-w-[180px]">{item.specs.attachment}</span>
                    </div>
                  )}
                  <div className="flex items-center justify-between text-slate-600">
                    <span className="font-medium">{lang === 'mr' ? 'स्थान:' : 'Location:'}</span>
                    <span className="font-bold text-emerald-800 flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-emerald-600" />
                      {item.village}, {item.taluka} ({item.district})
                    </span>
                  </div>
                </div>

                {/* Badge features */}
                <div className="flex flex-wrap gap-1.5 mt-2">
                  <span className="inline-flex items-center gap-1 bg-amber-50 border border-amber-200 text-amber-900 text-[10px] font-bold px-2 py-0.5 rounded-lg">
                    <Zap className="w-3 h-3 text-amber-600" />
                    {lang === 'mr' ? item.badgeMr : item.badgeEn}
                  </span>
                  {item.driverIncluded && (
                    <span className="bg-emerald-50 text-emerald-800 text-[10px] font-semibold px-2 py-0.5 rounded-lg">
                      {lang === 'mr' ? '✓ ड्रायव्हर उपलब्ध' : '✓ Driver Included'}
                    </span>
                  )}
                </div>

                {/* Pricing Display */}
                <div className="mt-3 p-2.5 bg-gradient-to-r from-emerald-50 to-amber-50 rounded-2xl border border-emerald-200/80">
                  <div className="text-[11px] text-slate-600 font-bold mb-0.5">
                    {lang === 'mr' ? 'दर व भाडे तपशील:' : 'Pricing & Rates:'}
                  </div>
                  <div className="flex items-baseline gap-2 flex-wrap">
                    {item.pricing.rentPerHour && (
                      <span className="text-sm font-black text-[#1B5E20]">
                        ₹{item.pricing.rentPerHour}
                        <span className="text-[10px] font-normal text-slate-600">{lang === 'mr' ? ' / तास' : ' / hr'}</span>
                      </span>
                    )}
                    {item.pricing.rentPerAcre && (
                      <span className="text-sm font-black text-amber-800">
                        ₹{item.pricing.rentPerAcre}
                        <span className="text-[10px] font-normal text-slate-600">{lang === 'mr' ? ' / एकर' : ' / acre'}</span>
                      </span>
                    )}
                    {item.pricing.sellingPrice && (
                      <span className="text-sm font-black text-blue-900">
                        ₹{item.pricing.sellingPrice.toLocaleString('en-IN')}
                        <span className="text-[10px] font-normal text-slate-600">{lang === 'mr' ? ' (किंमत)' : ' (Sale Price)'}</span>
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Owner and Direct Contact Action Bar */}
              <div className="pt-2 border-t border-slate-100 space-y-2 mt-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-700">
                    👨‍🌾 {item.ownerName}
                  </span>
                  <span className="text-[10px] text-slate-400 font-medium">
                    ⭐ {item.rating} / 5
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => handleCall(item)}
                    className="flex items-center justify-center gap-1.5 bg-[#1B5E20] hover:bg-emerald-800 text-white py-2 px-3 rounded-xl font-black text-xs shadow-sm transition-all active:scale-95"
                  >
                    <PhoneCall className="w-3.5 h-3.5 text-amber-300" />
                    <span>{lang === 'mr' ? 'कॉल करा' : 'Call Owner'}</span>
                  </button>

                  <button
                    onClick={() => handleWhatsApp(item)}
                    className="flex items-center justify-center gap-1.5 bg-[#25D366] hover:bg-emerald-600 text-slate-950 py-2 px-3 rounded-xl font-black text-xs shadow-sm transition-all active:scale-95"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>{lang === 'mr' ? 'WhatsApp' : 'WhatsApp'}</span>
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Subsidy Info Section */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-950 to-slate-950 p-4.5 rounded-3xl text-white border border-blue-400/40 shadow-lg space-y-2">
        <div className="flex items-center gap-2 text-amber-400 text-xs font-black uppercase">
          <Zap className="w-4 h-4" />
          <span>{lang === 'mr' ? 'कृषी यांत्रिकीकरण ५०% ते ७०% शासकीय अनुदान (SMAM)' : 'SMAM Farm Mechanization 50-70% Subsidy'}</span>
        </div>
        <p className="text-xs text-blue-100">
          {lang === 'mr'
            ? 'MahaDBT पोर्टलवर ट्रॅक्टर, रोटावेटर, ड्रोन आणि हार्वेस्टर खरेदीसाठी ५०% ते ७०% पर्यंत सबसिडी मिळते. अर्जासाठी महाडीबीटी किंवा जवळच्या कृषी सहाय्यकांशी संपर्क साधा.'
            : 'Get 50% to 70% government subsidy on Tractors, Rotavators, Drones, and Harvesters via MahaDBT SMAM portal.'}
        </p>
      </div>

      {/* Add Equipment Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-5 space-y-4 shadow-2xl border-2 border-[#FFC107] max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Tractor className="w-5 h-5 text-emerald-700" />
                <h3 className="font-black text-base text-slate-900">
                  {lang === 'mr' ? 'तुमचे अवजार नोंदवा (भाडे किंवा विक्री)' : 'List Your Equipment (Rent or Sale)'}
                </h3>
              </div>
              <button onClick={() => setShowAddModal(false)} className="p-1 rounded-full hover:bg-slate-100 text-slate-500">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  {lang === 'mr' ? 'अवजाराचे नाव व मॉडेल *' : 'Equipment Name & Model *'}
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder={lang === 'mr' ? 'उदा. महिंद्रा ५७५ DI किंवा रोटावेटर' : 'e.g. Mahindra 575 DI or Drone'}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {lang === 'mr' ? 'प्रकार निवडा' : 'Category'}
                  </label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value as any })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  >
                    <option value="tractor">{lang === 'mr' ? 'ट्रॅक्टर (Tractor)' : 'Tractor'}</option>
                    <option value="drone">{lang === 'mr' ? 'ड्रोन फवारणी (Drone)' : 'Agri Drone'}</option>
                    <option value="harvester">{lang === 'mr' ? 'कम्बाइन हार्वेस्टर' : 'Harvester'}</option>
                    <option value="tiller">{lang === 'mr' ? 'पॉवर टिलर' : 'Power Tiller'}</option>
                    <option value="rotavator">{lang === 'mr' ? 'रोटावेटर / नांगर' : 'Rotavator'}</option>
                    <option value="specialized">{lang === 'mr' ? 'लेझर लेव्हलर / इतर' : 'Specialized'}</option>
                    <option value="implements">{lang === 'mr' ? 'मल्चिंग / अवजारे' : 'Implements'}</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {lang === 'mr' ? 'नोंदणी प्रकार' : 'Listing Type'}
                  </label>
                  <select
                    value={formData.listingType}
                    onChange={(e) => setFormData({ ...formData, listingType: e.target.value as any })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  >
                    <option value="rent">{lang === 'mr' ? 'भाड्याने देणे (Rent)' : 'For Rent'}</option>
                    <option value="sell">{lang === 'mr' ? 'विक्रीसाठी (Sell)' : 'For Sale'}</option>
                    <option value="both">{lang === 'mr' ? 'भाडे व विक्री दोन्ही' : 'Both Rent & Sell'}</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {lang === 'mr' ? 'ब्रँड व अश्वशक्ती (HP)' : 'Brand & HP'}
                  </label>
                  <input
                    type="text"
                    value={formData.brand}
                    onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                    placeholder="उदा. Mahindra 50 HP"
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {lang === 'mr' ? 'जोडणी अवजार' : 'Attachment'}
                  </label>
                  <input
                    type="text"
                    value={formData.attachment}
                    onChange={(e) => setFormData({ ...formData, attachment: e.target.value })}
                    placeholder="उदा. ६ फूट रोटावेटर / ट्रॉली"
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  />
                </div>
              </div>

              {/* Pricing fields */}
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {lang === 'mr' ? 'भाडे (₹/तास)' : 'Rent (₹/hr)'}
                  </label>
                  <input
                    type="number"
                    value={formData.rentPerHour}
                    onChange={(e) => setFormData({ ...formData, rentPerHour: e.target.value })}
                    placeholder="७५०"
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {lang === 'mr' ? 'भाडे (₹/एकर)' : 'Rent (₹/acre)'}
                  </label>
                  <input
                    type="number"
                    value={formData.rentPerAcre}
                    onChange={(e) => setFormData({ ...formData, rentPerAcre: e.target.value })}
                    placeholder="८५०"
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {lang === 'mr' ? 'किंमत (₹ विक्री)' : 'Sale Price (₹)'}
                  </label>
                  <input
                    type="number"
                    value={formData.sellingPrice}
                    onChange={(e) => setFormData({ ...formData, sellingPrice: e.target.value })}
                    placeholder="५,५०,०००"
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  />
                </div>
              </div>

              {/* Owner details */}
              <div className="pt-2 border-t border-slate-100 space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      {lang === 'mr' ? 'तुमचे नाव *' : 'Your Name *'}
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.ownerName}
                      onChange={(e) => setFormData({ ...formData, ownerName: e.target.value })}
                      placeholder="उदा. सचिन तांबडे"
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      {lang === 'mr' ? 'मोबाईल नंबर *' : 'Phone Number *'}
                    </label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="९८२२००११२२"
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      {lang === 'mr' ? 'गाव' : 'Village'}
                    </label>
                    <input
                      type="text"
                      value={formData.village}
                      onChange={(e) => setFormData({ ...formData, village: e.target.value })}
                      placeholder="गाव"
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      {lang === 'mr' ? 'तालुका' : 'Taluka'}
                    </label>
                    <input
                      type="text"
                      value={formData.taluka}
                      onChange={(e) => setFormData({ ...formData, taluka: e.target.value })}
                      placeholder="तालुका"
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      {lang === 'mr' ? 'जिल्हा' : 'District'}
                    </label>
                    <select
                      value={formData.district}
                      onChange={(e) => setFormData({ ...formData, district: e.target.value })}
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                    >
                      {districts.filter(d => d !== 'all').map((d) => (
                        <option key={d} value={d}>{d}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 bg-slate-100 text-slate-700 rounded-xl font-bold"
                >
                  {lang === 'mr' ? 'रद्द करा' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-gradient-to-r from-[#1B5E20] to-emerald-700 text-white rounded-xl font-black shadow-lg"
                >
                  {lang === 'mr' ? 'अवजार लिस्ट करा ✓' : 'Submit Listing ✓'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
