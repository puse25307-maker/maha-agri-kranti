import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Language, TabType } from './types';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { Footer } from './components/Footer';
import { PWASplashScreen } from './components/PWASplashScreen';
import { PWAInstallBar } from './components/PWAInstallBar';
import { Wifi, Signal, Battery } from 'lucide-react';

// Tabs
import { TabHome } from './components/TabHome';
import { Tab1RogDoctor } from './components/Tab1RogDoctor';
import { TabSustainable } from './components/TabSustainable';
import { TabEquipmentHub } from './components/TabEquipmentHub';
import { TabProgressiveFarmers } from './components/TabProgressiveFarmers';
import { Tab2MatiPik } from './components/Tab2MatiPik';
import { Tab3MaharashtraConnect } from './components/Tab3MaharashtraConnect';
import { Tab4MahaBazaar } from './components/Tab4MahaBazaar';
import { Tab5UsBelt } from './components/Tab5UsBelt';
import { Tab6SarkariYojana } from './components/Tab6SarkariYojana';
import { Tab7JodDhanda } from './components/Tab7JodDhanda';
import { Tab8ExportDubaiIran } from './components/Tab8ExportDubaiIran';
import { Tab9DoctorHelpline } from './components/Tab9DoctorHelpline';
import { Tab10Shala } from './components/Tab10Shala';
import { TabMenu } from './components/TabMenu';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [lang, setLang] = useState<Language>('mr');
  const [currentTime, setCurrentTime] = useState<string>('09:41');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours().toString().padStart(2, '0');
      const mins = now.getMinutes().toString().padStart(2, '0');
      setCurrentTime(`${hours}:${mins}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  const handleToggleLang = () => {
    setLang((prev) => (prev === 'mr' ? 'en' : 'mr'));
  };

  const renderActiveTab = () => {
    switch (activeTab) {
      case 'home':
        return <TabHome key="tab_home" lang={lang} onNavigate={setActiveTab} />;
      case 'rog_doctor':
        return <Tab1RogDoctor key="tab_rog_doctor" />;
      case 'sustainable':
        return <TabSustainable key="tab_sustainable" lang={lang} onNavigate={setActiveTab} />;
      case 'equipment':
        return <TabEquipmentHub key="tab_equipment" lang={lang} />;
      case 'progressive_farmers':
        return <TabProgressiveFarmers key="tab_progressive_farmers" lang={lang} />;
      case 'maha_bazaar':
        return <Tab4MahaBazaar key="tab_maha_bazaar" />;
      case 'yojana':
        return <Tab6SarkariYojana key="tab_yojana" />;
      case 'menu':
        return <TabMenu key="tab_menu" lang={lang} onNavigate={setActiveTab} />;
      case 'mati_pik':
        return <Tab2MatiPik key="tab_mati_pik" />;
      case 'connect':
        return <Tab3MaharashtraConnect key="tab_connect" />;
      case 'us_belt':
        return <Tab5UsBelt key="tab_us_belt" />;
      case 'jod_dhanda':
        return <Tab7JodDhanda key="tab_jod_dhanda" />;
      case 'export':
        return <Tab8ExportDubaiIran key="tab_export" />;
      case 'doctor':
        return <Tab9DoctorHelpline key="tab_doctor" />;
      case 'shala':
        return <Tab10Shala key="tab_shala" />;
      default:
        return <TabHome key="tab_default" lang={lang} onNavigate={setActiveTab} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex justify-center items-start selection:bg-emerald-700 selection:text-white">
      {/* PWA Splash Screen on Launch */}
      <PWASplashScreen />

      {/* Mobile App Container (Native Android Phone Frame) */}
      <div className="w-full max-w-[430px] min-h-screen bg-[#FBFDFB] flex flex-col shadow-2xl relative border-x border-slate-200">
        {/* Android Native Status Bar */}
        <div className="bg-[#144818] text-white px-4 py-1 flex items-center justify-between text-[11px] font-semibold select-none border-b border-emerald-800/40">
          <div className="flex items-center gap-1">
            <span>{currentTime}</span>
            <span className="text-[9px] bg-amber-400 text-slate-950 font-black px-1 rounded-sm ml-1">5G</span>
          </div>
          <div className="flex items-center gap-1.5 text-emerald-200">
            <Signal className="w-3 h-3 text-emerald-200" />
            <Wifi className="w-3 h-3 text-emerald-200" />
            <div className="flex items-center gap-0.5">
              <span className="text-[10px] font-bold">100%</span>
              <Battery className="w-3.5 h-3.5 text-emerald-200" />
            </div>
          </div>
        </div>

        {/* PWA One-Click Install Banner */}
        <PWAInstallBar lang={lang} />

        {/* App Header with Bilingual toggle */}
        <Header lang={lang} onToggleLang={handleToggleLang} />

        {/* Dynamic Tab Content with Animation */}
        <main className="flex-1 p-3.5">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.16, ease: 'easeOut' }}
            >
              {renderActiveTab()}
            </motion.div>
          </AnimatePresence>

          {/* Footer Section */}
          <Footer lang={lang} />
        </main>

        {/* 5-Tab Clean Bottom Navigation */}
        <BottomNav activeTab={activeTab} lang={lang} onSelectTab={setActiveTab} />

        {/* Android Navigation Gesture Bar */}
        <div className="bg-white py-1.5 flex justify-center items-center border-t border-slate-100">
          <div className="w-32 h-1 bg-slate-300 rounded-full"></div>
        </div>
      </div>
    </div>
  );
}
