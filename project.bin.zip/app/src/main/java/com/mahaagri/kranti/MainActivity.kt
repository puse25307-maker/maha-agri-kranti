package com.mahaagri.kranti

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.mahaagri.kranti.data.models.TabType
import com.mahaagri.kranti.ui.components.MahaBottomBar
import com.mahaagri.kranti.ui.components.MahaHeader
import com.mahaagri.kranti.ui.screens.*
import com.mahaagri.kranti.ui.theme.BackgroundLight
import com.mahaagri.kranti.ui.theme.MahaAgriTheme
import com.mahaagri.kranti.viewmodel.AgriViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: AgriViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MahaAgriTheme {
                val uiState by viewModel.uiState.collectAsState()
                val userEquipmentListings by viewModel.userEquipment.collectAsState()

                // Display toast when message arrives
                LaunchedEffect(uiState.toastMessage) {
                    uiState.toastMessage?.let { msg ->
                        Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()
                        viewModel.clearToast()
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = BackgroundLight,
                    topBar = {
                        MahaHeader(
                            lang = uiState.language,
                            onToggleLang = { viewModel.toggleLanguage() },
                            onSpeakHeader = {
                                viewModel.speakText(
                                    if (uiState.language == com.mahaagri.kranti.data.models.Language.MARATHI)
                                        "महा ॲग्री क्रांती - महाराष्ट्रातील शेतकऱ्यांचे नंबर १ हरित कृषी ॲप"
                                    else
                                        "Maha Agri Kranti - Maharashtra's Number 1 Smart Agri App"
                                )
                            }
                        )
                    },
                    bottomBar = {
                        MahaBottomBar(
                            currentTab = uiState.currentTab,
                            lang = uiState.language,
                            onSelectTab = { tab -> viewModel.setTab(tab) }
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (uiState.currentTab) {
                            TabType.HOME -> HomeScreen(
                                lang = uiState.language,
                                onNavigate = { viewModel.setTab(it) },
                                onCallExpert = { makePhoneCall("9021458701") }
                            )
                            TabType.ROG_DOCTOR -> RogDoctorScreen(
                                lang = uiState.language,
                                selectedDisease = uiState.selectedDisease,
                                isScanning = uiState.isScanning,
                                onSelectDisease = { viewModel.selectDisease(it) },
                                onTriggerScan = { viewModel.simulateAiScan() },
                                onSpeakDisease = { text -> viewModel.speakText(text) },
                                onCallExpert = { makePhoneCall("9021458701") }
                            )
                            TabType.SUSTAINABLE -> SustainableScreen(
                                lang = uiState.language,
                                onNavigate = { viewModel.setTab(it) }
                            )
                            TabType.EQUIPMENT -> EquipmentHubScreen(
                                lang = uiState.language,
                                selectedCategory = uiState.equipmentFilter,
                                selectedListingType = uiState.equipmentListingFilter,
                                userListings = userEquipmentListings,
                                onSelectCategory = { viewModel.setEquipmentCategoryFilter(it) },
                                onSelectListingType = { viewModel.setEquipmentListingFilter(it) },
                                onAddEquipment = { title, category, type, rate, phone, loc ->
                                    viewModel.addUserEquipment(title, category, type, rate, phone, loc)
                                },
                                onCallPhone = { phone -> makePhoneCall(phone) }
                            )
                            TabType.PROGRESSIVE_FARMERS -> ProgressiveFarmersScreen(
                                lang = uiState.language,
                                selectedRegion = uiState.progressiveRegionFilter,
                                onSelectRegion = { viewModel.setProgressiveRegion(it) },
                                onCallFarmer = { phone -> makePhoneCall(phone) }
                            )
                            TabType.MAHA_BAZAAR -> MahaBazaarScreen(
                                lang = uiState.language,
                                searchQuery = uiState.mandiSearchQuery,
                                onSearchChange = { viewModel.setMandiSearch(it) },
                                onCallBuyer = { phone -> makePhoneCall(phone) }
                            )
                            TabType.YOJANA -> SarkariYojanaScreen(
                                lang = uiState.language,
                                searchQuery = uiState.yojanaSearchQuery,
                                onSearchChange = { viewModel.setYojanaSearch(it) },
                                onOpenLink = { url -> openWebLink(url) }
                            )
                            TabType.MENU -> MenuScreen(
                                lang = uiState.language,
                                onNavigate = { viewModel.setTab(it) }
                            )
                            TabType.US_BELT -> UsBeltScreen(
                                lang = uiState.language,
                                onBack = { viewModel.setTab(TabType.MENU) }
                            )
                            TabType.JOD_DHANDA -> JodDhandaScreen(
                                lang = uiState.language,
                                onBack = { viewModel.setTab(TabType.MENU) }
                            )
                            TabType.DOCTOR -> DoctorHelplineScreen(
                                lang = uiState.language,
                                onCallPhone = { makePhoneCall(it) },
                                onBack = { viewModel.setTab(TabType.MENU) }
                            )
                            TabType.MATI_PIK -> MatiPikScreen(
                                lang = uiState.language,
                                onBack = { viewModel.setTab(TabType.MENU) }
                            )
                            TabType.CONNECT -> ConnectScreen(
                                lang = uiState.language,
                                onBack = { viewModel.setTab(TabType.MENU) }
                            )
                            TabType.EXPORT -> ExportScreen(
                                lang = uiState.language,
                                onBack = { viewModel.setTab(TabType.MENU) }
                            )
                            TabType.SHALA -> ShalaScreen(
                                lang = uiState.language,
                                onBack = { viewModel.setTab(TabType.MENU) }
                            )
                        }
                    }
                }
            }
        }
    }

    private fun makePhoneCall(phoneNumber: String) {
        try {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber"))
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "कॉल जोडला जात आहे: $phoneNumber", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openWebLink(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "पोर्टल लिंक: $url", Toast.LENGTH_SHORT).show()
        }
    }
}
