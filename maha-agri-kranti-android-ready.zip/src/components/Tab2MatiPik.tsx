import React, { useState } from 'react';
import { 
  Sparkles, 
  Layers, 
  Calendar, 
  Volume2, 
  CheckCircle, 
  HelpCircle, 
  ArrowRight,
  TrendingUp,
  X,
  Droplet
} from 'lucide-react';
import { SUGARCANE_VARIETIES } from '../data/agriData';
import { SugarcaneVariety } from '../types';
import { speakMarathi } from '../utils/speech';

export const Tab2MatiPik: React.FC = () => {
  const [phValue, setPhValue] = useState<number>(6.8);
  const [selectedCrop, setSelectedCrop] = useState<string>('draksha_mirchi');
  const [comparingVarieties, setComparingVarieties] = useState<boolean>(false);
  const [activeVarietyModal, setActiveVarietyModal] = useState<SugarcaneVariety | null>(null);

  // NPK state
  const [nitrogen, setNitrogen] = useState<number>(240); // kg/ha
  const [phosphorus, setPhosphorus] = useState<number>(18); // kg/ha
  const [potash, setPotash] = useState<number>(310); // kg/ha

  const getPhAnalysis = (ph: number) => {
    if (ph < 6.0) {
      return {
        typeMr: 'आम्लधर्मी माती (Acidic Soil)',
        badgeColor: 'bg-red-600 text-white',
        status: 'दोष: अन्नद्रव्य शोषण मंदावते',
        remedyMr: 'उपाय: एकरी २०० किलो चुन्याची पूड (Dolomite Lime) मिसळा. सेंद्रिय शेणखत व गांडूळखत द्या.',
        isOptimal: false
      };
    } else if (ph >= 6.0 && ph <= 7.5) {
      return {
        typeMr: 'उत्तम सुपीक माती (Optimal Fertile Soil)',
        badgeColor: 'bg-emerald-600 text-white',
        status: 'सर्वोत्कृष्ट स्थिती: सर्व पिकांसाठी सुवर्णकाळ',
        remedyMr: 'उपाय: जिवाणू खते (PSB, Azotobacter) व ह्युमिक अ‍ॅसिड नियमित देऊन सुपीकता टिकवून ठेवा.',
        isOptimal: true
      };
    } else {
      return {
        typeMr: 'क्षारयुक्त / चोपण माती (Alkaline Soil)',
        badgeColor: 'bg-amber-600 text-white',
        status: 'दोष: पाण्याचा निचरा होत नाही, मुळे गुदमरतात',
        remedyMr: 'उपाय: एकरी ५०० किलो जिप्सम (Gypsum) द्या. ढेंचा किंवा ताग गाडून हिरवळीचे खत करा.',
        isOptimal: false
      };
    }
  };

  const phAnalysis = getPhAnalysis(phValue);

  const handleSpeakTriplePaisa = () => {
    const text = 'बारामती पॅटर्न ट्रिपल पैसा मॉडेल: १ एकर क्षेत्रामध्ये मुख्य पीक द्राक्ष १२ महिने ४ लाख रुपये, आंतरपीक मिरची ४ महिने ६० हजार रुपये, आणि भुईसर पीक मेथी किंवा कोथिंबीर १ महिना २० हजार रुपये. अशा प्रकारे १ एकरातून वर्षाला एकूण ४ लाख ८० हजार रुपयांचे भरघोस उत्पन्न मिळते.';
    speakMarathi(text);
  };

  const handleSpeakPh = () => {
    const text = `मातीचा सामू ${phValue} आहे. ही ${phAnalysis.typeMr} आहे. ${phAnalysis.remedyMr}`;
    speakMarathi(text);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Header Banner */}
      <div className="bg-gradient-to-br from-[#1B5E20] to-emerald-900 text-white p-3.5 rounded-2xl shadow-lg border border-emerald-500">
        <div className="flex items-center justify-between mb-1">
          <span className="bg-[#FFC107] text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
            🌱 माती परीक्षण व बहुपीक तंत्र
          </span>
          <span className="text-[10px] text-amber-300 font-bold">
            बारामती + राहुरी मॉडेल
          </span>
        </div>
        <h2 className="text-base font-black text-white leading-tight">
          मातीचा pH तपासा & बारामती पॅटर्नने ३ पट नफा कमवा!
        </h2>
        <p className="text-[11px] text-emerald-100 mt-0.5">
          १ एकर = द्राक्ष + मिरची + मेथी = ₹४,८०,००० वार्षिक उत्पन्न
        </p>
      </div>

      {/* 1. pH Soil Testing Slider Section */}
      <div className="bg-white p-4 rounded-2xl shadow-md border border-slate-200">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5">
            <span className="text-xl">🧪</span>
            <div>
              <h3 className="text-xs font-black text-slate-900">माती सामू (pH) चाचणी कॅल्क्युलेटर</h3>
              <p className="text-[10px] text-slate-500">स्लायडर फिरवून मातीचा प्रकार व उपाय पहा</p>
            </div>
          </div>
          <button
            onClick={handleSpeakPh}
            className="text-[10px] bg-amber-400 hover:bg-amber-500 text-slate-950 px-2 py-1 rounded-lg font-bold flex items-center gap-1 shadow-sm"
          >
            <Volume2 className="w-3 h-3" /> ऐका 🔊
          </button>
        </div>

        {/* Big pH Meter Display */}
        <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 mb-3 text-center">
          <div className="flex items-center justify-between mb-1 text-xs font-bold text-slate-600">
            <span>आम्ल (४.०)</span>
            <span className="text-2xl font-black text-emerald-800">pH {phValue.toFixed(1)}</span>
            <span>क्षार (९.०)</span>
          </div>

          <input
            type="range"
            min="4.0"
            max="9.0"
            step="0.1"
            value={phValue}
            onChange={(e) => setPhValue(parseFloat(e.target.value))}
            className="w-full h-3 bg-gradient-to-r from-red-500 via-emerald-500 to-amber-500 rounded-lg appearance-none cursor-pointer accent-[#1B5E20]"
          />

          <div className="mt-2.5 flex items-center justify-center gap-2">
            <span className={`text-[11px] font-black px-3 py-1 rounded-full shadow-sm ${phAnalysis.badgeColor}`}>
              {phAnalysis.typeMr}
            </span>
          </div>
        </div>

        {/* Dynamic Remedy Card */}
        <div className={`p-3 rounded-xl border text-xs ${phAnalysis.isOptimal ? 'bg-emerald-50 border-emerald-300 text-emerald-950' : 'bg-amber-50 border-amber-300 text-amber-950'}`}>
          <div className="font-black mb-1 flex items-center gap-1">
            {phAnalysis.isOptimal ? <CheckCircle className="w-4 h-4 text-emerald-700" /> : <HelpCircle className="w-4 h-4 text-amber-700" />}
            {phAnalysis.status}
          </div>
          <p className="font-semibold leading-relaxed text-slate-800">{phAnalysis.remedyMr}</p>
        </div>
      </div>

      {/* 2. Baramati Pattern Triple Paisa Card (Green) */}
      <div className="bg-gradient-to-br from-[#1B5E20] via-emerald-800 to-teal-900 text-white p-4 rounded-2xl shadow-xl border-2 border-[#FFC107] relative overflow-hidden">
        <div className="flex items-center justify-between mb-2">
          <span className="bg-[#FFC107] text-slate-950 text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1 shadow">
            <Sparkles className="w-3 h-3 text-red-700" /> बारामती पॅटर्न ट्रिपल पैसा कार्ड
          </span>
          <button
            onClick={handleSpeakTriplePaisa}
            className="text-[10px] bg-white/20 hover:bg-white/30 text-amber-300 px-2 py-0.5 rounded font-bold flex items-center gap-1"
          >
            <Volume2 className="w-3 h-3" /> ऐका 🔊
          </button>
        </div>

        <h3 className="text-sm font-black text-amber-300 leading-tight mb-2">
          १ एकर = द्राक्ष + मिरची + मेथी = वार्षिक ₹४,८०,०००
        </h3>

        {/* Triple Crop Breakdown */}
        <div className="space-y-2 mb-3">
          <div className="bg-white/10 p-2.5 rounded-xl backdrop-blur-sm border border-emerald-400/40 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-amber-300 font-bold block">१. वर मुख्य पीक (१२ महिने)</span>
              <span className="text-xs font-black text-white">🍇 द्राक्ष (Thomson Seedless)</span>
            </div>
            <span className="text-xs font-black text-amber-300 bg-emerald-950/80 px-2 py-1 rounded-lg border border-amber-400">
              ₹४,००,०००
            </span>
          </div>

          <div className="bg-white/10 p-2.5 rounded-xl backdrop-blur-sm border border-emerald-400/40 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-amber-300 font-bold block">२. मध्ये आंतरपीक (४ महिने)</span>
              <span className="text-xs font-black text-white">🌶️ मिरची (G-4 तिखट)</span>
            </div>
            <span className="text-xs font-black text-amber-300 bg-emerald-950/80 px-2 py-1 rounded-lg border border-amber-400">
              ₹६०,०००
            </span>
          </div>

          <div className="bg-white/10 p-2.5 rounded-xl backdrop-blur-sm border border-emerald-400/40 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-amber-300 font-bold block">३. खाली भुईसर पीक (१ महिना)</span>
              <span className="text-xs font-black text-white">🌿 मेथी / कोथिंबीर (Fast Cash)</span>
            </div>
            <span className="text-xs font-black text-amber-300 bg-emerald-950/80 px-2 py-1 rounded-lg border border-amber-400">
              ₹२०,०००
            </span>
          </div>
        </div>

        {/* Total Grand Sum */}
        <div className="bg-amber-400 text-slate-950 p-2.5 rounded-xl font-black text-center text-xs shadow-md border border-amber-200">
          एकूण निव्वळ नफा = ₹४,८०,००० / एकर / वर्ष 💰
        </div>

        {/* Calendar Timeline */}
        <div className="mt-3 bg-emerald-950/80 p-2.5 rounded-xl border border-emerald-600 text-[10px]">
          <span className="font-bold text-amber-300 block mb-1.5 flex items-center gap-1">
            <Calendar className="w-3 h-3" /> महिनावार कॅलेंडर वेळापत्रक:
          </span>
          <div className="grid grid-cols-3 gap-1 text-center">
            <div className="bg-emerald-900/60 p-1.5 rounded border border-emerald-700">
              <span className="font-bold text-amber-200 block">जून (June)</span>
              <span className="text-[9px] text-slate-300">द्राक्ष छाटणी</span>
            </div>
            <div className="bg-emerald-900/60 p-1.5 rounded border border-emerald-700">
              <span className="font-bold text-amber-200 block">जुलै (July)</span>
              <span className="text-[9px] text-slate-300">मिरची पुनर्लागवड</span>
            </div>
            <div className="bg-emerald-900/60 p-1.5 rounded border border-emerald-700">
              <span className="font-bold text-amber-200 block">ऑगस्ट (Aug)</span>
              <span className="text-[9px] text-slate-300">मेथी तोडणी (Cash)</span>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Sugarcane Bene Section (ऊस बेणे वाण निवड) */}
      <div className="bg-white p-4 rounded-2xl shadow-md border border-slate-200">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
              🎋 ऊस बेणे वाण निवड (Sugarcane Varieties)
            </h3>
            <p className="text-[10px] text-slate-500">महाराष्ट्रात सर्वाधिक वजन व साखर देणारे ३ वाण</p>
          </div>
          <button
            onClick={() => setComparingVarieties(!comparingVarieties)}
            className="bg-emerald-800 hover:bg-emerald-900 text-amber-300 text-[10px] font-black px-2.5 py-1 rounded-lg flex items-center gap-1 shadow-sm"
          >
            <Layers className="w-3 h-3" /> तुलना करा
          </button>
        </div>

        <div className="space-y-3">
          {SUGARCANE_VARIETIES.map((variety) => (
            <div
              key={variety.code}
              className="bg-gradient-to-r from-slate-50 to-emerald-50/50 p-3 rounded-xl border border-slate-200 hover:border-emerald-500 transition-all shadow-sm"
            >
              <div className="flex items-start justify-between gap-2 mb-1.5">
                <div>
                  <span className="text-[9px] bg-emerald-800 text-amber-300 font-bold px-1.5 py-0.5 rounded mr-1.5">
                    {variety.code}
                  </span>
                  <h4 className="text-xs font-black text-slate-950 inline">{variety.name}</h4>
                </div>
                <span className="text-[9px] bg-amber-100 text-amber-900 font-black px-1.5 py-0.5 rounded shrink-0">
                  {variety.sugarPercent}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[10px] mb-2">
                <div className="bg-white p-1.5 rounded border border-slate-100">
                  <span className="text-slate-500 block text-[9px]">उत्पादन क्षमता:</span>
                  <span className="font-bold text-emerald-900">{variety.yieldTon}</span>
                </div>
                <div className="bg-white p-1.5 rounded border border-slate-100">
                  <span className="text-slate-500 block text-[9px]">पाणी गरज:</span>
                  <span className="font-bold text-slate-800">{variety.waterRequirement}</span>
                </div>
              </div>

              <p className="text-[10px] text-slate-700 font-medium mb-2 leading-relaxed">
                {variety.highlightMr}
              </p>

              <div className="flex items-center justify-between pt-1 border-t border-slate-200">
                <span className="text-[9px] text-emerald-800 font-bold">
                  ⭐ {variety.popularity}
                </span>
                <button
                  onClick={() => {
                    setActiveVarietyModal(variety);
                    speakMarathi(`${variety.name}: उत्पादन क्षमता ${variety.yieldTon}. साखर उतारा ${variety.sugarPercent}.`);
                  }}
                  className="text-[10px] font-bold text-emerald-900 hover:text-emerald-700 flex items-center gap-0.5"
                >
                  तपशील पहा <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Comparison Modal */}
      {comparingVarieties && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-3">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl border-2 border-emerald-600 overflow-hidden">
            <div className="bg-[#1B5E20] text-white p-3 flex items-center justify-between">
              <h3 className="font-bold text-xs text-amber-300">३ ऊस वाणांची तुलना (Variety Comparison)</h3>
              <button onClick={() => setComparingVarieties(false)} className="text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-3 text-[10px] space-y-2 overflow-x-auto">
              <table className="w-full border-collapse border border-slate-200 text-left">
                <thead>
                  <tr className="bg-slate-100">
                    <th className="p-1.5 border border-slate-200">वैशिष्ट्ये</th>
                    <th className="p-1.5 border border-slate-200 font-bold text-emerald-900">Co 86032</th>
                    <th className="p-1.5 border border-slate-200 font-bold text-emerald-900">Phule 265</th>
                    <th className="p-1.5 border border-slate-200 font-bold text-emerald-900">CoVSI 18121</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="p-1.5 border border-slate-200 font-semibold">एकरी वजन</td>
                    <td className="p-1.5 border border-slate-200">११०-१३५ टन</td>
                    <td className="p-1.5 border border-slate-200 font-bold text-emerald-800">१५६ टन (Super)</td>
                    <td className="p-1.5 border border-slate-200">१५० टन</td>
                  </tr>
                  <tr className="bg-slate-50">
                    <td className="p-1.5 border border-slate-200 font-semibold">साखर उतारा</td>
                    <td className="p-1.5 border border-slate-200">१२.५%</td>
                    <td className="p-1.5 border border-slate-200">१३.१%</td>
                    <td className="p-1.5 border border-slate-200 font-bold text-emerald-800">१३.५% (Highest)</td>
                  </tr>
                  <tr>
                    <td className="p-1.5 border border-slate-200 font-semibold">पाणी गरज</td>
                    <td className="p-1.5 border border-slate-200">मध्यम</td>
                    <td className="p-1.5 border border-slate-200">जास्त</td>
                    <td className="p-1.5 border border-slate-200 font-bold text-emerald-800">कमी (ठिबक)</td>
                  </tr>
                  <tr className="bg-slate-50">
                    <td className="p-1.5 border border-slate-200 font-semibold">कारखाना पसंती</td>
                    <td className="p-1.5 border border-slate-200 font-bold">८२% नंबर १</td>
                    <td className="p-1.5 border border-slate-200">वजनासाठी उत्तम</td>
                    <td className="p-1.5 border border-slate-200">नवीन २०२४ वाण</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div className="p-2.5 bg-slate-50 text-right border-t">
              <button
                onClick={() => setComparingVarieties(false)}
                className="bg-slate-800 text-white text-xs px-4 py-1.5 rounded-lg font-bold"
              >
                बंद करा
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
