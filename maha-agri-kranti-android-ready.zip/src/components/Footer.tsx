import React, { useState } from 'react';
import { Sparkles, Leaf, Volume2, VolumeX } from 'lucide-react';
import { Language } from '../types';
import { speakText, stopSpeech, isSpeaking } from '../utils/speech';

interface FooterProps {
  lang?: Language;
}

export const Footer: React.FC<FooterProps> = ({ lang = 'mr' }) => {
  const currentLang: Language = lang === 'en' ? 'en' : 'mr';
  const [isPlaying, setIsPlaying] = useState(false);

  const handleVoiceSlogan = () => {
    if (isPlaying || isSpeaking()) {
      stopSpeech();
      setIsPlaying(false);
      return;
    }

    setIsPlaying(true);
    const text = currentLang === 'mr' ? 'जय महाराष्ट्र!' : 'Jai Maharashtra!';

    speakText(
      text,
      currentLang,
      () => setIsPlaying(false),
      () => setIsPlaying(false)
    );
  };

  return (
    <footer className="mt-8 mb-24 px-1 text-center">
      <div className="bg-gradient-to-br from-slate-950 via-[#0e3b16] to-[#08200d] text-white p-5 rounded-3xl border-2 border-[#FFC107] shadow-xl relative overflow-hidden">
        {/* Ambient Glow */}
        <div className="absolute top-0 right-0 -mr-8 -mt-8 w-32 h-32 bg-amber-400/20 rounded-full blur-2xl pointer-events-none" />

        {/* Brand Badge */}
        <div className="inline-flex items-center gap-1.5 bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 px-3.5 py-1 rounded-full text-[11px] font-black uppercase tracking-wider mb-3 shadow-md">
          <Sparkles className="w-3.5 h-3.5 text-slate-950 fill-amber-950" />
          <span>{lang === 'mr' ? '🌱 हरित कृषी क्रांती' : '🌱 HARIT KRUSHI KRANTI'}</span>
        </div>

        {/* Pure & Clean Jay Maharashtra Slogan */}
        <div 
          onClick={handleVoiceSlogan}
          className="cursor-pointer group bg-gradient-to-r from-amber-950/60 via-orange-950/40 to-amber-950/60 p-4 rounded-2xl border border-amber-400/70 shadow-inner hover:border-amber-300 hover:scale-[1.01] transition-all my-2 flex flex-col items-center justify-center gap-1.5"
          title={lang === 'mr' ? 'जय महाराष्ट्र ऐका' : 'Listen Jai Maharashtra'}
        >
          <span className="text-2xl animate-pulse select-none">🚩</span>
          <h3 className="text-2xl font-black text-amber-300 tracking-wider drop-shadow-md py-0.5 font-sans">
            || Jay Maharashtra ||
          </h3>
          <span className="text-2xl animate-pulse select-none">🚩</span>

          <div className="mt-1.5 flex items-center justify-center gap-1.5 text-[11px] font-bold text-amber-300/90 group-hover:text-amber-200">
            {isPlaying ? (
              <>
                <VolumeX className="w-3.5 h-3.5 text-amber-300 animate-spin" />
                <span>{lang === 'mr' ? 'आवाज सुरू आहे (थांबवण्यासाठी दाबा)' : 'Playing audio (tap to stop)'}</span>
              </>
            ) : (
              <>
                <Volume2 className="w-3.5 h-3.5 text-amber-300" />
                <span>{lang === 'mr' ? 'घोषणा ऐका 🔊' : 'Listen Slogan 🔊'}</span>
              </>
            )}
          </div>
        </div>

        {/* Mission Statement */}
        <p className="text-xs text-emerald-100 mt-3 font-medium leading-relaxed max-w-md mx-auto">
          {lang === 'mr'
            ? 'महाराष्ट्रातील प्रत्येक शेतकऱ्याच्या सेवेसाठी समर्पित डिजिटल कृषी व्यासपीठ.'
            : 'Dedicated digital agriculture platform for the farmers of Maharashtra.'}
        </p>

        {/* Bottom copyright */}
        <div className="mt-3.5 pt-3 border-t border-emerald-800/80 flex items-center justify-between text-[10px] text-slate-300">
          <span className="flex items-center gap-1 text-amber-300 font-bold">
            <Leaf className="w-3.5 h-3.5 text-emerald-400" />
            {lang === 'mr' ? 'शाश्वत शेती' : 'Sustainable Agri'}
          </span>
          <span className="text-emerald-300 font-bold">
            {lang === 'mr' ? 'बळीराजा सशक्तीकरण' : 'Farmer Empowerment'}
          </span>
        </div>
      </div>
    </footer>
  );
};



