import React, { useState } from 'react';
import { 
  Plane, 
  Sparkles, 
  Camera, 
  Calculator, 
  PhoneCall, 
  TrendingUp, 
  ShieldCheck, 
  DollarSign, 
  Volume2, 
  CheckCircle2,
  X
} from 'lucide-react';
import { speakMarathi } from '../utils/speech';

export const Tab8ExportDubaiIran: React.FC = () => {
  // Calculator state
  const [calcQuantityKg, setCalcQuantityKg] = useState<number>(5000); // 5 Ton
  const [calcExportRate, setCalcExportRate] = useState<number>(125); // Iran rate
  const [calcLocalRate, setCalcLocalRate] = useState<number>(18); // Local APMC rate
  const [qualityCheckModal, setQualityCheckModal] = useState<boolean>(false);
  const [callAlert, setCallAlert] = useState<string | null>(null);

  const localEarnings = calcQuantityKg * calcLocalRate;
  const exportEarnings = calcQuantityKg * calcExportRate;
  const netJackpotProfit = exportEarnings - localEarnings;
  const multiplier = (exportEarnings / (localEarnings || 1)).toFixed(1);

  const handleSpeakIranJackpot = () => {
    const text = 'इंदापूरची केळी थेट इराणला १२५ रुपये प्रति किलोने निर्यात होत आहे. स्थानिक बाजारातील १५ रुपयांच्या तुलनेत हा तब्बल सात पट जॅकपॉट नफा आहे. अपेडा पॅकिंग नियमांनुसार माल भरल्यास अवघ्या २१ दिवसांत बँक खात्यात थेट पेमेंट जमा होते.';
    speakMarathi(text);
  };

  const handleCallExporter = (name: string, phone: string) => {
    setCallAlert(`📞 ${name} यांच्या निर्यात कक्षाशी संपर्क जोडला जात आहे... फोन: ${phone}`);
    speakMarathi(`${name} यांच्याशी थेट संपर्क साधला जात आहे.`);
    setTimeout(() => setCallAlert(null), 4000);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Call Alert */}
      {callAlert && (
        <div className="fixed top-16 left-3 right-3 z-50 bg-slate-950 text-amber-300 p-3 rounded-2xl shadow-2xl border-2 border-[#FFC107] text-xs font-bold animate-bounce flex items-center justify-between">
          <span>{callAlert}</span>
          <button onClick={() => setCallAlert(null)} className="text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-gradient-to-br from-[#1B5E20] via-emerald-800 to-slate-900 text-white p-3.5 rounded-2xl shadow-lg border border-emerald-500">
        <div className="flex items-center justify-between mb-1">
          <span className="bg-[#FFC107] text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
            ✈️ थेट परदेशात शेतमाल निर्यात
          </span>
          <span className="text-[10px] text-amber-300 font-bold">
            दुबई & इराण कॉरिडॉर
          </span>
        </div>
        <h2 className="text-base font-black text-white leading-tight">
          इराण व दुबईला माल विका — ७ पट जॅकपॉट नफा मिळवा!
        </h2>
        <p className="text-[11px] text-emerald-100 mt-0.5">
          APEDA प्रमाणित पॅकिंग, कंटेनर बुकिंग व हमी थेट पेमेंट
        </p>
      </div>

      {/* 1. GREEN GRADIENT CARD: Nashik Grapes Dubai Market */}
      <div className="bg-gradient-to-br from-emerald-700 via-[#1B5E20] to-teal-900 text-white p-4 rounded-2xl shadow-xl border-2 border-emerald-400 relative overflow-hidden">
        <div className="flex items-center justify-between mb-2">
          <span className="bg-white/20 text-amber-300 text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1">
            🍇 नाशिक द्राक्षे दुबई थेट निर्यात
          </span>
          <span className="bg-[#FFC107] text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full">
            ४ पट नफा (4x Profit)
          </span>
        </div>

        <div className="flex items-start justify-between gap-2 mb-3">
          <div>
            <h3 className="text-sm font-black text-white leading-tight">
              नाशिक द्राक्ष दुबई मार्केट: ₹१२० / किलो
            </h3>
            <p className="text-[11px] text-emerald-200 mt-0.5">
              लोकल आडत भाव फक्त ₹३०/kg असताना थेट ४००% जादा परतावा
            </p>
          </div>
        </div>

        <div className="bg-emerald-950/70 p-2.5 rounded-xl border border-emerald-600 mb-3 text-xs flex items-center justify-between">
          <span className="text-emerald-200">१० टन द्राक्षांचे उत्पन्न:</span>
          <div className="text-right">
            <span className="font-black text-amber-300 text-sm">₹१२,००,००० (दुबई)</span>
            <span className="text-[9px] text-slate-400 line-through block">₹३,००,००० (लोकल)</span>
          </div>
        </div>

        <button
          onClick={() => setQualityCheckModal(true)}
          className="w-full bg-white text-[#1B5E20] hover:bg-emerald-50 font-black py-2.5 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all"
        >
          <Camera className="w-4 h-4 text-emerald-700" />
          <span>📸 क्वालिटी चेक फोटो काढा (Export Quality Check)</span>
        </button>
      </div>

      {/* 2. GOLD PULSING IRAN JACKPOT CARD */}
      <div className="bg-gradient-to-br from-amber-400 via-amber-300 to-yellow-400 text-slate-950 p-4 rounded-2xl shadow-xl border-2 border-red-600 gold-pulse relative overflow-hidden">
        <div className="flex items-center justify-between mb-2">
          <span className="bg-red-600 text-white text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1 shadow animate-pulse">
            <Sparkles className="w-3 h-3 text-amber-300" /> ⭐ ७x जॅकपॉट ऑफर (JACKPOT)
          </span>
          <button
            onClick={handleSpeakIranJackpot}
            className="text-[10px] bg-slate-950 text-amber-300 px-2 py-0.5 rounded font-bold flex items-center gap-1"
          >
            <Volume2 className="w-3 h-3" /> ऐका 🔊
          </button>
        </div>

        <h3 className="text-base font-black text-slate-950 leading-tight mb-1">
          इंदापूर केळी थेट इराण — ₹१२५ / किलो!
        </h3>
        <p className="text-xs text-slate-900 font-semibold mb-3">
          लोकल ₹१५/kg च्या तुलनेत ७ पट जॅकपॉट! २१ दिवसांत थेट बँक खात्यात पैसे जमा.
        </p>

        {/* 10 Ton Comparison Box */}
        <div className="bg-white/90 p-3 rounded-xl border border-amber-400 space-y-1 text-xs mb-3">
          <div className="flex justify-between font-bold text-slate-700">
            <span>लोकल मार्केट (१० टन):</span>
            <span className="line-through text-red-700 font-black">₹१,५०,०००</span>
          </div>
          <div className="flex justify-between font-black text-emerald-950 text-sm pt-1 border-t border-slate-200">
            <span>इराण थेट निर्यात (१० टन):</span>
            <span className="text-red-700 font-black text-base">₹१२,५०,०००</span>
          </div>
          <div className="text-[10px] text-emerald-800 font-bold text-center pt-0.5">
            निव्वळ जादा नफा = ₹११,००,००० (अकरा लाख रुपये!) 💰
          </div>
        </div>

        <button
          onClick={() => handleCallExporter('इंदापूर बनाना क्लस्टर APEDA इराण', '9822098450')}
          className="w-full bg-slate-950 hover:bg-slate-900 text-amber-300 font-black py-2.5 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95"
        >
          <Plane className="w-4 h-4 text-amber-400" />
          <span>इराण कंटेनर बुकिंगसाठी थेट संपर्क करा</span>
        </button>
      </div>

      {/* 3. Interactive Bhav & Profit Calculator */}
      <div className="bg-white p-4 rounded-2xl shadow-md border border-slate-200">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
            <Calculator className="w-4 h-4 text-[#1B5E20]" />
            थेट निर्यात नफा कॅल्क्युलेटर (Profit Calculator):
          </h3>
          <span className="text-[9px] bg-amber-100 text-amber-900 font-bold px-2 py-0.5 rounded-full">
            KG x Rate
          </span>
        </div>

        <div className="space-y-3 text-xs">
          <div>
            <div className="flex justify-between text-slate-700 font-bold mb-1">
              <span>एकूण शेतमाल वजन (किलो / Kg):</span>
              <span className="text-emerald-800 font-black">{calcQuantityKg.toLocaleString('en-IN')} किलो ({(calcQuantityKg / 1000).toFixed(1)} टन)</span>
            </div>
            <input
              type="range"
              min="500"
              max="20000"
              step="500"
              value={calcQuantityKg}
              onChange={(e) => setCalcQuantityKg(parseInt(e.target.value))}
              className="w-full h-2.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-[#1B5E20]"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="font-bold text-slate-700 block text-[10px] mb-1">निर्यात भाव (₹/kg):</label>
              <input
                type="number"
                value={calcExportRate}
                onChange={(e) => setCalcExportRate(parseFloat(e.target.value) || 0)}
                className="w-full p-2 border border-emerald-300 rounded-lg font-black text-emerald-800 text-xs"
              />
            </div>
            <div>
              <label className="font-bold text-slate-700 block text-[10px] mb-1">लोकल APMC भाव (₹/kg):</label>
              <input
                type="number"
                value={calcLocalRate}
                onChange={(e) => setCalcLocalRate(parseFloat(e.target.value) || 0)}
                className="w-full p-2 border border-slate-300 rounded-lg font-bold text-slate-600 text-xs"
              />
            </div>
          </div>

          {/* Calculator Output */}
          <div className="bg-gradient-to-br from-slate-900 to-emerald-950 text-white p-3 rounded-xl space-y-1.5">
            <div className="flex justify-between text-[11px] text-slate-300">
              <span>लोकल मार्केट कमाई:</span>
              <span className="font-bold">₹{localEarnings.toLocaleString('en-IN')}</span>
            </div>
            <div className="flex justify-between text-xs text-amber-300 font-bold">
              <span>निर्यात मार्केट कमाई:</span>
              <span className="font-black text-sm">₹{exportEarnings.toLocaleString('en-IN')}</span>
            </div>
            <div className="pt-1.5 border-t border-slate-700 flex justify-between items-center text-xs font-black text-white">
              <span>तुमचा निव्वळ जादा नफा:</span>
              <span className="text-amber-400 text-base font-black">
                +₹{netJackpotProfit.toLocaleString('en-IN')} ({multiplier}x)
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 4. APEDA Approved Exporters List */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
            🏢 APEDA प्रमाणित निर्यातदार सूची (Approved Exporters):
          </h3>
          <span className="text-[10px] text-emerald-800 font-bold">
            थेट फोन करा
          </span>
        </div>

        <div className="space-y-2 text-xs">
          {[
            { name: 'बारामती अ‍ॅग्रो फूड्स (इराण व दुबई)', loc: 'पिंपळी, बारामती', phone: '02112-245100', cert: 'APEDA Approved' },
            { name: 'देसाई फ्रूट्स (इंदापूर इराण स्पेशल)', loc: 'इंदापूर बेल्ट', phone: '9922458712', cert: '७ दिवसांत पेमेंट' },
            { name: 'सह्याद्री फार्म्स (नाशिक युरोप एक्सपोर्ट)', loc: 'दिंडोरी रोड, नाशिक', phone: '0253-2405000', cert: 'GlobalGAP Certified' }
          ].map((exp, idx) => (
            <div key={idx} className="bg-white p-3 rounded-2xl shadow-md border border-slate-200 flex items-center justify-between">
              <div>
                <h4 className="font-black text-xs text-slate-950">{exp.name}</h4>
                <span className="text-[10px] text-slate-500">{exp.loc} • <span className="text-emerald-800 font-bold">{exp.cert}</span></span>
              </div>
              <button
                onClick={() => handleCallExporter(exp.name, exp.phone)}
                className="bg-[#1B5E20] hover:bg-emerald-800 text-amber-300 font-black px-3 py-1.5 rounded-xl text-xs flex items-center gap-1 shadow active:scale-95"
              >
                <PhoneCall className="w-3.5 h-3.5 text-amber-400" />
                <span>CALL</span>
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Quality Check Camera Modal */}
      {qualityCheckModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl border-2 border-emerald-600 overflow-hidden">
            <div className="bg-[#1B5E20] text-white p-3 flex items-center justify-between">
              <h3 className="font-bold text-xs text-amber-300">📸 एक्सपोर्ट क्वालिटी चेक (AI Grading)</h3>
              <button onClick={() => setQualityCheckModal(false)} className="text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 space-y-3 text-xs text-center">
              <div className="w-16 h-16 mx-auto bg-emerald-50 rounded-full flex items-center justify-center border-2 border-emerald-300 text-emerald-800">
                <ShieldCheck className="w-9 h-9" />
              </div>
              <h4 className="font-black text-sm text-slate-900">APEDA एक्सपोर्ट ग्रेड मानके:</h4>
              <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-left space-y-1 text-[11px] text-slate-700">
                <p>✓ <strong>केळी:</strong> फिंगर लांबी १८-२२ सेमी, कॅलिबर ३९-४३ मिमी, शून्य डाग.</p>
                <p>✓ <strong>द्राक्षे:</strong> मणी आकार १८+ मिमी, साखर १८+ Brix, हिरवा दांडा.</p>
                <p>✓ <strong>पेरू/आंबा:</strong> एकसमान आकार, केमिकल अवशेष शून्य (Zero MRL).</p>
              </div>
              <button
                onClick={() => {
                  setQualityCheckModal(false);
                  speakMarathi('तुमचा माल ९५ टक्के एक्सपोर्ट ग्रेड आहे. इराण आणि दुबईसाठी पात्र ठरला आहे.');
                }}
                className="w-full bg-[#1B5E20] text-white font-bold py-2.5 rounded-xl"
              >
                फोटो स्कॅन पूर्ण करा (Pass AI Check)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
