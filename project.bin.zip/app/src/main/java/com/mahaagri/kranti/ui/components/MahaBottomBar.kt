package com.mahaagri.kranti.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mahaagri.kranti.data.models.Language
import com.mahaagri.kranti.data.models.TabType
import com.mahaagri.kranti.ui.theme.*

data class BottomNavItem(
    val tab: TabType,
    val labelMr: String,
    val labelEn: String,
    val icon: ImageVector
)

@Composable
fun MahaBottomBar(
    currentTab: TabType,
    lang: Language,
    onSelectTab: (TabType) -> Unit
) {
    val items = listOf(
        BottomNavItem(TabType.HOME, "होम", "Home", Icons.Default.Home),
        BottomNavItem(TabType.ROG_DOCTOR, "रोग AI", "Doc AI", Icons.Default.CameraAlt),
        BottomNavItem(TabType.SUSTAINABLE, "शाश्वत विकास", "Green Agri", Icons.Default.Eco),
        BottomNavItem(TabType.MAHA_BAZAAR, "महा बाजार", "Market", Icons.Default.ShoppingBag),
        BottomNavItem(TabType.MENU, "मेनू ≡", "Menu ≡", Icons.Default.Menu)
    )

    val isMenuSubTab = currentTab in listOf(
        TabType.MATI_PIK, TabType.CONNECT, TabType.US_BELT,
        TabType.YOJANA, TabType.JOD_DHANDA, TabType.EXPORT,
        TabType.DOCTOR, TabType.SHALA, TabType.EQUIPMENT,
        TabType.PROGRESSIVE_FARMERS, TabType.MENU
    )

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color.White,
        shadowElevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(vertical = 6.dp, horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEach { item ->
                val isSelected = if (item.tab == TabType.MENU) isMenuSubTab else currentTab == item.tab

                Column(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onSelectTab(item.tab) }
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) Green100 else Color.Transparent),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.labelEn,
                            tint = if (isSelected) Green800 else Slate500,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Text(
                        text = if (lang == Language.MARATHI) item.labelMr else item.labelEn,
                        color = if (isSelected) Green800 else Slate600,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Black else FontWeight.Medium
                    )

                    if (isSelected) {
                        Box(
                            modifier = Modifier
                                .padding(top = 2.dp)
                                .size(4.dp)
                                .clip(CircleShape)
                                .background(Green800)
                        )
                    }
                }
            }
        }
    }
}
