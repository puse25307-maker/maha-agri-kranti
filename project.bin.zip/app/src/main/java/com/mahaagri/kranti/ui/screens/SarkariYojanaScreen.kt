package com.mahaagri.kranti.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mahaagri.kranti.data.datasource.AgriDatabase
import com.mahaagri.kranti.data.models.Language
import com.mahaagri.kranti.ui.theme.*

@Composable
fun SarkariYojanaScreen(
    lang: Language,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    onOpenLink: (String) -> Unit
) {
    val list = AgriDatabase.yojanaList.filter {
        searchQuery.isBlank() || it.nameMr.contains(searchQuery, ignoreCase = true) || it.categoryMr.contains(searchQuery, ignoreCase = true)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = if (lang == Language.MARATHI) "सरकारी कृषी योजना व थेट अनुदान 🏛️" else "Government Schemes & Subsidies 🏛️",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    color = Slate900
                )
                Text(
                    text = if (lang == Language.MARATHI)
                        "MahaDBT, PM-KUSUM, नमो शेतकरी योजनांचे १००% अचूक नियम, पात्रता व कागदपत्रे."
                    else
                        "Complete rules, eligibility & application portals for all Maharashtra agri schemes.",
                    fontSize = 11.sp,
                    color = Slate600
                )

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchChange,
                    placeholder = { Text("योजना शोधा (उदा. सौर पंप, नमो शेतकरी, ठिबक)") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Slate500) },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    )
                )
            }
        }

        items(list) { yojana ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Amber100)
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(text = yojana.subsidyTag, fontSize = 9.sp, fontWeight = FontWeight.Black, color = Slate900)
                    }

                    Text(
                        text = yojana.nameMr,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        color = Slate900
                    )

                    Text(
                        text = yojana.benefitMr,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Green800
                    )

                    Text(
                        text = yojana.descriptionMr,
                        fontSize = 11.sp,
                        color = Slate700,
                        lineHeight = 15.sp
                    )

                    // Eligibility
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(text = "पात्रता निकष:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Slate900)
                        yojana.eligibilityMr.forEach { el ->
                            Text(text = "• $el", fontSize = 10.sp, color = Slate600)
                        }
                    }

                    // Documents
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(text = "आवश्यक कागदपत्रे:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Slate900)
                        yojana.documentsMr.forEach { doc ->
                            Text(text = "📄 $doc", fontSize = 10.sp, color = Slate600)
                        }
                    }

                    Button(
                        onClick = { onOpenLink(yojana.applyLink) },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Green800),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.OpenInBrowser, contentDescription = null, tint = Amber500, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (lang == Language.MARATHI) "शासकीय पोर्टलवर थेट अर्ज करा" else "Apply on MahaDBT Portal",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
