import React, { useState } from 'react';
import { 
  Sprout, 
  Users, 
  Factory, 
  Coins, 
  PlaneTakeoff, 
  PhoneCall, 
  GraduationCap, 
  ChevronRight, 
  Leaf,
  Landmark,
  ShieldCheck,
  Award,
  Tractor,
  Star,
  Smartphone,
  Code2,
  Copy,
  Check,
  X
} from 'lucide-react';
import { Language, TabType } from '../types';

interface TabMenuProps {
  lang: Language;
  onNavigate: (tab: TabType) => void;
}

export const TabMenu: React.FC<TabMenuProps> = ({ lang, onNavigate }) => {
  const [showAndroidModal, setShowAndroidModal] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [selectedFileKey, setSelectedFileKey] = useState<'main' | 'viewmodel' | 'database' | 'home' | 'doctor' | 'gradle'>('main');

  const androidFiles = {
    main: {
      name: 'MainActivity.kt',
      path: 'app/src/main/java/com/mahaagri/kranti/MainActivity.kt',
      code: `package com.mahaagri.kranti

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.mahaagri.kranti.data.models.TabType
import com.mahaagri.kranti.ui.components.MahaBottomBar
import com.mahaagri.kranti.ui.components.MahaHeader
import com.mahaagri.kranti.ui.screens.*
import com.mahaagri.kranti.ui.theme.MahaAgriTheme
import com.mahaagri.kranti.viewmodel.AgriViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: AgriViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MahaAgriTheme {
                val uiState by viewModel.uiState.collectAsState()
                val userListings by viewModel.userEquipment.collectAsState()

                Scaffold(
                    topBar = {
                        MahaHeader(
                            lang = uiState.language,
                            onToggleLang = { viewModel.toggleLanguage() },
                            onSpeakHeader = { viewModel.speakText("महा ॲग्री क्रांती") }
                        )
                    },
                    bottomBar = {
                        MahaBottomBar(
                            currentTab = uiState.currentTab,
                            lang = uiState.language,
                            onSelectTab = { tab -> viewModel.setTab(tab) }
                        )
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                        when (uiState.currentTab) {
                            TabType.HOME -> HomeScreen(uiState.language, onNavigate = { viewModel.setTab(it) }, onCallExpert = { makePhoneCall("9021458701") })
                            TabType.ROG_DOCTOR -> RogDoctorScreen(uiState.language, uiState.selectedDisease, uiState.isScanning, { viewModel.selectDisease(it) }, { viewModel.simulateAiScan() }, { viewModel.speakText(it) }, { makePhoneCall("9021458701") })
                            TabType.SUSTAINABLE -> SustainableScreen(uiState.language, onNavigate = { viewModel.setTab(it) })
                            TabType.EQUIPMENT -> EquipmentHubScreen(uiState.language, uiState.equipmentFilter, uiState.equipmentListingFilter, userListings, { viewModel.setEquipmentCategoryFilter(it) }, { viewModel.setEquipmentListingFilter(it) }, { t, c, ty, r, p, l -> viewModel.addUserEquipment(t, c, ty, r, p, l) }, { makePhoneCall(it) })
                            TabType.PROGRESSIVE_FARMERS -> ProgressiveFarmersScreen(uiState.language, uiState.progressiveRegionFilter, { viewModel.setProgressiveRegion(it) }, { makePhoneCall(it) })
                            TabType.MAHA_BAZAAR -> MahaBazaarScreen(uiState.language, uiState.mandiSearchQuery, { viewModel.setMandiSearch(it) }, { makePhoneCall(it) })
                            TabType.YOJANA -> SarkariYojanaScreen(uiState.language, uiState.yojanaSearchQuery, { viewModel.setYojanaSearch(it) }, { openWebLink(it) })
                            TabType.MENU -> MenuScreen(uiState.language, onNavigate = { viewModel.setTab(it) })
                            else -> HomeScreen(uiState.language, onNavigate = { viewModel.setTab(it) }, onCallExpert = { makePhoneCall("9021458701") })
                        }
                    }
                }
            }
        }
    }
}`
    },
    viewmodel: {
      name: 'AgriViewModel.kt',
      path: 'app/src/main/java/com/mahaagri/kranti/viewmodel/AgriViewModel.kt',
      code: `package com.mahaagri.kranti.viewmodel

import android.app.Application
import android.speech.tts.TextToSpeech
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mahaagri.kranti.MahaAgriApplication
import com.mahaagri.kranti.data.datasource.AgriDatabase
import com.mahaagri.kranti.data.models.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Locale

class AgriViewModel(application: Application) : AndroidViewModel(application) {
    private val db = (application as MahaAgriApplication).database
    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()
    val userEquipment = db.userEquipmentDao().getAllEquipment().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setTab(tab: TabType) { _uiState.update { it.copy(currentTab = tab) } }
    fun toggleLanguage() { _uiState.update { it.copy(language = if (it.language == Language.MARATHI) Language.ENGLISH else Language.MARATHI) } }
}`
    },
    database: {
      name: 'RoomEntitiesAndDao.kt',
      path: 'app/src/main/java/com/mahaagri/kranti/data/local/RoomEntitiesAndDao.kt',
      code: `package com.mahaagri.kranti.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "scan_history")
data class ScanHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cropName: String,
    val diseaseName: String,
    val severityPercent: Int,
    val scannedDate: String
)

@Dao
interface ScanHistoryDao {
    @Query("SELECT * FROM scan_history ORDER BY id DESC")
    fun getAllHistory(): Flow<List<ScanHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScan(scan: ScanHistoryEntity)
}`
    },
    home: {
      name: 'HomeScreen.kt',
      path: 'app/src/main/java/com/mahaagri/kranti/ui/screens/HomeScreen.kt',
      code: `@Composable
fun HomeScreen(
    lang: Language,
    onNavigate: (TabType) -> Unit,
    onCallExpert: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            // Native Compose Hero Card with 90% Subsidies, AI Scanner & Mandi Rates
        }
    }
}`
    },
    doctor: {
      name: 'RogDoctorScreen.kt',
      path: 'app/src/main/java/com/mahaagri/kranti/ui/screens/RogDoctorScreen.kt',
      code: `@Composable
fun RogDoctorScreen(
    lang: Language,
    selectedDisease: DiseaseInfo,
    isScanning: Boolean,
    onSelectDisease: (DiseaseInfo) -> Unit,
    onTriggerScan: () -> Unit,
    onSpeakDisease: (String) -> Unit,
    onCallExpert: () -> Unit
) {
    // Jetpack Compose 95% AI Crop Disease Scanner with offline dosage calculation
}`
    },
    gradle: {
      name: 'app/build.gradle.kts',
      path: 'app/build.gradle.kts',
      code: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.mahaagri.kranti"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.mahaagri.kranti"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
    buildFeatures { compose = true }
}

dependencies {
    implementation(libs.androidx.material3)
    implementation(libs.room.runtime)
    ksp(libs.room.compiler)
}`
    }
  };

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const menuCategories = [
    {
      headingMr: 'अवजारे, शेतकरी यशकथा व तंत्रज्ञान',
      headingEn: 'Equipment, Progressive Farmers & Tech',
      items: [
        {
          id: 'equipment' as TabType,
          titleMr: 'कृषी अवजारे भाडे व खरेदी-विक्री',
          titleEn: 'Farm Equipment Rent & Sale',
          subtitleMr: 'ट्रॅक्टर, ड्रोन फवारणी, हार्वेस्टर व रोटावेटर',
          subtitleEn: 'Tractor, spraying drone, combine harvester & rotavator',
          icon: Tractor,
          color: 'text-amber-700',
          bg: 'bg-amber-50'
        },
        {
          id: 'progressive_farmers' as TabType,
          titleMr: 'प्रगतशील शेतकरी व पीक यशकथा',
          titleEn: 'Progressive Farmers & Top Crops',
          subtitleMr: 'विक्रमी उत्पादन, शेतीची सूत्रे व थेट शेतातून खरेदी',
          subtitleEn: 'Record yields, best practices & direct farm produce',
          icon: Award,
          color: 'text-emerald-800',
          bg: 'bg-emerald-50'
        },
        {
          id: 'sustainable' as TabType,
          titleMr: 'शाश्वत विकास व हरित शेती',
          titleEn: 'Sustainable Agri & Eco-Farming',
          subtitleMr: 'सौर कृषी पंप, ठिबक जलसंधारण व सेंद्रिय जीवामृत',
          subtitleEn: 'PM-KUSUM solar, 60% drip saving & organic bio-control',
          icon: Leaf,
          color: 'text-teal-700',
          bg: 'bg-teal-50'
        },
        {
          id: 'mati_pik' as TabType,
          titleMr: 'माती व पीक सल्लागार',
          titleEn: 'Soil & Crop Advisory',
          subtitleMr: 'खत व्यवस्थापन, NPK प्रमाण व पीक चक्र',
          subtitleEn: 'NPK management, organic carbon & crop cycles',
          icon: Sprout,
          color: 'text-emerald-700',
          bg: 'bg-emerald-50'
        },
        {
          id: 'connect' as TabType,
          titleMr: 'महाराष्ट्र शेतकरी कनेक्ट',
          titleEn: 'Maharashtra Farmer Connect',
          subtitleMr: 'पश्चिम महाराष्ट्र, विदर्भ व मराठवाडा शेतकरी गट',
          subtitleEn: 'Regional farmer groups & community networks',
          icon: Users,
          color: 'text-blue-700',
          bg: 'bg-blue-50'
        }
      ]
    },
    {
      headingMr: 'उद्योग, ऊस व निर्यात',
      headingEn: 'Industry, Sugarcane & Global Export',
      items: [
        {
          id: 'us_belt' as TabType,
          titleMr: 'ऊस पट्टा व साखर कारखाने',
          titleEn: 'Sugarcane Belt & Mills',
          subtitleMr: 'FRP दर, 86032 वाण व कारखाने पेमेंट',
          subtitleEn: 'FRP rates, high-recovery varieties & mill payments',
          icon: Factory,
          color: 'text-amber-700',
          bg: 'bg-amber-50'
        },
        {
          id: 'jod_dhanda' as TabType,
          titleMr: 'शेतकरी जोडधंदा व उद्योग',
          titleEn: 'Agri-Business & Allied Units',
          subtitleMr: 'शेळीपालन, गांडूळ खत, रेशीम व प्रक्रिया उद्योग',
          subtitleEn: 'Goat farming, vermicompost, sericulture & food processing',
          icon: Coins,
          color: 'text-orange-700',
          bg: 'bg-orange-50'
        },
        {
          id: 'export' as TabType,
          titleMr: 'थेट निर्यात (दुबई व इराण)',
          titleEn: 'Direct Export (Dubai & Global)',
          subtitleMr: 'केळी, डाळिंब व द्राक्षे थेट जागतिक निर्यात',
          subtitleEn: 'Banana, pomegranate & table grapes global shipments',
          icon: PlaneTakeoff,
          color: 'text-indigo-700',
          bg: 'bg-indigo-50'
        }
      ]
    },
    {
      headingMr: 'योजना, सल्ला व शिक्षण',
      headingEn: 'Govt Schemes, Helpline & School',
      items: [
        {
          id: 'yojana' as TabType,
          titleMr: 'शासकीय योजना व सबसिडी',
          titleEn: 'Govt Schemes & Subsidies',
          subtitleMr: 'नमो शेतकरी, पिक विमा व महाडीबीटी',
          subtitleEn: 'MahaDBT, crop insurance & equipment subsidies',
          icon: Landmark,
          color: 'text-purple-700',
          bg: 'bg-purple-50'
        },
        {
          id: 'doctor' as TabType,
          titleMr: 'कृषी तज्ज्ञ डॉक्टर्स हेल्पलाईन',
          titleEn: 'Agri Expert Doctors Helpline',
          subtitleMr: 'डॉक्टरांशी थेट फोन कॉल व व्हॉट्सअ‍ॅप सल्ला',
          subtitleEn: 'Direct phone & video consultation with certified agronomists',
          icon: PhoneCall,
          color: 'text-red-700',
          bg: 'bg-red-50'
        },
        {
          id: 'shala' as TabType,
          titleMr: 'कृषी शाळा व व्हिडिओ वर्ग',
          titleEn: 'Digital Agri Academy',
          subtitleMr: 'तज्ज्ञ मार्गदर्शनाचे मोफत व्हिडिओ व नोट्स',
          subtitleEn: 'Expert video masterclasses & practical guides',
          icon: GraduationCap,
          color: 'text-emerald-800',
          bg: 'bg-emerald-50'
        }
      ]
    }
  ];

  return (
    <div className="space-y-4 pb-20">
      {/* Menu Header */}
      <div className="bg-gradient-to-r from-[#144818] to-emerald-900 text-white p-4 rounded-3xl shadow-sm border border-emerald-700">
        <h2 className="text-base font-black text-white leading-tight">
          {lang === 'mr' ? 'सर्व कृषी सेवा व साधने (Menu ≡)' : 'All Agri Services & Portals (Menu ≡)'}
        </h2>
        <p className="text-xs text-emerald-100/90 mt-1">
          {lang === 'mr' 
            ? 'महाराष्ट्र शासनाच्या योजना, तज्ज्ञ सल्ला, शाश्वत शेती व बाजारपेठा'
            : 'Access Maharashtra schemes, sustainability hub, exports & expert helpline'}
        </p>
      </div>

      {/* Android Kotlin & Jetpack Compose Native Architecture Spotlight */}
      <div 
        onClick={() => setShowAndroidModal(true)}
        className="bg-gradient-to-r from-emerald-950 via-slate-900 to-emerald-900 text-white p-3.5 rounded-3xl shadow-md border-2 border-emerald-400/70 relative overflow-hidden cursor-pointer hover:border-amber-400 transition-all group"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-emerald-500 text-slate-950 flex items-center justify-center font-black shadow-md">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="bg-amber-400 text-slate-950 text-[9px] font-black px-2 py-0.2 rounded-full uppercase">
                  Native Android
                </span>
                <span className="text-[9px] text-emerald-300 font-bold">Kotlin & Jetpack Compose</span>
              </div>
              <h3 className="text-xs font-black text-white mt-0.5">
                {lang === 'mr' ? 'अँड्रॉइड नेटिव्ह ॲप आर्किटेक्चर व कोड' : 'Native Android Code & Architecture'}
              </h3>
            </div>
          </div>
          <div className="flex items-center gap-1 text-xs font-bold text-amber-300 group-hover:translate-x-1 transition-transform">
            <span>{lang === 'mr' ? 'कोड पहा' : 'View Code'}</span>
            <Code2 className="w-4 h-4" />
          </div>
        </div>
        <p className="text-[10px] text-slate-300 mt-2 leading-relaxed">
          {lang === 'mr'
            ? 'Android Studio ready संपूर्ण Kotlin, Jetpack Compose, Room Database व Material 3 फाईल्स.'
            : 'Android Studio ready Kotlin, Jetpack Compose, Room DB & Material 3 implementation.'}
        </p>
      </div>

      {/* Categorized Menu Items */}
      {menuCategories.map((cat, idx) => (
        <div key={idx} className="space-y-2">
          <h3 className="text-xs font-black text-slate-700 px-1 uppercase tracking-wider">
            {lang === 'mr' ? cat.headingMr : cat.headingEn}
          </h3>
          <div className="bg-white rounded-3xl shadow-sm border border-slate-200/80 divide-y divide-slate-100 overflow-hidden">
            {cat.items.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className="w-full p-3.5 flex items-center justify-between hover:bg-emerald-50/40 active:bg-emerald-50 transition-all text-left group"
                >
                  <div className="flex items-center gap-3">
                    <div className={`p-2.5 rounded-2xl ${item.bg} ${item.color} shrink-0 group-hover:scale-105 transition-transform`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-black text-xs text-slate-900 leading-tight">
                        {lang === 'mr' ? item.titleMr : item.titleEn}
                      </h4>
                      <p className="text-[11px] text-slate-500 mt-0.5 leading-snug">
                        {lang === 'mr' ? item.subtitleMr : item.subtitleEn}
                      </p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 shrink-0 ml-2 group-hover:translate-x-1 group-hover:text-emerald-700 transition-all" />
                </button>
              );
            })}
          </div>
        </div>
      ))}

      {/* App Info Box */}
      <div className="p-3 bg-gradient-to-r from-emerald-50 to-amber-50 rounded-2xl text-center text-xs text-slate-600 border border-emerald-200/80">
        <p className="font-black text-[#1B5E20]">
          🌱 {lang === 'mr' ? 'हरित कृषी क्रांती • आवृत्ती ३.० (Android & Web)' : 'Harit Krushi Kranti • v3.0 (Android & Web)'}
        </p>
        <p className="text-[10px] text-slate-500 mt-0.5">
          {lang === 'mr' ? 'महाराष्ट्र राज्य शेतकरी सशक्तीकरण व शाश्वत कृषी व्यासपीठ' : 'Maharashtra State Farmer Empowerment & Sustainable Agriculture Platform'}
        </p>
      </div>

      {/* Native Android Code Inspector Modal */}
      {showAndroidModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3">
          <div className="bg-slate-900 text-white rounded-3xl w-full max-w-md max-h-[85vh] flex flex-col border border-emerald-500/50 shadow-2xl overflow-hidden animate-fade-in">
            {/* Modal Header */}
            <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-amber-400" />
                <div>
                  <h3 className="font-black text-xs text-white">
                    Native Android Kotlin & Jetpack Compose
                  </h3>
                  <p className="text-[10px] text-emerald-400">100% Offline-First Architecture</p>
                </div>
              </div>
              <button 
                onClick={() => setShowAndroidModal(false)}
                className="p-1 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* File Selector Tabs */}
            <div className="flex gap-1.5 p-2 bg-slate-950/60 overflow-x-auto no-scrollbar border-b border-slate-800 text-[11px]">
              {(Object.keys(androidFiles) as Array<keyof typeof androidFiles>).map((key) => (
                <button
                  key={key}
                  onClick={() => setSelectedFileKey(key)}
                  className={`px-2.5 py-1 rounded-xl font-bold whitespace-nowrap transition-all ${
                    selectedFileKey === key
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'bg-slate-800/80 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {androidFiles[key].name}
                </button>
              ))}
            </div>

            {/* Code Body */}
            <div className="flex-1 p-3 overflow-y-auto font-mono text-[10px] leading-relaxed bg-slate-950/90 text-emerald-300">
              <div className="flex items-center justify-between text-slate-500 mb-2 font-sans text-[10px]">
                <span className="truncate">{androidFiles[selectedFileKey].path}</span>
                <button
                  onClick={() => handleCopy(androidFiles[selectedFileKey].code, selectedFileKey)}
                  className="flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-white px-2 py-1 rounded-lg text-[9px] shrink-0"
                >
                  {copiedKey === selectedFileKey ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedKey === selectedFileKey ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
              <pre className="whitespace-pre-wrap overflow-x-auto text-slate-200">
                {androidFiles[selectedFileKey].code}
              </pre>
            </div>

            {/* Modal Footer */}
            <div className="p-3 bg-slate-950 border-t border-slate-800 text-[10px] text-slate-400 flex items-center justify-between">
              <span>Android SDK 35 • Material3 • Room DB</span>
              <button
                onClick={() => setShowAndroidModal(false)}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3 py-1.5 rounded-xl"
              >
                बंद करा (Close)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
