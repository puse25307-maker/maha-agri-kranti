import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Language, TabType } from './types';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { Footer } from './components/Footer';
import { PWASplashScreen } from './components/PWASplashScreen';

// Tabs
import { TabHome } from './components/TabHome';
import { Tab1RogDoctor } from './components/Tab1RogDoctor';
import { TabSustainable } from './components/TabSustainable';
import { TabEquipmentHub } from './components/TabEquipmentHub';
import { TabProgressiveFarmers } from './components/TabProgressiveFarmers';
import { Tab2MatiPik } from './components/Tab2MatiPik';
import { Tab3MaharashtraConnect } from './components/Tab3MaharashtraConnect';
import { Tab4MahaBazaar } from './components/Tab4MahaBazaar';
import { Tab5UsBelt } from './components/Tab5UsBelt';
import { Tab6SarkariYojana } from './components/Tab6SarkariYojana';
import { Tab7JodDhanda } from './components/Tab7JodDhanda';
import { Tab8ExportDubaiIran } from './components/Tab8ExportDubaiIran';
import { Tab9DoctorHelpline } from './components/Tab9DoctorHelpline';
import { Tab10Shala } from './components/Tab10Shala';
import { TabMenu } from './components/TabMenu';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [lang, setLang] = useState<Language>('mr');

  const handleToggleLang = () => {
    setLang((prev) => (prev === 'mr' ? 'en' : 'mr'));
  };

  const renderActiveTab = () => {
    switch (activeTab) {
      case 'home':
        return <TabHome key="tab_home" lang={lang} onNavigate={setActiveTab} />;
      case 'rog_doctor':
        return <Tab1RogDoctor key="tab_rog_doctor" />;
      case 'sustainable':
        return <TabSustainable key="tab_sustainable" lang={lang} onNavigate={setActiveTab} />;
      case 'equipment':
        return <TabEquipmentHub key="tab_equipment" lang={lang} />;
      case 'progressive_farmers':
        return <TabProgressiveFarmers key="tab_progressive_farmers" lang={lang} />;
      case 'maha_bazaar':
        return <Tab4MahaBazaar key="tab_maha_bazaar" />;
      case 'yojana':
        return <Tab6SarkariYojana key="tab_yojana" />;
      case 'menu':
        return <TabMenu key="tab_menu" lang={lang} onNavigate={setActiveTab} />;
      case 'mati_pik':
        return <Tab2MatiPik key="tab_mati_pik" />;
      case 'connect':
        return <Tab3MaharashtraConnect key="tab_connect" />;
      case 'us_belt':
        return <Tab5UsBelt key="tab_us_belt" />;
      case 'jod_dhanda':
        return <Tab7JodDhanda key="tab_jod_dhanda" />;
      case 'export':
        return <Tab8ExportDubaiIran key="tab_export" />;
      case 'doctor':
        return <Tab9DoctorHelpline key="tab_doctor" />;
      case 'shala':
        return <Tab10Shala key="tab_shala" />;
      default:
        return <TabHome key="tab_default" lang={lang} onNavigate={setActiveTab} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex justify-center items-start selection:bg-emerald-700 selection:text-white">
      {/* PWA Splash Screen on Launch */}
      <PWASplashScreen />

      {/* Mobile App Container (Max-W 430px Mobile Look) */}
      <div className="w-full max-w-[430px] min-h-screen bg-[#FBFDFB] flex flex-col shadow-xl relative border-x border-slate-200">
        {/* App Header with Bilingual toggle */}
        <Header lang={lang} onToggleLang={handleToggleLang} />

        {/* Dynamic Tab Content with Animation */}
        <main className="flex-1 p-3.5">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.16, ease: 'easeOut' }}
            >
              {renderActiveTab()}
            </motion.div>
          </AnimatePresence>

          {/* Footer Section */}
          <Footer lang={lang} />
        </main>

        {/* 5-Tab Clean Bottom Navigation */}
        <BottomNav activeTab={activeTab} lang={lang} onSelectTab={setActiveTab} />
      </div>
    </div>
  );
}


