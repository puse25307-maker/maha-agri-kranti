const fs = require('fs');

let content = fs.readFileSync('src/data/agriData.ts', 'utf8');

const newJodDhandaList = `export const JOD_DHANDA_LIST: JodDhandaItem[] = [
  {
    id: 'dairy',
    titleMr: '१. दुग्ध व्यवसाय (Dudh Dairy)',
    titleEn: 'Dairy Farming',
    iconEmoji: '🐄',
    monthlyIncome: 'नफा: ₹३०,००० / महिना',
    setupCost: 'खर्च: १ गाय ₹८०,००० (८०% अनुदान)',
    loanScheme: 'नाबार्ड डेअरी योजना (NABARD)',
    subsidyPercent: '८०% सबसिडी',
    stepsMr: [
      'उत्पादन: १५ लिटर/दिवस x ३५ रुपये = ₹१५,७५०/महिना (१ गाईचे).',
      '२० ते २५ लिटर देणाऱ्या HF किंवा गीर गाईंची निवड करा.',
      'हिरवा चारा, सायलेज आणि योग्य गोठ्यामुळे दुधाच्या फॅटमध्ये वाढ होते.',
      'नाबार्ड योजनेअंतर्गत ८०% सबसिडी मिळवून गोठा बांधा.'
    ],
    marketTips: 'थेट सोसायट्यांमध्ये किंवा डेअरीमध्ये A2 दूध विका.'
  },
  {
    id: 'poultry',
    titleMr: '२. कुक्कुटपालन (Kombadi Palan)',
    titleEn: 'Poultry Farming',
    iconEmoji: '🐓',
    monthlyIncome: 'नफा: ₹२५,००० / महिना',
    setupCost: 'खर्च: १०० कोंबड्या ₹२५,०००',
    loanScheme: 'मुद्रा कर्ज (Mudra Yojana)',
    subsidyPercent: 'विनातारण कर्ज',
    stepsMr: [
      'उत्पादन: ८० अंडी/दिवस x ८ रुपये = ₹१९,२००/महिना.',
      'गावरान, कावेरी किंवा ग्रामप्रिया जातीच्या कोंबड्या पाळा.',
      'मांस आणि अंडी या दोन्ही बाजूंनी उत्पन्न मिळते.',
      'मुद्रा योजनेअंतर्गत ५० हजारांपर्यंत विनातारण शिशु कर्ज मिळवा.'
    ],
    marketTips: 'गावातील आठवडे बाजार आणि नॉनव्हेज हॉटेल्सना थेट अंडी व चिकन सप्लाय.'
  },
  {
    id: 'goat_farming',
    titleMr: '३. शेळीपालन (Sheli Palan)',
    titleEn: 'Goat Farming',
    iconEmoji: '🐐',
    monthlyIncome: 'नफा: ₹३५,००० / महिना',
    setupCost: 'खर्च: १० शेळ्या ₹६०,०००',
    loanScheme: 'नाबार्ड / अहिल्यादेवी महामंडळ',
    subsidyPercent: '५०% अनुदान',
    stepsMr: [
      'उत्पादन: २ करडू x ८,००० = ₹१६,००० + खत ₹५,००० (वर्षाकाठी मोठी कमाई).',
      'उस्मानाबादी, बोअर किंवा सिरोही शेळ्यांची निवड.',
      'बंदिस्त शेळीपालनामुळे चारा कमी लागतो आणि वजन लवकर वाढते.',
      'अहिल्यादेवी महामंडळामार्फत ५०% अनुदानासाठी अर्ज करा.'
    ],
    marketTips: 'बोकडांची ईदला व सणासुदीला विक्री करून दुप्पट नफा कमवा.'
  },
  {
    id: 'beekeeping',
    titleMr: '४. मधमाशी पालन (Madhmashi Palan)',
    titleEn: 'Beekeeping',
    iconEmoji: '🍯',
    monthlyIncome: 'नफा: ₹२५,००० / महिना',
    setupCost: 'खर्च: १० पेट्या ₹४०,०००',
    loanScheme: 'KVIC हनी मिशन योजना',
    subsidyPercent: '८०% अनुदान',
    stepsMr: [
      'उत्पादन: ३० किलो मध x ८०० रुपये = ₹२४,०००/हंगाम.',
      'मधमाश्यांमुळे पिकांचे परागीभवन होऊन शेतातील उत्पादनही ४०% वाढते.',
      'पेट्या सूर्यफूल, मोहरी किंवा फळबागेत ठेवा.',
      'KVIC मधून ८०% अनुदानावर पेट्या मिळवा.'
    ],
    marketTips: 'सेंद्रिय मध, बी-वॅक्स आणि रॉयल जेली या उत्पादनांना बाजारात प्रचंड मागणी.'
  },
  {
    id: 'mushroom',
    titleMr: '५. अळंबी शेती (Mushroom Farming)',
    titleEn: 'Mushroom Farming',
    iconEmoji: '🍄',
    monthlyIncome: 'नफा: ₹२०,००० / महिना',
    setupCost: 'खर्च: १०x१० खोली ₹३०,०००',
    loanScheme: 'राष्ट्रीय फलोत्पादन अभियान (NHM)',
    subsidyPercent: '५०% अनुदान',
    stepsMr: [
      'उत्पादन: ५० किलो/महिना x २०० रुपये = ₹१०,०००.',
      'गव्हाच्या किंवा भाताच्या काडाचा (भुसा) उपयोग करून ऑयस्टर अळंबी पिकवा.',
      'फक्त २२-२५ दिवसांत पीक तयार होते व कमी जागेत भरपूर नफा मिळतो.',
      'NHM मधून ५०% अनुदानाचा लाभ घ्या.'
    ],
    marketTips: 'हॉटेल्स, चायनीज सेंटर्स आणि आयुर्वेदिक औषध कंपन्यांना सुके व ओले मशरूम विका.'
  },
  {
    id: 'biofloc_fish',
    titleMr: '६. मत्स्यपालन (Biofloc Fish Farming)',
    titleEn: 'Biofloc Fish Farming',
    iconEmoji: '🐟',
    monthlyIncome: 'नफा: ₹४०,००० / महिना',
    setupCost: 'खर्च: १ टँक ₹५०,०००',
    loanScheme: 'PM मत्स्य संपदा योजना (PMMSY)',
    subsidyPercent: '४०% ते ६०% अनुदान',
    stepsMr: [
      'उत्पादन: ५०० किलो x १५० रुपये = ₹७५,००० (प्रति टँक).',
      'बायोफ्लॉक तंत्रज्ञानाने कमी पाण्यात व कमी जागेत जास्त मासे मिळतात.',
      'रोहू, कटला किंवा तिलापिया माशांची पैदास करा.',
      'पंतप्रधान मत्स्य संपदा योजनेतून ६०% पर्यंत अनुदान मिळवा.'
    ],
    marketTips: 'शहरातील मासळी बाजार आणि मोठ्या रेस्टॉरंट्सशी करार करा.'
  },
  {
    id: 'vermicompost',
    titleMr: '७. गांडूळ खत प्रकल्प (Vermicompost)',
    titleEn: 'Vermicomposting',
    iconEmoji: '🪱',
    monthlyIncome: 'नफा: ₹१५,००० / महिना',
    setupCost: 'खर्च: ४ बेड ₹२०,०००',
    loanScheme: 'कृषी विभाग सेंद्रिय शेती योजना',
    subsidyPercent: '१००% मोफत किट',
    stepsMr: [
      'उत्पादन: २ टन खत x १० रुपये किलो = ₹२०,०००.',
      'शेतातील काडीकचरा आणि शेणापासून उच्च दर्जाचे सेंद्रिय खत.',
      'खतासोबतच गांडूळ कल्चर (बीज) विकूनही पैसे मिळवा.',
      'कृषी विभागाकडून गांडूळ बेड व बीज अनुदानावर मिळवा.'
    ],
    marketTips: 'नर्सरी, गार्डन्स आणि सेंद्रिय शेती करणाऱ्या शेतकऱ्यांना थेट विक्री करा.'
  },
  {
    id: 'sericulture',
    titleMr: '८. रेशीम उद्योग (Reshim Udyog)',
    titleEn: 'Sericulture',
    iconEmoji: '🐛',
    monthlyIncome: 'नफा: ₹४०,००० / महिना',
    setupCost: 'खर्च: १ एकर तुती ₹५०,०००',
    loanScheme: 'मनरेगा रेशीम योजना (MNREGA)',
    subsidyPercent: '₹३ लाख पर्यंत अनुदान',
    stepsMr: [
      'उत्पादन: १०० किलो कोष x ४०० रुपये = ₹४०,००० प्रति बॅच.',
      '१ एकर तुती लागवडीतून वर्षाला ४ ते ५ बॅचेस काढता येतात.',
      'रेशीम कीटक पालनासाठी शासनाकडून मोफत प्रशिक्षण आणि मार्गदर्शन.',
      'मनरेगा योजनेतून शेड व मजुरीसाठी ३ लाखांपर्यंत अनुदान.'
    ],
    marketTips: 'रामणगर (कर्नाटक) किंवा जालना येथील बाजारपेठेत कोषाला सर्वाधिक भाव मिळतो.'
  }
];`;

content = content.replace(
  /export const JOD_DHANDA_LIST: JodDhandaItem\[\] = \[[\s\S]*?\];\n\nexport const AGRI_VIDEO_LESSONS/,
  newJodDhandaList + '\n\nexport const AGRI_VIDEO_LESSONS'
);

fs.writeFileSync('src/data/agriData.ts', content);
