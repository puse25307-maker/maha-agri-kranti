# Maha Agri Kranti

Prepared Android build for the Vite/React project.

The GitHub Actions workflow builds the web app with Vite, copies the `dist` output into the Android app assets, and produces a debug APK.
