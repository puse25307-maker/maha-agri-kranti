package com.mahaagri.kranti.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mahaagri.kranti.data.datasource.AgriDatabase
import com.mahaagri.kranti.data.models.DiseaseInfo
import com.mahaagri.kranti.data.models.Language
import com.mahaagri.kranti.ui.theme.*

@Composable
fun RogDoctorScreen(
    lang: Language,
    selectedDisease: DiseaseInfo,
    isScanning: Boolean,
    onSelectDisease: (DiseaseInfo) -> Unit,
    onTriggerScan: () -> Unit,
    onSpeakDisease: (String) -> Unit,
    onCallExpert: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
    ) {
        // AI Leaf Scanner Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Green900)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(Green900, Green800, Color(0xFF0F3D14))
                            )
                        )
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Amber500)
                            .padding(horizontal = 10.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = if (lang == Language.MARATHI) "⚡ ९५% अचूक एआय रोग निदान" else "⚡ 95% Accurate AI Detection",
                            color = Slate900,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = if (lang == Language.MARATHI) "पानाचा फोटो काढा किंवा अपलोड करा" else "Take Leaf Photo or Upload",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Scanner Viewport Box
                    Box(
                        modifier = Modifier
                            .size(160.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color.White.copy(alpha = 0.1f))
                            .border(2.dp, Amber500, RoundedCornerShape(20.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isScanning) {
                            CircularProgressIndicator(
                                color = Amber500,
                                modifier = Modifier.size(48.dp)
                            )
                        } else {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = selectedDisease.imagePlaceholder, fontSize = 48.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = selectedDisease.cropMr,
                                    color = Green100,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = onTriggerScan,
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Amber500),
                        modifier = Modifier.fillMaxWidth(0.85f)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = null, tint = Slate900)
                            Text(
                                text = if (lang == Language.MARATHI) "कॅमेऱ्याने स्कॅन करा (Scan Now)" else "Scan Leaf With Camera",
                                color = Slate900,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }
        }

        // Crop Selection Horizontal Bar
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = if (lang == Language.MARATHI) "प्रमुख पिकांचे रोग निवडा (Quick Test):" else "Select Crop Disease to Inspect:",
                    color = Slate900,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(AgriDatabase.diseases) { disease ->
                        val isSelected = disease.id == selectedDisease.id
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (isSelected) Green800 else Color.White)
                                .border(1.dp, if (isSelected) Green800 else Slate200, RoundedCornerShape(14.dp))
                                .clickable { onSelectDisease(disease) }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = disease.imagePlaceholder, fontSize = 16.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (lang == Language.MARATHI) disease.cropMr else disease.cropEn,
                                    color = if (isSelected) Color.White else Slate800,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Black else FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        }

        // Disease Diagnosis Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Slate200, Slate200)))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (lang == Language.MARATHI) selectedDisease.cropMr else selectedDisease.cropEn,
                                color = Green800,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = if (lang == Language.MARATHI) selectedDisease.nameMr else selectedDisease.nameEn,
                                color = Slate900,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        IconButton(
                            onClick = {
                                onSpeakDisease(
                                    if (lang == Language.MARATHI)
                                        "${selectedDisease.cropMr} मध्ये ${selectedDisease.nameMr} रोग आढळला आहे. उपाय: ${selectedDisease.upcharMr}"
                                    else
                                        "${selectedDisease.cropEn}: ${selectedDisease.nameEn}. Treatment: ${selectedDisease.upcharMr}"
                                )
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Green100)
                        ) {
                            Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Green800, modifier = Modifier.size(20.dp))
                        }
                    }

                    // Severity Progress Bar
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "रोगाची तीव्रता (Severity)", fontSize = 11.sp, color = Slate600, fontWeight = FontWeight.Bold)
                            Text(text = "${selectedDisease.severityPercent}%", fontSize = 11.sp, color = Red600, fontWeight = FontWeight.Black)
                        }

                        LinearProgressIndicator(
                            progress = { selectedDisease.severityPercent / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = if (selectedDisease.severityPercent > 50) Red600 else Amber500,
                            trackColor = Slate200
                        )

                        Text(
                            text = selectedDisease.severityLabel,
                            fontSize = 10.sp,
                            color = Slate500
                        )
                    }

                    HorizontalDivider(color = Slate100)

                    // Treatment Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Green50)
                            .padding(12.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.MedicalServices, contentDescription = null, tint = Green800, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (lang == Language.MARATHI) "तात्काळ फवारणी उपाय:" else "Recommended Spraying:",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Green900
                                )
                            }
                            Text(
                                text = selectedDisease.upcharMr,
                                fontSize = 11.sp,
                                color = Slate800,
                                lineHeight = 16.sp
                            )
                            Text(
                                text = "अंदाजे खर्च: ${selectedDisease.kharchMr}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Green800
                            )
                        }
                    }

                    // Medicine Dosages
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = if (lang == Language.MARATHI) "प्रमाणित औषधे व डोस (Dosage):" else "Certified Medicines & Dosage:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            color = Slate900
                        )

                        selectedDisease.medicines.forEach { med ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Slate50)
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = med.brand, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Slate900)
                                    Text(text = "कंपनी: ${med.company} | ${med.timing}", fontSize = 9.sp, color = Slate500)
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Amber100)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(text = med.dose, fontSize = 10.sp, fontWeight = FontWeight.Black, color = Slate900)
                                }
                            }
                        }
                    }

                    // Call Expert Button
                    Button(
                        onClick = onCallExpert,
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Green800),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Phone, contentDescription = null, tint = Amber500, modifier = Modifier.size(16.dp))
                            Text(
                                text = if (lang == Language.MARATHI) "कृषी तज्ज्ञांशी मोफत बोला (Free Call)" else "Consult Agronomist Free",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
