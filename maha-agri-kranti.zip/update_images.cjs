const fs = require('fs');
let content = fs.readFileSync('src/data/agriData.ts', 'utf8');

// Hero farmer (Dattatraya)
content = content.replace(
  /farmerName: 'दत्तात्रय ज्ञानदेव कदम',([\s\S]*?)avatarEmoji: '🌾',/,
  `farmerName: 'दत्तात्रय ज्ञानदेव कदम',$1avatarEmoji: '🌾',
    image: 'https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=500',`
);

// Grapes Farmer (Vilas)
content = content.replace(
  /farmerName: 'विलास विठ्ठल शिंदे',([\s\S]*?)avatarEmoji: '🍇',/,
  `farmerName: 'विलास विठ्ठल शिंदे',$1avatarEmoji: '🍇',
    image: 'https://images.unsplash.com/photo-1596363505729-4190a9506133?w=500',`
);

// Banana Farmer (Rohidas)
content = content.replace(
  /farmerName: 'रोहिदास आनंदा पाटील',([\s\S]*?)avatarEmoji: '🍌',/,
  `farmerName: 'रोहिदास आनंदा पाटील',$1avatarEmoji: '🍌',
    image: 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=500',`
);

fs.writeFileSync('src/data/agriData.ts', content);
