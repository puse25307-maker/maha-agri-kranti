import React, { useState } from 'react';
import { 
  Leaf, 
  Sun, 
  Droplets, 
  Sparkles, 
  Globe2, 
  ShieldCheck, 
  Trees, 
  Recycle, 
  Calculator, 
  CheckCircle2, 
  Award, 
  TrendingUp, 
  PhoneCall, 
  Share2, 
  Volume2,
  ChevronRight,
  Info,
  Flame
} from 'lucide-react';
import { Language, TabType } from '../types';
import { speakText } from '../utils/speech';

interface TabSustainableProps {
  lang: Language;
  onNavigate: (tab: TabType) => void;
}

export const TabSustainable: React.FC<TabSustainableProps> = ({ lang, onNavigate }) => {
  const [selectedSolarAcres, setSelectedSolarAcres] = useState<number>(3);
  const [selectedPumpHp, setSelectedPumpHp] = useState<number>(5);
  const [selectedDripAcres, setSelectedDripAcres] = useState<number>(4);
  const [organicPillarTab, setOrganicPillarTab] = useState<'jivamrut' | 'vermicompost' | 'dashparni' | 'carbon'>('jivamrut');
  const [callAlert, setCallAlert] = useState<string | null>(null);

  // Green Farmer Quiz / Checklist
  const [greenScoreChecks, setGreenScoreChecks] = useState<Record<string, boolean>>({
    drip: true,
    solar: true,
    organicManure: false,
    cropRotation: true,
    bioPesticide: false,
    bundTrees: false
  });

  const toggleCheck = (key: string) => {
    setGreenScoreChecks(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const completedChecksCount = Object.values(greenScoreChecks).filter(Boolean).length;
  const greenScorePercent = Math.round((completedChecksCount / 6) * 100);

  // Solar calculation: 5HP saves ~₹48,000/yr diesel/power, 90% subsidy
  const solarCostTotal = selectedPumpHp * 55000;
  const solarGovtSubsidy = Math.round(solarCostTotal * 0.90);
  const solarFarmerShare = solarCostTotal - solarGovtSubsidy;
  const solarAnnualSaving = selectedPumpHp * 9600;

  // Water calculation: Drip saves ~60% water (approx 2,40,000 liters/acre/season)
  const waterSavedLiters = selectedDripAcres * 240000;
  const yieldBonusPercent = 28;

  const handleListenOverview = () => {
    const textMr = `शाश्वत शेती आणि हरित विकासामध्ये आपले स्वागत. ठिबक सिंचनाने ६० टक्के पाण्याची बचत होते, तर पीएम कुसुम सौर पंपावर ९० टक्के शासकीय अनुदान मिळते. सेंद्रिय जीवामृत आणि कामगंध सापळ्यांमुळे विषमुक्त शेती होऊन एकरी खर्चात २५ हजार रुपयांची बचत होते.`;
    const textEn = `Welcome to Sustainable Agriculture and Green Development. Micro-irrigation saves up to 60 percent water, while PM-KUSUM solar pumps provide 90 percent government subsidy. Organic Jivamrut and bio-pest controls enable residue-free farming saving up to 25 thousand rupees per acre.`;
    
    speakText(lang === 'mr' ? textMr : textEn, lang);
  };

  const handleApplyKusum = () => {
    setCallAlert(
      lang === 'mr' 
        ? '☀️ महाऊर्जा (MahaUrja) PM-KUSUM सौर पंप योजनेसाठी नोंदणी लिंक उघडली जात आहे...'
        : '☀️ Opening MahaUrja PM-KUSUM Solar Pump application link...'
    );
    speakText(
      lang === 'mr' ? 'पीएम कुसुम सौर पंप अर्जासाठी अधिकृत पोर्टल उघडले जात आहे.' : 'Opening PM Kusum solar pump official portal.',
      lang
    );
    setTimeout(() => setCallAlert(null), 4000);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Toast Alert */}
      {callAlert && (
        <div className="bg-emerald-900 text-white text-xs p-3 rounded-2xl shadow-lg flex items-center gap-2 border border-emerald-500 animate-fade-in">
          <Sparkles className="w-4 h-4 text-amber-300 animate-spin shrink-0" />
          <span className="font-bold">{callAlert}</span>
        </div>
      )}

      {/* Sustainable Hero Banner (Vibrant Green & Gold SDG Style) */}
      <div className="bg-gradient-to-br from-[#104716] via-emerald-800 to-teal-900 text-white p-4 rounded-3xl shadow-md relative overflow-hidden border border-emerald-500/30">
        <div className="absolute top-0 right-0 -mr-6 -mt-6 w-32 h-32 bg-amber-400/20 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-6 -mb-6 w-32 h-32 bg-teal-400/20 rounded-full blur-2xl pointer-events-none" />
        
        <div className="flex justify-between items-start relative z-10">
          <div>
            <div className="flex items-center gap-1.5 mb-1.5">
              <span className="bg-amber-400 text-slate-950 text-[10px] font-black px-2.5 py-0.5 rounded-full shadow-sm">
                🌿 {lang === 'mr' ? 'शाश्वत विकास' : 'SUSTAINABLE AGRI'}
              </span>
              <span className="bg-white/20 text-emerald-100 text-[10px] font-bold px-2 py-0.5 rounded-full backdrop-blur-sm">
                UN SDG 2, 6, 7, 13
              </span>
            </div>
            <h2 className="text-lg font-black text-white leading-tight">
              {lang === 'mr' ? 'हरित शेती • समृद्ध शेतकरी' : 'Green Farming • Prosperous Future'}
            </h2>
            <p className="text-xs text-emerald-100/90 mt-1 max-w-[280px]">
              {lang === 'mr' 
                ? 'सौर ऊर्जा, ठिबक जलसंधारण, सेंद्रिय जीवामृत व कार्बन क्रेडिट्स द्वारे खर्चात ५०% कपात.' 
                : 'Solar energy, water conservation, zero-chemical organic recipes & carbon credits for max profitability.'}
            </p>
          </div>
          <button
            onClick={handleListenOverview}
            className="p-2.5 rounded-2xl bg-white/15 hover:bg-white/25 backdrop-blur-sm border border-white/20 text-amber-300 shadow-sm transition-all"
            title={lang === 'mr' ? 'माहिती ऐका' : 'Listen speech'}
          >
            <Volume2 className="w-5 h-5" />
          </button>
        </div>

        {/* 3 Impact Highlights */}
        <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-white/15 text-center">
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-2">
            <span className="text-[10px] text-emerald-200 block">
              {lang === 'mr' ? 'पाणी बचत' : 'Water Saved'}
            </span>
            <span className="text-xs font-black text-amber-300">६०% Drip</span>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-2">
            <span className="text-[10px] text-emerald-200 block">
              {lang === 'mr' ? 'सौर पंप अनुदान' : 'Solar Subsidy'}
            </span>
            <span className="text-xs font-black text-amber-300">९०% KUSUM</span>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-2">
            <span className="text-[10px] text-emerald-200 block">
              {lang === 'mr' ? 'खर्चात बचत' : 'Cost Cut'}
            </span>
            <span className="text-xs font-black text-amber-300">₹२५,०००/एकर</span>
          </div>
        </div>
      </div>

      {/* Interactive Tool 1: PM-KUSUM Solar Pump Subsidy & Energy Savings Calculator */}
      <div className="bg-white p-4 rounded-3xl shadow-sm border border-slate-200/80 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold">
              <Sun className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-xs text-slate-900 leading-tight">
                {lang === 'mr' ? '१. सौर कृषी पंप गणक (PM-KUSUM)' : '1. Solar Agri-Pump & Savings Calculator'}
              </h3>
              <p className="text-[11px] text-slate-500">
                {lang === 'mr' ? 'दिवसा मोफत वीज + ९०% शासकीय अनुदान' : 'Free daytime power + 90% Govt Subsidy'}
              </p>
            </div>
          </div>
          <span className="bg-emerald-100 text-emerald-900 text-[10px] font-black px-2 py-0.5 rounded-full">
            ९०% SUBSIDY
          </span>
        </div>

        {/* Pump HP Selector */}
        <div className="space-y-1.5">
          <label className="text-[11px] font-bold text-slate-700 block">
            {lang === 'mr' ? 'पंप क्षमता (HP) निवडा:' : 'Select Pump Capacity (HP):'}
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[3, 5, 7.5].map((hp) => (
              <button
                key={hp}
                onClick={() => setSelectedPumpHp(hp)}
                className={`py-2 px-3 rounded-xl text-xs font-black transition-all border ${
                  selectedPumpHp === hp
                    ? 'bg-amber-500 text-slate-950 border-amber-500 shadow-sm'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-amber-50'
                }`}
              >
                {hp} HP {lang === 'mr' ? 'सौर पंप' : 'Solar'}
              </button>
            ))}
          </div>
        </div>

        {/* Calculations Display */}
        <div className="bg-gradient-to-r from-amber-50 to-emerald-50 rounded-2xl p-3 border border-amber-200/80 grid grid-cols-3 gap-2 text-center text-xs">
          <div>
            <span className="text-[10px] text-slate-500 block">
              {lang === 'mr' ? 'एकूण किंमत' : 'Total Cost'}
            </span>
            <span className="font-bold text-slate-800">₹{(solarCostTotal).toLocaleString('en-IN')}</span>
          </div>
          <div className="border-x border-amber-200">
            <span className="text-[10px] text-emerald-800 font-bold block">
              {lang === 'mr' ? 'शासन अनुदान (९०%)' : 'Govt Subsidy (90%)'}
            </span>
            <span className="font-black text-emerald-900">₹{(solarGovtSubsidy).toLocaleString('en-IN')}</span>
          </div>
          <div>
            <span className="text-[10px] text-amber-800 font-bold block">
              {lang === 'mr' ? 'शेतकरी हिस्सा (१०%)' : 'Farmer Share (10%)'}
            </span>
            <span className="font-black text-slate-950">₹{(solarFarmerShare).toLocaleString('en-IN')}</span>
          </div>
        </div>

        <div className="flex items-center justify-between text-xs pt-1">
          <span className="text-emerald-800 font-bold flex items-center gap-1 text-[11px]">
            <TrendingUp className="w-3.5 h-3.5" />
            {lang === 'mr' ? `वार्षिक वीज/डिझेल बचत: ₹${solarAnnualSaving.toLocaleString('en-IN')}` : `Annual Diesel/Power Savings: ₹${solarAnnualSaving.toLocaleString('en-IN')}`}
          </span>
          <button
            onClick={handleApplyKusum}
            className="bg-[#1B5E20] hover:bg-emerald-900 text-white font-bold text-xs px-3 py-1.5 rounded-xl flex items-center gap-1 shadow-sm active:scale-95 transition-all"
          >
            <span>{lang === 'mr' ? 'अर्ज करा' : 'Apply Now'}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Interactive Tool 2: Water Conservation & Drip Irrigation Calculator */}
      <div className="bg-white p-4 rounded-3xl shadow-sm border border-slate-200/80 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-2xl bg-cyan-100 text-cyan-800 flex items-center justify-center font-bold">
              <Droplets className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-xs text-slate-900 leading-tight">
                {lang === 'mr' ? '२. ठिबक सिंचन व पाणी बचत गणक' : '2. Micro-Irrigation & Water Conservation'}
              </h3>
              <p className="text-[11px] text-slate-500">
                {lang === 'mr' ? '६०% पाण्याची बचत + ३०% उत्पादन वाढ' : '60% Water Saved + 30% Higher Yield'}
              </p>
            </div>
          </div>
          <span className="bg-cyan-100 text-cyan-900 text-[10px] font-black px-2 py-0.5 rounded-full">
            जल समृद्धी
          </span>
        </div>

        {/* Acre Slider */}
        <div className="space-y-1">
          <div className="flex justify-between text-xs font-bold text-slate-700">
            <span>{lang === 'mr' ? 'शेत क्षेत्र (Acres):' : 'Farm Area (Acres):'}</span>
            <span className="text-cyan-800 font-black">{selectedDripAcres} {lang === 'mr' ? 'एकर' : 'Acres'}</span>
          </div>
          <input
            type="range"
            min={1}
            max={15}
            value={selectedDripAcres}
            onChange={(e) => setSelectedDripAcres(Number(e.target.value))}
            className="w-full h-2 bg-cyan-100 rounded-lg appearance-none cursor-pointer accent-cyan-700"
          />
          <div className="flex justify-between text-[10px] text-slate-400 font-semibold">
            <span>१ एकर</span>
            <span>५ एकर</span>
            <span>१० एकर</span>
            <span>१५ एकर</span>
          </div>
        </div>

        {/* Water Impact Stat Box */}
        <div className="bg-cyan-50/70 border border-cyan-200 rounded-2xl p-3 flex items-center justify-between text-xs">
          <div>
            <span className="text-[10px] text-cyan-800 font-bold block">
              {lang === 'mr' ? 'हंगामातील पाणी बचत:' : 'Seasonal Water Saved:'}
            </span>
            <span className="text-base font-black text-cyan-950">
              {(waterSavedLiters / 1000).toLocaleString('en-IN')} {lang === 'mr' ? 'हजार लिटर' : 'k Liters'}
            </span>
          </div>
          <div className="text-right">
            <span className="text-[10px] text-slate-500 block">
              {lang === 'mr' ? 'उत्पादनातील वाढ' : 'Yield Increase'}
            </span>
            <span className="text-base font-black text-emerald-800">
              +{yieldBonusPercent}%
            </span>
          </div>
        </div>
      </div>

      {/* Sustainable Practices & Organic Formulations (Jivamrut, Dashparni, Vermicompost) */}
      <div className="bg-white p-4 rounded-3xl shadow-sm border border-slate-200/80 space-y-3">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
            <Leaf className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-black text-xs text-slate-900 leading-tight">
              {lang === 'mr' ? '३. सेंद्रिय व जैविक शेती कृती (Zero Chemical)' : '3. Organic Formulations & Natural Bio-Control'}
            </h3>
            <p className="text-[11px] text-slate-500">
              {lang === 'mr' ? 'घरच्या घरी बनवा जीवामृत, दशपर्णी अर्क व गांडूळ खत' : 'Homemade Jivamrut, Dashparni & Vermicompost'}
            </p>
          </div>
        </div>

        {/* Sub tabs for organic recipes */}
        <div className="grid grid-cols-4 gap-1 p-1 bg-slate-100 rounded-xl">
          {[
            { id: 'jivamrut', labelMr: 'जीवामृत', labelEn: 'Jivamrut' },
            { id: 'dashparni', labelMr: 'दशपर्णी', labelEn: 'Dashparni' },
            { id: 'vermicompost', labelMr: 'गांडूळ खत', labelEn: 'Vermi' },
            { id: 'carbon', labelMr: 'कार्बन क्रेडिट', labelEn: 'Carbon' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setOrganicPillarTab(tab.id as any)}
              className={`py-1.5 text-center text-xs font-bold rounded-lg transition-all ${
                organicPillarTab === tab.id
                  ? 'bg-white text-emerald-900 shadow-sm font-black'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {lang === 'mr' ? tab.labelMr : tab.labelEn}
            </button>
          ))}
        </div>

        {/* Tab Contents */}
        {organicPillarTab === 'jivamrut' && (
          <div className="p-3 bg-emerald-50/60 rounded-2xl border border-emerald-200 text-xs space-y-2">
            <div className="flex justify-between items-center">
              <span className="font-black text-emerald-950">
                🌱 {lang === 'mr' ? 'जीवामृत कृती (२०० लिटर बॅरलसाठी):' : 'Jivamrut Recipe (for 200L Drum):'}
              </span>
              <span className="text-[10px] bg-emerald-200 text-emerald-900 px-2 py-0.5 rounded font-bold">
                {lang === 'mr' ? '१ एकरासाठी' : 'For 1 Acre'}
              </span>
            </div>
            <ul className="space-y-1 text-slate-700 text-[11px] list-disc list-inside">
              <li>{lang === 'mr' ? '१० किलो देशी गायीचे ताजे शेण + १० लिटर गोमूत्र' : '10 kg fresh Desi Cow Dung + 10L Cow Urine'}</li>
              <li>{lang === 'mr' ? '२ किलो सेंद्रिय काळा गूळ + २ किलो बेसण (कडधान्य पीठ)' : '2 kg organic black Jaggery + 2 kg Gram Flour (Besan)'}</li>
              <li>{lang === 'mr' ? '१ मूठ बांधावरची जिवाणूयुक्त सुपीक माती + २०० लिटर पाणी' : '1 handful fertile bund soil + 200 Liters Water'}</li>
              <li>{lang === 'mr' ? '४८ तास सावलीत ढवळावे; ठिबकद्वारे किंवा आळवणीने द्यावे' : 'Stir clockwise for 48 hrs in shade; apply via drip/drenching'}</li>
            </ul>
          </div>
        )}

        {organicPillarTab === 'dashparni' && (
          <div className="p-3 bg-emerald-50/60 rounded-2xl border border-emerald-200 text-xs space-y-2">
            <div className="flex justify-between items-center">
              <span className="font-black text-emerald-950">
                🌿 {lang === 'mr' ? 'दशपर्णी अर्क (नैसर्गिक कीटकनाशक):' : 'Dashparni Ark (Natural Bio-Pesticide):'}
              </span>
              <span className="text-[10px] bg-emerald-200 text-emerald-900 px-2 py-0.5 rounded font-bold">
                {lang === 'mr' ? '१००% विषमुक्त' : 'Residue-Free'}
              </span>
            </div>
            <p className="text-[11px] text-slate-700">
              {lang === 'mr'
                ? 'कडुनिंब, करंज, धोत्रा, रुई, घाणेरी, सीताफळ, कणेर, तुळस, एरंड व पपई या १० वनस्पतींच्या पानांचा काढा. सर्व प्रकारच्या मावा, तुडतुडे, अळी व फुलकिडे १००% नियंत्रित होतात.'
                : 'Extract made of 10 bitter plant leaves (Neem, Karanj, Dhatura, Rui, Lantana, Custard apple, Castor, Papaya, Basil). Controls thrips, aphids, worms, and sucking pests naturally.'}
            </p>
          </div>
        )}

        {organicPillarTab === 'vermicompost' && (
          <div className="p-3 bg-emerald-50/60 rounded-2xl border border-emerald-200 text-xs space-y-2">
            <div className="flex justify-between items-center">
              <span className="font-black text-emerald-950">
                🪱 {lang === 'mr' ? 'गांडूळ खत (आयसेनिया फेटिडा):' : 'Vermicompost (Eisenia Foetida):'}
              </span>
              <span className="text-[10px] bg-emerald-200 text-emerald-900 px-2 py-0.5 rounded font-bold">
                NPK + सूक्ष्म अन्नद्रव्ये
              </span>
            </div>
            <p className="text-[11px] text-slate-700">
              {lang === 'mr'
                ? 'शेतीचा कचरा व शेणापासून ६० दिवसांत काळे सोने (गांडूळ खत) तयार होते. जमिनीचा सेंद्रिय कर्ब (Organic Carbon) ०.४ वरून ०.८% पर्यंत वाढतो.'
                : 'Converts agro-waste into black gold in 60 days. Increases soil organic carbon from 0.4% to over 0.8% and boosts microbial activity.'}
            </p>
          </div>
        )}

        {organicPillarTab === 'carbon' && (
          <div className="p-3 bg-emerald-50/60 rounded-2xl border border-emerald-200 text-xs space-y-2">
            <div className="flex justify-between items-center">
              <span className="font-black text-emerald-950">
                🌍 {lang === 'mr' ? 'कार्बन क्रेडिट्स व झाडे लागवड:' : 'Agri Carbon Credits & Tree Plantation:'}
              </span>
              <span className="text-[10px] bg-emerald-200 text-emerald-900 px-2 py-0.5 rounded font-bold">
                {lang === 'mr' ? 'अतिरिक्त उत्पन्न' : 'Extra Income'}
              </span>
            </div>
            <p className="text-[11px] text-slate-700">
              {lang === 'mr'
                ? 'सेंद्रिय शेती आणि बांधावर बांबू, साग किंवा फळझाडे लावणाऱ्या शेतकऱ्यांना प्रति एकर ₹२,५०० पर्यंत जागतिक कार्बन क्रेडिट्स परतावा मिळतो.'
                : 'Farmers adopting zero-tillage, organic farming and boundary tree plantations can earn up to ₹2,500/acre in carbon credit revenues.'}
            </p>
          </div>
        )}
      </div>

      {/* Interactive Green Farmer Scorecard (हरित शेतकरी प्रमाणपत्र) */}
      <div className="bg-gradient-to-br from-emerald-900 to-[#144818] text-white p-4 rounded-3xl shadow-sm border border-emerald-600 space-y-3">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-2">
            <Award className="w-6 h-6 text-amber-300 shrink-0" />
            <div>
              <h3 className="font-black text-sm text-white leading-tight">
                {lang === 'mr' ? 'तुमचा हरित शेतकरी स्कोअर (Green Score)' : 'Your Green Farmer Sustainability Score'}
              </h3>
              <p className="text-[11px] text-emerald-200">
                {lang === 'mr' ? 'पर्यावरणपूरक शेती पद्धती निवडून स्कोअर वाढवा' : 'Check eco-friendly practices to level up your farm score'}
              </p>
            </div>
          </div>
          <div className="text-right">
            <span className="text-xl font-black text-amber-300">{greenScorePercent}%</span>
            <span className="text-[10px] text-emerald-200 block">{lang === 'mr' ? 'हरित प्रगती' : 'Eco Progress'}</span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-emerald-950 rounded-full h-2.5 overflow-hidden">
          <div 
            className="bg-gradient-to-r from-amber-400 to-emerald-400 h-full rounded-full transition-all duration-500"
            style={{ width: `${greenScorePercent}%` }}
          />
        </div>

        {/* 6 Interactive Checkpoints */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          {[
            { key: 'drip', mr: 'ठिबक / तुषार सिंचन', en: 'Drip / Sprinkler' },
            { key: 'solar', mr: 'सौर कृषी पंप', en: 'Solar Agri Pump' },
            { key: 'organicManure', mr: 'जीवामृत / शेणखत', en: 'Organic Manure' },
            { key: 'cropRotation', mr: 'पीक फेरपालट', en: 'Crop Rotation' },
            { key: 'bioPesticide', mr: 'जैविक कीडनाशक', en: 'Bio-Pesticides' },
            { key: 'bundTrees', mr: 'बांधावर फळझाडे', en: 'Bund Trees' }
          ].map((item) => {
            const checked = greenScoreChecks[item.key];
            return (
              <button
                key={item.key}
                onClick={() => toggleCheck(item.key)}
                className={`p-2 rounded-xl text-left flex items-center justify-between border transition-all ${
                  checked 
                    ? 'bg-emerald-800/90 border-amber-400 text-white font-bold'
                    : 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
                }`}
              >
                <span className="text-[11px] truncate">{lang === 'mr' ? item.mr : item.en}</span>
                <CheckCircle2 className={`w-3.5 h-3.5 shrink-0 ${checked ? 'text-amber-300 fill-emerald-800' : 'text-emerald-700'}`} />
              </button>
            );
          })}
        </div>

        {greenScorePercent >= 70 && (
          <div className="bg-amber-400 text-slate-950 p-2.5 rounded-xl font-bold text-xs flex items-center justify-between shadow-md animate-fade-in">
            <div className="flex items-center gap-1.5">
              <Award className="w-4 h-4 text-emerald-950" />
              <span>{lang === 'mr' ? 'अभिनंदन! तुम्ही ५-स्टार हरित शेतकरी आहात 🌟' : 'Congrats! You are a 5-Star Green Farmer 🌟'}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
