const fs = require('fs');

let content = fs.readFileSync('src/data/agriData.ts', 'utf8');

const newLoans = `
  {
    id: 'pacs_pik_karj',
    nameMr: 'प्राथमिक कृषी पतसंस्था (PACS) पीक कर्ज',
    nameEn: 'PACS Crop Loan (Zero Percent Interest)',
    benefitMr: '₹३ लाख पर्यंत पीक कर्ज (वेळेवर परतफेड केल्यास ०% व्याज)',
    categoryMr: 'पतसंस्था पीक कर्ज',
    subsidyTag: '०% व्याज कर्ज',
    descriptionMr: 'गावातील विविध कार्यकारी सेवा सहकारी संस्था (V.K.S.S.) / पतसंस्था यांच्यामार्फत शेतकऱ्यांना खरीप व रब्बी हंगामासाठी पीक कर्ज दिले जाते. डॉ. पंजाबराव देशमुख व्याज सवलत योजनेअंतर्गत नियमित परतफेड करणाऱ्यांना ३ लाखांपर्यंत ०% व्याजाने कर्ज मिळते.',
    eligibilityMr: ['गावातील सोसायटीचे (पतसंस्थेचे) क्रियाशील सभासद असणे आवश्यक.', 'स्वतःच्या नावावर शेतजमीन (७/१२) असावी.', 'मागील कर्जाची थकबाकी नसावी.'],
    documentsMr: ['७/१२ आणि ८-अ उतारा', 'आधार कार्ड व पॅन कार्ड', 'दोन जामीनदार', 'पीक पेरा नोंद'],
    applyLink: 'https://sahakarayukta.maharashtra.gov.in/',
    videoMinutes: '५ मिनिट'
  },
  {
    id: 'bank_agri_term_loan',
    nameMr: 'राष्ट्रीयकृत / जिल्हा मध्यवर्ती बँक शेती विकास कर्ज',
    nameEn: 'Bank Agri Term Loan (Tractor, Drip, Well)',
    benefitMr: 'ट्रॅक्टर, विहीर व शेती विकासासाठी दीर्घ मुदतीचे कर्ज',
    categoryMr: 'बँक शेती कर्ज',
    subsidyTag: 'दीर्घ मुदत कर्ज',
    descriptionMr: 'शेतकऱ्यांना शेतीची अवजारे (ट्रॅक्टर, रोटावेटर), सिंचन सुविधा (विहीर, पाईपलाईन, शेततळे) आणि जोडधंद्यासाठी राष्ट्रीयकृत बँका (उदा. SBI, BOI) आणि जिल्हा मध्यवर्ती सहकारी बँका (DCCB) ५ ते ७ वर्षांसाठी दीर्घ मुदतीचे कर्ज देतात.',
    eligibilityMr: ['शेतजमीन धारक शेतकरी', 'चांगला सिबिल स्कोअर (CIBIL) किंवा मागील कर्ज परतफेड इतिहास चांगला असावा.', 'प्रकल्पासाठी आवश्यक तांत्रिक व आर्थिक क्षमता असावी.'],
    documentsMr: ['७/१२, ८-अ, फेरफार उतारा', 'आधार कार्ड, पॅन कार्ड', 'खरेदी करायच्या वस्तूचे/ट्रॅक्टरचे कोटेशन (Quotation)', 'वकिलांचा सर्च रिपोर्ट'],
    applyLink: 'https://sbi.co.in/web/agri-rural/agriculture-banking/crop-loan',
    videoMinutes: '६ मिनिट'
  },
`;

content = content.replace(
  /export const SARKARI_YOJANA_LIST: SarkariYojana\[\] = \[/,
  `export const SARKARI_YOJANA_LIST: SarkariYojana[] = [\n${newLoans}`
);

fs.writeFileSync('src/data/agriData.ts', content);
