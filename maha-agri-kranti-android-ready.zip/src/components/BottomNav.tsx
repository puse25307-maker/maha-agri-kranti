import React from 'react';
import { Home, Camera, ShoppingBag, Leaf, Menu } from 'lucide-react';
import { Language, TabType } from '../types';

interface BottomNavProps {
  activeTab: TabType;
  lang: Language;
  onSelectTab: (tab: TabType) => void;
}

interface NavTabItem {
  id: TabType;
  labelMr: string;
  labelEn: string;
  icon: React.ComponentType<{ className?: string }>;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, lang, onSelectTab }) => {
  const tabs: NavTabItem[] = [
    { id: 'home', labelMr: 'होम', labelEn: 'Home', icon: Home },
    { id: 'rog_doctor', labelMr: 'रोग AI', labelEn: 'Doc AI', icon: Camera },
    { id: 'sustainable', labelMr: 'शाश्वत विकास', labelEn: 'Green Agri', icon: Leaf },
    { id: 'maha_bazaar', labelMr: 'महा बाजार', labelEn: 'Market', icon: ShoppingBag },
    { id: 'menu', labelMr: 'मेनू ≡', labelEn: 'Menu ≡', icon: Menu },
  ];

  // Map any sub-tab that's inside menu to highlight the 'menu' tab if active
  const menuSubTabs: TabType[] = ['mati_pik', 'connect', 'us_belt', 'yojana', 'jod_dhanda', 'export', 'doctor', 'shala'];
  const effectiveActiveTab = menuSubTabs.includes(activeTab) ? 'menu' : activeTab;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md border-t border-slate-200/90 shadow-[0_-4px_16px_rgba(0,0,0,0.08)] safe-area-bottom">
      <div className="max-w-[430px] mx-auto grid grid-cols-5 px-1 py-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = effectiveActiveTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`flex flex-col items-center justify-center py-1 px-0.5 rounded-xl transition-all relative ${
                isActive
                  ? 'text-[#1B5E20] font-black scale-105'
                  : 'text-slate-500 hover:text-slate-900 font-medium'
              }`}
            >
              <div
                className={`p-1 rounded-xl transition-all ${
                  isActive 
                    ? 'bg-gradient-to-tr from-emerald-100 to-amber-100 text-[#1B5E20] shadow-sm' 
                    : 'text-slate-500'
                }`}
              >
                <Icon className="w-5 h-5" />
              </div>
              <span className="text-[10px] leading-tight tracking-tight mt-0.5 whitespace-nowrap">
                {lang === 'mr' ? tab.labelMr : tab.labelEn}
              </span>
              {isActive && (
                <span className="w-1.5 h-1.5 rounded-full bg-[#1B5E20] mt-0.5" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};


