import React, { useState } from 'react';
import { 
  Building2, 
  CheckCircle2, 
  PlayCircle, 
  Volume2, 
  ExternalLink, 
  FileText, 
  HelpCircle,
  X,
  Sparkles
} from 'lucide-react';
import { SARKARI_YOJANA_LIST } from '../data/agriData';
import { SarkariYojana } from '../types';
import { speakMarathi } from '../utils/speech';

export const Tab6SarkariYojana: React.FC = () => {
  const [selectedYojanaModal, setSelectedYojanaModal] = useState<SarkariYojana | null>(null);
  const [activeVideoYojana, setActiveVideoYojana] = useState<SarkariYojana | null>(null);

  const handleSpeakYojana = (yojana: SarkariYojana) => {
    const text = `${yojana.nameMr}. लाभ: ${yojana.benefitMr}. ${yojana.descriptionMr}. लागणारी कागदपत्रे: ${yojana.documentsMr.join(', ')}.`;
    speakMarathi(text);
  };

  const handleOpenVideoGuide = (yojana: SarkariYojana) => {
    setActiveVideoYojana(yojana);
    speakMarathi(`${yojana.nameMr} चा अर्ज कसा करावा याचा व्हिडिओ मार्गदर्शक उघडला आहे.`);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Header Banner */}
      <div className="bg-gradient-to-br from-[#1B5E20] via-emerald-800 to-slate-900 text-white p-3.5 rounded-2xl shadow-lg border border-emerald-500">
        <div className="flex items-center justify-between mb-1">
          <span className="bg-[#FFC107] text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
            🏛️ शासकीय योजना व थेट अनुदान
          </span>
          <span className="text-[10px] text-amber-300 font-bold">
            १००% अधिकृत मार्गदर्शक
          </span>
        </div>
        <h2 className="text-base font-black text-white leading-tight">
          महाराष्ट्र व केंद्र सरकारच्या ५ महत्त्वाच्या शेतकरी योजना!
        </h2>
        <p className="text-[11px] text-emerald-100 mt-0.5">
          अर्ज कसा करावा? कागदपत्रे व व्हिडिओ मार्गदर्शन एका क्लिकवर
        </p>
      </div>

      {/* 5 Scheme Cards with border-l-4 Green + Amount Badge + 2 Buttons */}
      <div className="space-y-3">
        {SARKARI_YOJANA_LIST.map((yojana) => (
          <div
            key={yojana.id}
            className="bg-white p-3.5 rounded-2xl shadow-md border border-slate-200 border-l-4 border-l-[#1B5E20] hover:shadow-lg transition-all"
          >
            <div className="flex items-start justify-between gap-2 mb-1.5">
              <span className="text-[10px] font-bold text-slate-500 uppercase">
                {yojana.categoryMr}
              </span>
              <span className="bg-emerald-100 text-emerald-950 text-[10px] font-black px-2 py-0.5 rounded-full border border-emerald-200">
                {yojana.subsidyTag}
              </span>
            </div>

            <h3 className="text-xs font-black text-slate-950 leading-tight mb-1">
              {yojana.nameMr}
            </h3>

            {/* Benefit Highlight Box */}
            <div className="bg-amber-50 p-2 rounded-xl border border-amber-200 mb-2">
              <span className="text-[10px] font-black text-amber-950 block">
                💰 थेट लाभ (Benefits):
              </span>
              <p className="text-xs font-bold text-emerald-900 mt-0.5">
                {yojana.benefitMr}
              </p>
            </div>

            <p className="text-[11px] text-slate-600 font-medium leading-relaxed mb-3">
              {yojana.descriptionMr}
            </p>

            {/* 2 Buttons: Video Guide + Aika */}
            <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-100">
              <button
                onClick={() => handleOpenVideoGuide(yojana)}
                className="bg-[#1B5E20] hover:bg-emerald-800 text-white font-bold py-2 px-2.5 rounded-xl text-[11px] flex items-center justify-center gap-1 shadow active:scale-95 transition-all"
              >
                <PlayCircle className="w-3.5 h-3.5 text-amber-400" />
                <span>अर्ज कसा करावा? Video</span>
              </button>

              <button
                onClick={() => handleSpeakYojana(yojana)}
                className="bg-amber-400 hover:bg-amber-500 text-slate-950 font-black py-2 px-2.5 rounded-xl text-[11px] flex items-center justify-center gap-1 shadow active:scale-95 transition-all"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>🔊 ऐका (Aika)</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Video Guide & Step-by-Step Modal */}
      {activeVideoYojana && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl border-2 border-emerald-600 overflow-hidden">
            <div className="bg-[#1B5E20] text-white p-3 flex items-center justify-between">
              <h3 className="font-bold text-xs text-amber-300">
                {activeVideoYojana.nameMr}
              </h3>
              <button onClick={() => setActiveVideoYojana(null)} className="text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 space-y-3 text-xs">
              {/* Video Mockup */}
              <div className="aspect-video bg-slate-900 rounded-xl flex flex-col items-center justify-center text-white p-3 relative overflow-hidden border border-slate-700">
                <PlayCircle className="w-10 h-10 text-amber-400 mb-1 animate-pulse" />
                <span className="text-xs font-bold text-amber-200 text-center">
                  ऑनलाईन अर्ज भरण्याची स्टेप-बाय-स्टेप कृती ({activeVideoYojana.videoMinutes})
                </span>
                <span className="text-[9px] bg-red-600 text-white px-2 py-0.5 rounded-full mt-1.5">
                  मराठी ट्यूटोरियल 📹
                </span>
              </div>

              {/* Required Documents */}
              <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                <span className="font-bold text-slate-900 block mb-1">📄 लागणारी आवश्यक कागदपत्रे:</span>
                <ul className="list-disc pl-4 space-y-0.5 text-[11px] text-slate-700">
                  {activeVideoYojana.documentsMr.map((doc, idx) => (
                    <li key={idx}>{doc}</li>
                  ))}
                </ul>
              </div>

              {/* Eligibility */}
              <div className="bg-emerald-50 p-2.5 rounded-xl border border-emerald-200">
                <span className="font-bold text-emerald-950 block mb-1">✅ कोण पात्र आहे? (Eligibility):</span>
                <ul className="list-disc pl-4 space-y-0.5 text-[11px] text-slate-700">
                  {activeVideoYojana.eligibilityMr.map((el, idx) => (
                    <li key={idx}>{el}</li>
                  ))}
                </ul>
              </div>

              <a
                href={activeVideoYojana.applyLink}
                target="_blank"
                rel="noreferrer"
                className="w-full bg-[#1B5E20] hover:bg-emerald-800 text-amber-300 font-black py-2.5 rounded-xl flex items-center justify-center gap-1.5 shadow"
              >
                <span>अधिकृत पोर्टलवर अर्ज उघडा</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
