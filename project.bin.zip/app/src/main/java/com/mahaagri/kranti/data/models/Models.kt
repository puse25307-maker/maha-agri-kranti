package com.mahaagri.kranti.data.models

enum class Language(val code: String, val displayName: String) {
    MARATHI("mr", "मराठी"),
    ENGLISH("en", "English")
}

enum class TabType {
    HOME,
    ROG_DOCTOR,
    SUSTAINABLE,
    EQUIPMENT,
    PROGRESSIVE_FARMERS,
    MAHA_BAZAAR,
    YOJANA,
    MATI_PIK,
    CONNECT,
    US_BELT,
    JOD_DHANDA,
    EXPORT,
    DOCTOR,
    SHALA,
    MENU
}

data class Medicine(
    val brand: String,
    val company: String,
    val dose: String,
    val timing: String
)

data class DiseaseInfo(
    val id: String,
    val nameMr: String,
    val nameEn: String,
    val cropMr: String,
    val cropEn: String,
    val seasonMr: String,
    val severityPercent: Int,
    val severityLabel: String,
    val upcharMr: String,
    val kharchMr: String,
    val medicines: List<Medicine>,
    val imagePlaceholder: String
)

data class DoctorExpert(
    val id: String,
    val name: String,
    val degree: String,
    val specialtyMr: String,
    val specialtyEn: String,
    val locationMr: String,
    val experience: String,
    val phone: String,
    val rating: Double,
    val isAvailable: Boolean = true,
    val avatar: String
)

data class FarmingEquipment(
    val id: String,
    val nameMr: String,
    val nameEn: String,
    val category: String, // tractor, harvester, drone, tiller, rotavator, implements, specialized
    val listingType: String, // rent, sell, both
    val condition: String, // new, used_good, used_fair
    val brand: String,
    val modelYear: String? = null,
    val hp: String? = null,
    val rentPerHour: Int? = null,
    val rentPerDay: Int? = null,
    val rentPerAcre: Int? = null,
    val sellingPrice: Int? = null,
    val ownerName: String,
    val phone: String,
    val village: String,
    val taluka: String,
    val district: String,
    val availability: String,
    val imageEmoji: String,
    val rating: Double,
    val badgeMr: String,
    val badgeEn: String,
    val fuelIncluded: Boolean = false,
    val driverIncluded: Boolean = false,
    val notesMr: String? = null
)

data class ProduceForSale(
    val itemMr: String,
    val itemEn: String,
    val quantityAvailable: String,
    val priceRate: String,
    val qualityGrade: String
)

data class ProgressiveFarmerStory(
    val id: String,
    val farmerName: String,
    val village: String,
    val taluka: String,
    val district: String,
    val region: String, // paschim, vidarbha, marathwada, khandesh, konkan
    val mainCropMr: String,
    val mainCropEn: String,
    val variety: String,
    val acres: Double,
    val cropYieldRecordMr: String,
    val cropYieldRecordEn: String,
    val netProfitPerAcreMr: String,
    val netProfitPerAcreEn: String,
    val bestFarmingTechniquesMr: List<String>,
    val bestFarmingTechniquesEn: List<String>,
    val produceForSale: List<ProduceForSale>,
    val phone: String,
    val whatsapp: String,
    val avatarEmoji: String,
    val experienceYears: Int,
    val awardsMr: String,
    val awardsEn: String,
    val storyQuoteMr: String,
    val storyQuoteEn: String,
    val verified: Boolean = true
)

data class LiveMandiRate(
    val mandi: String,
    val crop: String,
    val minPrice: Int,
    val maxPrice: Int,
    val avgPrice: Int,
    val trend: String // "up", "down", "stable"
)

data class MarketCropItem(
    val id: String,
    val nameMr: String,
    val nameEn: String,
    val emoji: String,
    val farmerName: String,
    val location: String,
    val qty: String,
    val directPrice: Int,
    val apmcPrice: Int,
    val contact: String,
    val tag: String? = null
)

data class SarkariYojana(
    val id: String,
    val nameMr: String,
    val nameEn: String,
    val benefitMr: String,
    val categoryMr: String,
    val subsidyTag: String,
    val descriptionMr: String,
    val eligibilityMr: List<String>,
    val documentsMr: List<String>,
    val applyLink: String,
    val videoMinutes: String
)

data class SugarcaneVariety(
    val code: String,
    val name: String,
    val yieldTon: String,
    val sugarPercent: String,
    val popularity: String,
    val waterRequirement: String,
    val highlightMr: String,
    val maturationDays: String
)

data class SugarKarkhana(
    val id: String,
    val nameMr: String,
    val location: String,
    val ratePerTon: Int,
    val paymentDays: Int,
    val frpBonus: Int,
    val rating: String,
    val isBest: Boolean = false
)

data class JodDhandaItem(
    val id: String,
    val titleMr: String,
    val titleEn: String,
    val iconEmoji: String,
    val monthlyIncome: String,
    val setupCost: String,
    val loanScheme: String,
    val subsidyPercent: String,
    val stepsMr: List<String>,
    val marketTips: String
)

data class AgriVideoLesson(
    val id: String,
    val titleMr: String,
    val titleEn: String,
    val duration: String,
    val views: String,
    val savingsBenefit: String,
    val category: String,
    val summaryMr: String,
    val keyPoints: List<String>,
    val thumbnailGradient: String
)

data class RegionFarmer(
    val id: String,
    val name: String,
    val taluka: String,
    val district: String,
    val region: String,
    val cropMr: String,
    val acres: Double,
    val phone: String,
    val verified: Boolean,
    val avatar: String,
    val notes: String
)
