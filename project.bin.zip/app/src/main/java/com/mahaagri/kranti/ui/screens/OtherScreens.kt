package com.mahaagri.kranti.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mahaagri.kranti.data.datasource.AgriDatabase
import com.mahaagri.kranti.data.models.Language
import com.mahaagri.kranti.data.models.TabType
import com.mahaagri.kranti.ui.theme.*

@Composable
fun UsBeltScreen(lang: Language, onBack: () -> Unit) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                Text(text = "ऊस पट्टा व साखर कारखाने दर 🎋", fontSize = 15.sp, fontWeight = FontWeight.Black, color = Slate900)
            }
        }

        items(AgriDatabase.sugarKarkhanas) { karkhana ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = karkhana.nameMr, fontSize = 13.sp, fontWeight = FontWeight.Black, color = Slate900, modifier = Modifier.weight(1f))
                        Text(text = karkhana.rating, fontSize = 11.sp, color = Amber700, fontWeight = FontWeight.Bold)
                    }
                    Text(text = "ठिकाण: ${karkhana.location}", fontSize = 10.sp, color = Slate500)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Amber100.copy(alpha = 0.5f))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "FRP दर: ₹${karkhana.ratePerTon} / टन", fontSize = 11.sp, fontWeight = FontWeight.Black, color = Green800)
                        Text(text = "पेमेंट कालावधी: ${karkhana.paymentDays} दिवस", fontSize = 10.sp, color = Slate700)
                    }
                }
            }
        }
    }
}

@Composable
fun JodDhandaScreen(lang: Language, onBack: () -> Unit) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                Text(text = "शेतीपूरक जोडधंदे व नाबार्ड सबसिडी 🐄", fontSize = 15.sp, fontWeight = FontWeight.Black, color = Slate900)
            }
        }

        items(AgriDatabase.jodDhandaItems) { item ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = item.iconEmoji, fontSize = 24.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = item.titleMr, fontSize = 13.sp, fontWeight = FontWeight.Black, color = Slate900)
                    }
                    Text(text = "मासिक उत्पन्न: ${item.monthlyIncome}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Green800)
                    Text(text = "प्रकल्प खर्च: ${item.setupCost} | अनुदान: ${item.subsidyPercent}", fontSize = 10.sp, color = Amber700, fontWeight = FontWeight.Bold)
                    Text(text = "💡 विक्री टिप्स: ${item.marketTips}", fontSize = 10.sp, color = Slate600)
                }
            }
        }
    }
}

@Composable
fun DoctorHelplineScreen(lang: Language, onCallPhone: (String) -> Unit, onBack: () -> Unit) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                Text(text = "वरिष्ठ कृषी शास्त्रज्ञ व डॉक्टर फोन 👨‍⚕️", fontSize = 15.sp, fontWeight = FontWeight.Black, color = Slate900)
            }
        }

        items(AgriDatabase.doctors) { doc ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Text(text = doc.avatar, fontSize = 32.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(text = doc.name, fontSize = 13.sp, fontWeight = FontWeight.Black, color = Slate900)
                            Text(text = doc.specialtyMr, fontSize = 10.sp, color = Green800, fontWeight = FontWeight.Bold)
                            Text(text = "${doc.locationMr} • ${doc.experience}", fontSize = 9.sp, color = Slate500)
                        }
                    }

                    Button(
                        onClick = { onCallPhone(doc.phone) },
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(containerColor = Green800),
                        contentPadding = PaddingValues(10.dp)
                    ) {
                        Icon(Icons.Default.Phone, contentDescription = "Call", tint = Amber500, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun MatiPikScreen(lang: Language, onBack: () -> Unit) {
    var ph by remember { mutableStateOf(7.2f) }
    var ec by remember { mutableStateOf(0.45f) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                Text(text = "माती परीक्षण व खत नियोजन 🧪", fontSize = 15.sp, fontWeight = FontWeight.Black, color = Slate900)
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = "आपल्या जमिनीचा सामू (pH): $ph", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Slate900)
                    Slider(
                        value = ph,
                        onValueChange = { ph = ((it * 10).toInt() / 10f) },
                        valueRange = 5.5f..9.0f,
                        colors = SliderDefaults.colors(thumbColor = Green800, activeTrackColor = Green800)
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (ph in 6.5f..7.8f) Green100 else Amber100)
                            .padding(10.dp)
                    ) {
                        Text(
                            text = if (ph in 6.5f..7.8f)
                                "✅ उत्तम सामू (pH 6.5-7.8): केळी, ऊस, द्राक्ष व कांदा पिकासाठी अत्यंत सुपीक जमीन."
                            else
                                "⚠️ चोपण / आम्लयुक्त जमीन: जिप्सम किंवा सेंद्रिय खतांचा वापर वाढवणे आवश्यक आहे.",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (ph in 6.5f..7.8f) Green900 else Slate900
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ConnectScreen(lang: Language, onBack: () -> Unit) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                Text(text = "महाराष्ट्र शेतकरी समुदाय 🤝", fontSize = 15.sp, fontWeight = FontWeight.Black, color = Slate900)
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Green50)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = "🚩 पश्चिम महाराष्ट्र, विदर्भ व मराठवाडा शेतकरी गट", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Green900)
                    Text(text = "हजारो शेतकरी अनुभवांची देवाणघेवाण करतात आणि एकत्रित खरेदी द्वारे ३०% खत-औषध खर्च वाचवतात.", fontSize = 11.sp, color = Slate700)
                }
            }
        }
    }
}

@Composable
fun ExportScreen(lang: Language, onBack: () -> Unit) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                Text(text = "थेट निर्यात दुबई, इराण व युरोप 🚢", fontSize = 15.sp, fontWeight = FontWeight.Black, color = Slate900)
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = "🍌 केळी दुबई निर्यात मानके (APEDA Standards)", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Slate900)
                    Text(text = "• घड वय: कापणी वेळी ३८-४२ मिमी कॅलिबर\n• डागरहित ३५ मायक्रॉन ब्लू स्कर्टिंग बॅगिंग\n• पॅकहाऊस ग्रेडिंग व तापमान १३.५° से. मेंटेन", fontSize = 11.sp, color = Slate700)
                }
            }
        }
    }
}

@Composable
fun ShalaScreen(lang: Language, onBack: () -> Unit) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                Text(text = "कृषी ज्ञान शाळा मास्टरक्लास 🎓", fontSize = 15.sp, fontWeight = FontWeight.Black, color = Slate900)
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = "📺 ऊस १५० टन व ठिबक फर्टीगेशन मास्टरक्लास", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Slate900)
                    Text(text = "कालावधी: २० मिनिटे | ३०,०००+ शेतकऱ्यांनी पाहिले", fontSize = 10.sp, color = Slate500)
                    Button(
                        onClick = {},
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Green800)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Amber500, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "व्हिडिओ पहा")
                    }
                }
            }
        }
    }
}
