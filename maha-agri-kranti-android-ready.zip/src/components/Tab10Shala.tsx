import React, { useState } from 'react';
import { 
  GraduationCap, 
  PlayCircle, 
  Volume2, 
  Clock, 
  Eye, 
  Sparkles, 
  CheckCircle2, 
  FileText,
  X,
  Play,
  Award
} from 'lucide-react';
import { AGRI_VIDEO_LESSONS } from '../data/agriData';
import { AgriVideoLesson } from '../types';
import { speakMarathi } from '../utils/speech';

export const Tab10Shala: React.FC = () => {
  const [activeVideoModal, setActiveVideoModal] = useState<AgriVideoLesson | null>(null);
  const [isPlayingSimulated, setIsPlayingSimulated] = useState<boolean>(false);

  const handlePlayVideo = (lesson: AgriVideoLesson) => {
    setActiveVideoModal(lesson);
    setIsPlayingSimulated(true);
    speakMarathi(`${lesson.titleMr}. धडा सुरू झाला आहे.`);
  };

  const handleSpeakSummary = (lesson: AgriVideoLesson) => {
    const text = `${lesson.titleMr}. कालावधी ${lesson.duration}. मुख्य फायदे: ${lesson.savingsBenefit}. सारांश: ${lesson.summaryMr}. मुख्य मुद्दे: ${lesson.keyPoints.join('. ')}.`;
    speakMarathi(text);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Header Banner */}
      <div className="bg-gradient-to-br from-[#1B5E20] via-emerald-800 to-slate-900 text-white p-3.5 rounded-2xl shadow-lg border border-emerald-500">
        <div className="flex items-center justify-between mb-1">
          <span className="bg-[#FFC107] text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
            🎓 महा कृषी शाळा - व्हिडिओ शिक्षण
          </span>
          <span className="text-[10px] text-amber-300 font-bold">
            १००% मोफत प्रॅक्टिकल ज्ञान
          </span>
        </div>
        <h2 className="text-base font-black text-white leading-tight">
          आधुनिक तंत्रज्ञान शिका — शेतीत क्रांती घडवा!
        </h2>
        <p className="text-[11px] text-emerald-100 mt-0.5">
          ठिबक, पॉलिहाऊस, ड्रोन फवारणी व परदेश निर्यात पॅकिंगचे व्हिडिओ
        </p>
      </div>

      {/* 4 Video Cards */}
      <div className="space-y-3.5">
        {AGRI_VIDEO_LESSONS.map((lesson) => (
          <div
            key={lesson.id}
            className="bg-white rounded-2xl shadow-md border border-slate-200 overflow-hidden hover:border-emerald-500 transition-all"
          >
            {/* Black/Dark Video Thumbnail with Play Icon */}
            <div
              onClick={() => handlePlayVideo(lesson)}
              className={`relative aspect-video bg-gradient-to-br ${lesson.thumbnailGradient} flex flex-col items-center justify-center text-white cursor-pointer group p-4`}
            >
              <div className="w-14 h-14 rounded-full bg-[#FFC107] text-slate-950 flex items-center justify-center shadow-2xl group-hover:scale-110 transition-transform">
                <Play className="w-7 h-7 fill-slate-950 ml-1" />
              </div>

              <div className="absolute top-2 left-2 bg-slate-950/80 backdrop-blur-md px-2 py-0.5 rounded-md text-[10px] font-bold text-amber-300 border border-emerald-500/30">
                {lesson.category}
              </div>

              <div className="absolute bottom-2 right-2 bg-slate-950/80 backdrop-blur-md px-2 py-0.5 rounded-md text-[10px] font-bold flex items-center gap-1">
                <Clock className="w-3 h-3 text-amber-400" />
                <span>{lesson.duration}</span>
              </div>

              <div className="absolute bottom-2 left-2 text-[10px] text-slate-300 font-semibold flex items-center gap-1">
                <Eye className="w-3 h-3 text-emerald-400" />
                <span>{lesson.views}</span>
              </div>
            </div>

            {/* Video Content & Controls */}
            <div className="p-3.5 space-y-2">
              <h3 className="font-black text-xs text-slate-950 leading-snug">
                {lesson.titleMr}
              </h3>

              <div className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-800 bg-emerald-50 p-2 rounded-xl border border-emerald-200">
                <Sparkles className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>फायदा: {lesson.savingsBenefit}</span>
              </div>

              <p className="text-[11px] text-slate-600 font-medium leading-relaxed">
                {lesson.summaryMr}
              </p>

              {/* 2 Buttons: Play & Aika */}
              <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-100">
                <button
                  onClick={() => handlePlayVideo(lesson)}
                  className="bg-[#1B5E20] hover:bg-emerald-800 text-white font-bold py-2 px-2.5 rounded-xl text-xs flex items-center justify-center gap-1 shadow active:scale-95 transition-all"
                >
                  <PlayCircle className="w-3.5 h-3.5 text-amber-400" />
                  <span>व्हिडिओ पहा</span>
                </button>

                <button
                  onClick={() => handleSpeakSummary(lesson)}
                  className="bg-amber-400 hover:bg-amber-500 text-slate-950 font-black py-2 px-2.5 rounded-xl text-xs flex items-center justify-center gap-1 shadow active:scale-95 transition-all"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>🔊 ऐका (Aika)</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Video Player Modal */}
      {activeVideoModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl border-2 border-emerald-600 overflow-hidden">
            <div className="bg-[#1B5E20] text-white p-3 flex items-center justify-between">
              <h3 className="font-bold text-xs text-amber-300 line-clamp-1">
                {activeVideoModal.titleMr}
              </h3>
              <button onClick={() => setActiveVideoModal(null)} className="text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 space-y-3 text-xs">
              {/* Simulated Video Player */}
              <div className="aspect-video bg-slate-950 rounded-xl relative flex flex-col items-center justify-center text-white overflow-hidden border border-slate-700">
                <div className="w-12 h-12 rounded-full bg-red-600 text-white flex items-center justify-center shadow-lg animate-pulse mb-2">
                  <Play className="w-6 h-6 ml-0.5 fill-white" />
                </div>
                <span className="text-xs font-bold text-amber-200 px-3 text-center">
                  प्रशिक्षण व्हिडिओ चालू आहे... ({activeVideoModal.duration})
                </span>
                <div className="w-full bg-slate-800 h-1.5 absolute bottom-0 left-0">
                  <div className="bg-amber-400 h-full w-2/3 animate-pulse"></div>
                </div>
              </div>

              {/* Practical Lesson Key Takeaways */}
              <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-200">
                <span className="font-black text-emerald-950 block mb-1.5 flex items-center gap-1">
                  <Award className="w-4 h-4 text-emerald-700" />
                  या व्हिडिओतून काय शिकाल? (Key Takeaways):
                </span>
                <ul className="space-y-1.5 text-[11px] text-slate-800 font-medium">
                  {activeVideoModal.keyPoints.map((point, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700 shrink-0 mt-0.5" />
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <button
                onClick={() => setActiveVideoModal(null)}
                className="w-full bg-slate-900 text-white font-bold py-2 rounded-xl text-xs"
              >
                धडा पूर्ण झाला (Close)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
