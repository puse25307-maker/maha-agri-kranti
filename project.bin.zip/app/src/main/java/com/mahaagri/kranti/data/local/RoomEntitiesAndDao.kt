package com.mahaagri.kranti.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "scan_history")
data class ScanHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cropName: String,
    val diseaseName: String,
    val severityPercent: Int,
    val scannedDate: String,
    val imageUri: String? = null,
    val notes: String? = null
)

@Entity(tableName = "user_equipment_listings")
data class UserEquipmentEntity(
    @PrimaryKey val id: String,
    val title: String,
    val category: String,
    val listingType: String, // rent or sell
    val rate: String,
    val phone: String,
    val location: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface ScanHistoryDao {
    @Query("SELECT * FROM scan_history ORDER BY id DESC")
    fun getAllHistory(): Flow<List<ScanHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScan(scan: ScanHistoryEntity)

    @Delete
    suspend fun deleteScan(scan: ScanHistoryEntity)
}

@Dao
interface UserEquipmentDao {
    @Query("SELECT * FROM user_equipment_listings ORDER BY createdAt DESC")
    fun getAllEquipment(): Flow<List<UserEquipmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEquipment(equipment: UserEquipmentEntity)

    @Delete
    suspend fun deleteEquipment(equipment: UserEquipmentEntity)
}

@Database(
    entities = [ScanHistoryEntity::class, UserEquipmentEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppRoomDatabase : RoomDatabase() {
    abstract fun scanHistoryDao(): ScanHistoryDao
    abstract fun userEquipmentDao(): UserEquipmentDao
}
