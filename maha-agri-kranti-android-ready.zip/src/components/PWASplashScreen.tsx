import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, ShieldCheck } from 'lucide-react';

interface PWASplashScreenProps {
  onFinish?: () => void;
}

export const PWASplashScreen: React.FC<PWASplashScreenProps> = ({ onFinish }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    // Check session storage if splash already shown in this session (optional, or show briefly)
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setIsVisible(false);
            if (onFinish) onFinish();
          }, 250);
          return 100;
        }
        return prev + 12;
      });
    }, 100);

    return () => clearInterval(interval);
  }, [onFinish]);

  const handleDismiss = () => {
    setIsVisible(false);
    if (onFinish) onFinish();
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.03 }}
          transition={{ duration: 0.4, ease: 'easeInOut' }}
          onClick={handleDismiss}
          className="fixed inset-0 z-[9999] flex flex-col items-center justify-between bg-gradient-to-b from-[#1B5E20] via-[#0F3E14] to-[#08230B] text-white p-6 select-none cursor-pointer overflow-hidden"
          style={{ backgroundColor: '#1B5E20' }}
        >
          {/* Top Maharashtra Theme Accent */}
          <div className="w-full flex items-center justify-between pt-4 px-2">
            <span className="text-xs font-bold text-amber-300 tracking-wider flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" />
              महाराष्ट्र शासन कृषी सेवा संकल्पना
            </span>
            <span className="text-[11px] bg-amber-400 text-slate-950 font-black px-2.5 py-0.5 rounded-full shadow">
              OFFLINE READY
            </span>
          </div>

          {/* Center Brand & Slogan */}
          <div className="flex flex-col items-center justify-center text-center my-auto w-full max-w-sm">
            {/* Glowing Sprout Icon Circle */}
            <motion.div
              initial={{ scale: 0.7, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5, ease: 'easeOut' }}
              className="relative mb-6"
            >
              {/* Outer Golden Glow */}
              <div className="w-32 h-32 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 p-1 shadow-2xl shadow-emerald-950 flex items-center justify-center animate-pulse">
                <div className="w-full h-full rounded-full bg-[#124618] border-2 border-emerald-400/50 flex flex-col items-center justify-center relative overflow-hidden">
                  <span className="text-5xl filter drop-shadow">🌱</span>
                  <div className="absolute bottom-1.5 text-[9px] font-black text-amber-300 tracking-widest uppercase">
                    MAHA AGRI
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Saffron Flag & Slogan */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.15, duration: 0.45 }}
              className="flex flex-col items-center gap-1.5"
            >
              <div className="flex items-center gap-2">
                <span className="text-3xl">🚩</span>
                <h1 className="text-3xl sm:text-4xl font-black text-amber-300 tracking-wider drop-shadow-md font-sans">
                  JAY MAHARASHTRA
                </h1>
                <span className="text-3xl">🚩</span>
              </div>

              <div className="font-yatra text-xl sm:text-2xl font-black text-emerald-200 tracking-wide mt-1">
                || जय महाराष्ट्र ||
              </div>
            </motion.div>

            {/* App Title */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.45 }}
              className="mt-6 flex flex-col items-center"
            >
              <div className="inline-flex items-center gap-1.5 bg-black/40 border border-amber-400/60 px-4 py-1 rounded-full text-xs font-black text-amber-300 uppercase tracking-widest shadow-inner mb-2">
                <span>🌱 MAHA AGRI KRANTI</span>
              </div>
              <p className="text-sm font-bold text-emerald-100 max-w-xs leading-relaxed">
                महाराष्ट्रातील शेतकऱ्यांचे शाश्वत, आधुनिक व डिजिटल कृषी महा-ॲप
              </p>
            </motion.div>
          </div>

          {/* Bottom Progress & Tap info */}
          <div className="w-full max-w-xs flex flex-col items-center gap-3 pb-6">
            <div className="w-full bg-black/50 h-2 rounded-full overflow-hidden border border-emerald-700/60 p-0.5">
              <motion.div
                className="h-full bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 rounded-full"
                style={{ width: `${progress}%` }}
              />
            </div>

            <div className="flex items-center justify-between w-full text-[10px] text-emerald-200/80 font-medium">
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                १००% मोफत व सुरक्षित
              </span>
              <span>सुरू होत आहे... {progress}%</span>
            </div>

            <p className="text-[10px] text-slate-400">
              ॲप उघडण्यासाठी कुठेही स्पर्श करा (Tap to open)
            </p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
