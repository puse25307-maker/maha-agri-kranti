import React, { useState } from 'react';
import { 
  Camera, 
  Upload, 
  Search, 
  PhoneCall, 
  Send, 
  AlertTriangle, 
  CheckCircle2, 
  Sparkles, 
  FileText, 
  Calendar, 
  CloudSun, 
  Mic, 
  Store, 
  History, 
  Video, 
  Volume2,
  X,
  Clock,
  ShieldCheck,
  FolderOpen,
  Image as ImageIcon
} from 'lucide-react';
import { DISEASES_DATABASE, DOCTOR_EXPERTS } from '../data/agriData';
import { DiseaseInfo, DoctorExpert } from '../types';
import { speakMarathi } from '../utils/speech';

export const Tab1RogDoctor: React.FC = () => {
  const [selectedDisease, setSelectedDisease] = useState<DiseaseInfo>(DISEASES_DATABASE[0]);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [modalTitle, setModalTitle] = useState<string>('');
  const [modalContent, setModalContent] = useState<React.ReactNode | null>(null);
  const [selectedDoctorForContact, setSelectedDoctorForContact] = useState<DoctorExpert | null>(null);
  const [callAlert, setCallAlert] = useState<string | null>(null);
  const [voiceQueryActive, setVoiceQueryActive] = useState<boolean>(false);
  const [isDragOver, setIsDragOver] = useState<boolean>(false);
  const [historyItems, setHistoryItems] = useState([
    { date: '२२ ऑगस्ट २०२६', crop: 'केळी (G9)', disease: 'सिगाटोका बुरशी', status: 'उपचार सुरू' },
    { date: '१५ जुलै २०२६', crop: 'ऊस (86032)', disease: 'पोक्का बोईंग', status: 'बरी झाली' }
  ]);

  const handleProcessFile = (file: File, sourceName: string) => {
    const reader = new FileReader();
    reader.onload = () => {
      setPreviewImage(reader.result as string);
      setIsScanning(true);
      setTimeout(() => {
        setIsScanning(false);
        speakMarathi(`${sourceName} मधून फोटो यशस्वीरित्या निवडला. एआय रोग निदान पूर्ण झाले.`);
      }, 600);
    };
    reader.readAsDataURL(file);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, sourceName: string = 'इंटरनल स्टोरेज') => {
    const file = e.target.files?.[0];
    if (file) {
      handleProcessFile(file, sourceName);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleProcessFile(file, 'इंटरनल स्टोरेज');
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const runScanAnimation = (diseaseToSet?: DiseaseInfo) => {
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      if (diseaseToSet) {
        setSelectedDisease(diseaseToSet);
      }
    }, 1200);
  };

  const handleSelectPreset = (disease: DiseaseInfo) => {
    setPreviewImage(null);
    setSelectedDisease(disease);
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      // Auto voice announcement cue or scroll
      speakMarathi(`${disease.cropMr} - ${disease.nameMr} रोग निदान पूर्ण झाले.`);
    }, 400);
  };

  const handleOpenAushadhDukan = () => {
    setModalTitle('🛒 अधिकृत औषध दुकान (Aushadh Dukan) - खरेदी व संपर्क');
    setModalContent(
      <div className="space-y-3 text-xs">
        <div className="bg-emerald-50 p-2.5 rounded-xl border border-emerald-200 text-emerald-950 font-bold">
          📍 जवळची अधिकृत कृषी सेवा केंद्रे (ओरिजिनल औषधे हमी):
        </div>
        <div className="p-3 bg-slate-50 border rounded-xl space-y-1">
          <div className="flex justify-between items-center">
            <span className="font-bold text-slate-900 text-xs">जय किसान कृषी केंद्र, इंदापूर</span>
            <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-1.5 py-0.5 rounded">उपलब्ध</span>
          </div>
          <p className="text-slate-600 text-[11px]">टिल्ट (Tilt 1ml/L) + बाविस्टीन (Bavistin) स्टॉक उपलब्ध</p>
          <div className="flex gap-2 pt-1">
            <button 
              onClick={() => {
                setCallAlert('📞 जय किसान कृषी केंद्र, इंदापूर (9822014000) ला कॉल लागत आहे...');
                speakMarathi('कृषी सेवा केंद्राशी संपर्क जोडला जात आहे.');
                setTimeout(() => setCallAlert(null), 4000);
              }}
              className="bg-emerald-700 text-white px-2.5 py-1 rounded-lg font-bold flex items-center gap-1 text-[11px]"
            >
              <PhoneCall className="w-3 h-3" /> कॉल करा
            </button>
            <button 
              onClick={() => {
                setCallAlert('✅ टिल्ट + बाविस्टीन औषध ऑर्डर बुक झाली! दुकानातून घरपोच डिलिव्हरी केली जाईल.');
                speakMarathi('तुमची औषध ऑर्डर यशस्वीरीत्या नोंदवली गेली.');
                setTimeout(() => setCallAlert(null), 4000);
              }}
              className="bg-amber-400 text-slate-950 px-2.5 py-1 rounded-lg font-bold text-[11px]"
            >
              🛒 घरपोच मागवा (₹४५०)
            </button>
          </div>
        </div>

        <div className="p-3 bg-slate-50 border rounded-xl space-y-1">
          <div className="flex justify-between items-center">
            <span className="font-bold text-slate-900 text-xs">सह्याद्री अ‍ॅग्रो एजन्सी, पिंपळगाव नाशिक</span>
            <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-1.5 py-0.5 rounded">१०% सूट</span>
          </div>
          <p className="text-slate-600 text-[11px]">द्राक्ष व केळी स्पेशल बुरशीनाशके उपलब्ध</p>
          <div className="flex gap-2 pt-1">
            <button 
              onClick={() => {
                setCallAlert('📞 सह्याद्री अ‍ॅग्रो एजन्सी, नाशिक (0253-240055) ला कॉल लागत आहे...');
                speakMarathi('सह्याद्री कृषी केंद्राशी संपर्क जोडला जात आहे.');
                setTimeout(() => setCallAlert(null), 4000);
              }}
              className="bg-emerald-700 text-white px-2.5 py-1 rounded-lg font-bold flex items-center gap-1 text-[11px]"
            >
              <PhoneCall className="w-3 h-3" /> कॉल करा
            </button>
          </div>
        </div>
      </div>
    );
    setActiveModal('8');
  };

  const handleVoiceListenResult = () => {
    const speechText = `रोग नाव: ${selectedDisease.nameMr}. हंगाम: ${selectedDisease.seasonMr}. तीव्रता: ${selectedDisease.severityLabel}. उपचार: ${selectedDisease.upcharMr}. एकरी फवारणी खर्च अंदाजे ${selectedDisease.kharchMr} रुपये आहे. तात्काळ उपायासाठी सायजेंटा टिल्ट एक मिली प्रति लिटर पाण्यात मिसळून फवारा.`;
    speakMarathi(speechText);
  };

  const handleDoctorCall = (doc: DoctorExpert) => {
    setCallAlert(`📞 ${doc.name} यांच्याशी थेट संपर्क जोडला जात आहे... फोन: ${doc.phone}`);
    speakMarathi(`${doc.name} यांना विनामूल्य कॉल लावला जात आहे.`);
    setTimeout(() => setCallAlert(null), 5000);
  };

  const handleSendPhotoToDoctor = () => {
    setCallAlert(`✅ ${selectedDisease.nameMr} चा फोटो व अहवाल डॉ. अनिल पवार (इंदापूर) यांना WhatsApp वर पाठवला गेला आहे!`);
    speakMarathi(`तुमचा रोग अहवाल डॉक्टर पवार यांच्याकडे यशस्वीरित्या पाठवला आहे.`);
    setTimeout(() => setCallAlert(null), 5000);
  };

  const openGridFeature = (pointNumber: number) => {
    switch (pointNumber) {
      case 1:
        setModalTitle('१. AI फोटो स्कॅनर (Gemini 1.5 Flash)');
        setModalContent(
          <div className="space-y-3 text-sm">
            <p className="font-semibold text-emerald-900">पानाच्या फोटोवरून ९५% अचूक रोग निदान:</p>
            <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-200">
              <ul className="list-disc pl-5 space-y-1 text-slate-700">
                <li>कॅमेरा पानाच्या जवळ ४ इंचावर धरा.</li>
                <li>सूर्यप्रकाशात स्पष्ट फोटो काढा.</li>
                <li>एआय सिस्टिम बुरशी, कीड, आणि अन्नद्रव्य कमतरता ओळखते.</li>
              </ul>
            </div>
          </div>
        );
        break;
      case 2:
        setModalTitle('२. औषध मात्रा व कंपनी माहिती');
        setModalContent(
          <div className="space-y-3 text-sm">
            <p className="font-bold text-slate-900">प्रमाणित औषधे व कंपन्या (Bayer, Syngenta, UPL):</p>
            <div className="space-y-2">
              {selectedDisease.medicines.map((m, idx) => (
                <div key={idx} className="bg-amber-50 p-2.5 rounded-xl border border-amber-200 text-xs">
                  <div className="font-bold text-amber-900">{m.brand} ({m.company})</div>
                  <div className="text-slate-700">मात्रा: <span className="font-bold text-emerald-800">{m.dose}</span></div>
                  <div className="text-slate-600 text-[11px]">वेळ: {m.timing}</div>
                </div>
              ))}
            </div>
          </div>
        );
        break;
      case 3:
        setModalTitle('३. ६ तज्ज्ञ डॉक्टर थेट फोन (सकाळी ७ ते रात्री ८)');
        setModalContent(
          <div className="space-y-2 text-sm max-h-72 overflow-y-auto">
            {DOCTOR_EXPERTS.map(doc => (
              <div key={doc.id} className="p-2 bg-slate-50 border rounded-xl flex items-center justify-between">
                <div>
                  <div className="font-bold text-xs">{doc.name}</div>
                  <div className="text-[10px] text-emerald-800">{doc.specialtyMr}</div>
                </div>
                <button 
                  onClick={() => handleDoctorCall(doc)}
                  className="bg-emerald-700 text-white text-xs px-2.5 py-1 rounded-lg font-bold flex items-center gap-1"
                >
                  <PhoneCall className="w-3 h-3" /> कॉल
                </button>
              </div>
            ))}
          </div>
        );
        break;
      case 4:
        setModalTitle('४. २ मिनिट मराठी व्हिडिओ सल्ला');
        setModalContent(
          <div className="space-y-3 text-sm">
            <div className="aspect-video bg-slate-900 rounded-xl flex flex-col items-center justify-center text-white p-4 relative overflow-hidden">
              <Video className="w-10 h-10 text-amber-400 mb-2 animate-bounce" />
              <p className="font-bold text-xs text-center text-amber-200">डॉ. अनिल पवार यांचा २ मिनिटांचा सिगाटोका नियंत्रण व्हिडिओ</p>
              <span className="text-[10px] bg-red-600 px-2 py-0.5 rounded-full mt-2">HD Marathi Video 📹</span>
            </div>
            <p className="text-xs text-slate-600">केळीच्या पानावर ठिबक व फवारणी करताना कोणती काळजी घ्यावी याचे थेट प्रात्यक्षिक.</p>
          </div>
        );
        break;
      case 5:
        setModalTitle('५. फवारणी वेळापत्रक PDF (दिवस १ ते ३५०)');
        setModalContent(
          <div className="space-y-3 text-sm">
            <p className="text-xs text-slate-700">पिकाच्या लागवडीपासून काढणीपर्यंत संपूर्ण ३५० दिवसांचे फवारणी व खत वेळापत्रक:</p>
            <div className="space-y-1.5">
              <div className="p-2 bg-emerald-50 rounded-lg text-xs flex justify-between font-bold">
                <span>दिवस १-३० (मुळे फुटणे)</span>
                <span className="text-emerald-800">19:19:19 + ह्युमिक</span>
              </div>
              <div className="p-2 bg-emerald-50 rounded-lg text-xs flex justify-between font-bold">
                <span>दिवस ३०-९० (झाडांची वाढ)</span>
                <span className="text-emerald-800">12:61:00 + मायक्रोन्युट्रियंट</span>
              </div>
              <div className="p-2 bg-emerald-50 rounded-lg text-xs flex justify-between font-bold">
                <span>दिवस ९०-१८० (घडाची निर्मिती)</span>
                <span className="text-emerald-800">00:52:34 + बोरॉन</span>
              </div>
              <div className="p-2 bg-amber-50 rounded-lg text-xs flex justify-between font-bold">
                <span>दिवस १८०-३०० (वजन व चमक)</span>
                <span className="text-amber-800">00:00:50 पोटॅश</span>
              </div>
            </div>
            <button 
              onClick={() => speakMarathi('३५० दिवसांचे फवारणी वेळापत्रक तुमच्या फोनमध्ये डाउनलोड झाले आहे.')}
              className="w-full bg-[#1B5E20] text-white py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1 shadow"
            >
              <FileText className="w-3.5 h-3.5" /> वेळापत्रक PDF डाऊनलोड करा
            </button>
          </div>
        );
        break;
      case 6:
        setModalTitle('६. हवामान अंदाज व फवारणी अलर्ट');
        setModalContent(
          <div className="space-y-3 text-sm">
            <div className="bg-sky-50 border border-sky-200 p-3 rounded-xl">
              <div className="flex items-center gap-2 text-sky-900 font-bold mb-1">
                <CloudSun className="w-5 h-5 text-amber-500" /> हवामान फवारणी शिफारस:
              </div>
              <p className="text-xs text-slate-700">उद्या दुपारनंतर नाशिक, बारामती भागात ढगाळ व पावसाचे वातावरण राहील. फवारणी करताना <strong>स्टिकर (Silwet Gold)</strong> अवश्य वापरा किंवा फवारणी सकाळी ८ ते १० दरम्यान पूर्ण करा.</p>
            </div>
          </div>
        );
        break;
      case 7:
        setModalTitle('७. बोलून विचारा (Voice Search)');
        setModalContent(
          <div className="space-y-4 text-center py-2">
            <div className={`w-16 h-16 mx-auto rounded-full flex items-center justify-center cursor-pointer transition-all ${
              voiceQueryActive ? 'bg-red-600 text-white animate-ping' : 'bg-amber-400 text-slate-950 shadow-lg'
            }`}
            onClick={() => {
              setVoiceQueryActive(true);
              speakMarathi('बोला शेतकरी मित्रा, तुमच्या पिकाला कोणता त्रास होत आहे?');
              setTimeout(() => setVoiceQueryActive(false), 3000);
            }}
            >
              <Mic className="w-8 h-8" />
            </div>
            <p className="text-xs font-bold text-slate-800">
              माईकवर दाबा आणि मराठीत बोला <br />
              <span className="text-emerald-700 text-[11px]">उदा: "माझ्या उसाची पाने तांबडी पडली आहेत काय करू?"</span>
            </p>
          </div>
        );
        break;
      case 8:
        setModalTitle('८. अधिकृत कृषी सेवा केंद्र (बारामती / इंदापूर / नाशिक)');
        setModalContent(
          <div className="space-y-2 text-xs">
            <div className="p-2.5 bg-slate-50 border rounded-xl">
              <div className="font-bold text-slate-900">जय किसान कृषी सेवा केंद्र, इंदापूर</div>
              <div className="text-slate-600">संपर्क: ९८२२०१४००० (ओरिजिनल औषधे हमी)</div>
            </div>
            <div className="p-2.5 bg-slate-50 border rounded-xl">
              <div className="font-bold text-slate-900">शेतकरी अ‍ॅग्रो एजन्सी, बारामती मार्केट यार्ड</div>
              <div className="text-slate-600">संपर्क: ९४२२०५६००० (१०% शेतकरी सवलत)</div>
            </div>
            <div className="p-2.5 bg-slate-50 border rounded-xl">
              <div className="font-bold text-slate-900">सह्याद्री कृषी केंद्र, पिंपळगाव नाशिक</div>
              <div className="text-slate-600">संपर्क: ०२५३-२४००५५ (द्राक्ष औषधे उपलब्ध)</div>
            </div>
          </div>
        );
        break;
      case 9:
        setModalTitle('९. माझा दवाखाना (तपासणी इतिहास)');
        setModalContent(
          <div className="space-y-2 text-xs">
            <p className="text-slate-600">तुमच्या मागील रोग स्कॅन व औषधोपचारांची नोंद:</p>
            {historyItems.map((item, idx) => (
              <div key={idx} className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between">
                <div>
                  <div className="font-bold text-emerald-950">{item.crop} - {item.disease}</div>
                  <div className="text-[10px] text-slate-500">{item.date}</div>
                </div>
                <span className="bg-emerald-700 text-white font-bold px-2 py-0.5 rounded text-[10px]">{item.status}</span>
              </div>
            ))}
          </div>
        );
        break;
      default:
        break;
    }
    setActiveModal(pointNumber.toString());
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Call Alert Notification */}
      {callAlert && (
        <div className="fixed top-16 left-3 right-3 z-50 bg-slate-950 text-amber-300 p-3 rounded-2xl shadow-2xl border-2 border-[#FFC107] text-xs font-bold animate-bounce flex items-center justify-between">
          <span>{callAlert}</span>
          <button onClick={() => setCallAlert(null)} className="text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main Hero Header Banner */}
      <div className="bg-gradient-to-br from-[#1B5E20] to-emerald-900 text-white p-4 rounded-2xl shadow-sm relative overflow-hidden">
        <div className="flex items-center justify-between mb-1.5">
          <span className="bg-white/20 text-white text-[11px] font-bold px-2.5 py-0.5 rounded-full backdrop-blur-sm border border-white/10">
            🌱 पीक रोग निदान
          </span>
          <span className="text-[11px] text-emerald-100 flex items-center gap-1 font-semibold">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-300" /> अचूक एआय विश्लेषण
          </span>
        </div>
        <h2 className="text-base font-black text-white leading-tight">
          पानाचा फोटो काढा — क्षणात रोग ओळखा!
        </h2>
        <p className="text-xs text-emerald-100/90 mt-1">
          बुरशी, कीड व खतांची कमतरता तपासा आणि तात्काळ औषध उपाय मिळवा.
        </p>
      </div>

      {/* Big Camera Box - Clean White Card with Soft Drop Shadow */}
      <div 
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        className={`bg-white p-4 rounded-2xl shadow-sm border border-slate-200/80 transition-all relative ${
          isDragOver ? 'border-emerald-600 bg-emerald-50/40' : ''
        }`}
      >
        <div className="flex flex-col items-center justify-center text-center">
          {previewImage ? (
            <div className="w-full relative rounded-2xl overflow-hidden mb-3 border border-slate-200">
              <img src={previewImage} alt="Crop Leaf" className="w-full h-48 object-cover" />
              {isScanning && (
                <div className="absolute inset-0 bg-emerald-950/70 flex flex-col items-center justify-center text-white p-4">
                  <Sparkles className="w-8 h-8 text-emerald-300 animate-spin mb-2" />
                  <span className="text-xs font-bold text-white">एआय स्कॅनिंग सुरू आहे...</span>
                </div>
              )}
            </div>
          ) : (
            /* Big Central Clickable Camera Button to open Camera / Gallery / Storage */
            <label className="w-full py-6 px-4 bg-slate-50 hover:bg-emerald-50/50 rounded-2xl mb-3 border border-slate-200/80 flex flex-col items-center justify-center cursor-pointer transition-all active:scale-[0.99] group">
              <div className="w-16 h-16 rounded-2xl bg-[#1B5E20] text-white flex items-center justify-center mb-3 shadow-md group-hover:scale-105 transition-transform">
                <Camera className="w-8 h-8" />
              </div>
              <span className="text-sm font-black text-slate-800">
                पानाचा फोटो काढा किंवा गॅलरीतून निवडा
              </span>
              <span className="text-xs text-slate-500 mt-1">
                फोटो निवडण्यासाठी येथे स्पर्श करा
              </span>
              <input 
                type="file" 
                accept="image/*" 
                onChange={(e) => handleFileUpload(e, 'गॅलरी')} 
                className="hidden" 
              />
            </label>
          )}

          {/* Preset Leaf Selector */}
          <div className="w-full mb-3">
            <span className="text-xs font-bold text-slate-700 block text-left mb-2">
              नमुना आजारी पाने निवडून त्वरित तपासा:
            </span>
            <div className="grid grid-cols-4 gap-2">
              {DISEASES_DATABASE.map((d) => (
                <button
                  key={d.id}
                  onClick={() => handleSelectPreset(d)}
                  className={`p-2 rounded-xl text-center text-xs font-bold transition-all border ${
                    selectedDisease.id === d.id
                      ? 'bg-[#1B5E20] text-white border-[#1B5E20] shadow-sm'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-emerald-50'
                  }`}
                >
                  <span className="text-lg block mb-0.5">{d.imagePlaceholder}</span>
                  <span className="line-clamp-1 text-[11px]">{d.cropMr}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Show "रोग ओळखा AI" button only after a photo is selected */}
          {previewImage && (
            <div className="w-full flex items-center gap-2">
              <label className="cursor-pointer bg-slate-100 hover:bg-slate-200 text-slate-800 py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border border-slate-300 transition-all">
                <Upload className="w-4 h-4 text-emerald-800" />
                <span>दुसरा फोटो निवडा</span>
                <input 
                  type="file" 
                  accept="image/*" 
                  onChange={(e) => handleFileUpload(e, 'गॅलरी')} 
                  className="hidden" 
                />
              </label>

              <button
                onClick={() => runScanAnimation(selectedDisease)}
                disabled={isScanning}
                className="flex-1 bg-[#1B5E20] hover:bg-emerald-900 text-white py-2.5 px-4 rounded-xl text-xs font-black flex items-center justify-center gap-2 shadow-sm active:scale-95 transition-all"
              >
                <Search className="w-4 h-4 text-emerald-200" />
                <span>{isScanning ? 'स्कॅनिंग होत आहे...' : 'रोग ओळखा AI'}</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Disease Diagnosis Result Card */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200/80 relative overflow-hidden">
        <div className="flex justify-between items-start mb-3">
          <div className="flex items-start gap-3">
            <span className="text-3xl p-2 bg-emerald-50 rounded-xl border border-emerald-100">
              {selectedDisease.imagePlaceholder}
            </span>
            <div>
              <span className="text-[11px] font-bold text-emerald-800 uppercase tracking-wide">
                {selectedDisease.cropMr}
              </span>
              <h3 className="text-base font-black text-slate-900 leading-tight">
                {selectedDisease.nameMr}
              </h3>
              <span className="text-xs text-slate-500 font-medium">
                {selectedDisease.nameEn}
              </span>
            </div>
          </div>

          <span className="bg-emerald-50 text-emerald-800 border border-emerald-200 px-2.5 py-1 text-[11px] font-bold rounded-lg flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
            निदान पूर्ण
          </span>
        </div>

        {/* 3 Calm Badges: Season, Severity, Cost */}
        <div className="grid grid-cols-3 gap-2 mb-3 text-center">
          <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
            <span className="text-[10px] text-slate-500 block font-medium">हंगाम</span>
            <span className="text-xs font-bold text-slate-800">{selectedDisease.seasonMr}</span>
          </div>

          <div className="bg-amber-50/70 p-2 rounded-xl border border-amber-100">
            <span className="text-[10px] text-amber-800 block font-medium">तीव्रता</span>
            <span className="text-xs font-bold text-amber-900">{selectedDisease.severityLabel}</span>
          </div>

          <div className="bg-emerald-50/70 p-2 rounded-xl border border-emerald-100">
            <span className="text-[10px] text-emerald-800 block font-medium">अंदाजे खर्च</span>
            <span className="text-xs font-black text-emerald-900">{selectedDisease.kharchMr}</span>
          </div>
        </div>

        {/* Upchar & Prescription */}
        <div className="bg-emerald-50/60 p-3.5 rounded-xl border border-emerald-200/80 mb-3">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-black text-emerald-950 flex items-center gap-1.5">
              💊 तात्काळ फवारणी उपाय:
            </span>
            <button
              onClick={handleVoiceListenResult}
              className="text-xs bg-white text-emerald-900 border border-emerald-300 hover:bg-emerald-100 px-2.5 py-1 rounded-lg font-bold flex items-center gap-1 shadow-sm transition-all"
            >
              <Volume2 className="w-3.5 h-3.5 text-emerald-700" /> माहिती ऐका
            </button>
          </div>
          <p className="text-xs text-slate-800 leading-relaxed font-semibold">
            {selectedDisease.upcharMr}
          </p>
        </div>

        {/* Medicines Table */}
        <div className="space-y-2 mb-4">
          <span className="text-xs font-bold text-slate-700 block">प्रमाणित औषधे व डोस:</span>
          {selectedDisease.medicines.map((med, idx) => (
            <div key={idx} className="flex items-center justify-between bg-slate-50 p-2.5 rounded-xl border border-slate-200/80 text-xs">
              <div>
                <span className="font-bold text-slate-900 block">{med.brand}</span>
                <span className="text-[11px] text-slate-500">{med.company} • {med.timing}</span>
              </div>
              <span className="font-bold text-emerald-900 bg-emerald-100/80 border border-emerald-200 px-2 py-0.5 rounded-lg text-xs">
                {med.dose}
              </span>
            </div>
          ))}
        </div>

        {/* 2 Action Buttons */}
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={handleOpenAushadhDukan}
            className="bg-[#1B5E20] hover:bg-emerald-900 text-white font-bold py-2.5 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-sm active:scale-95 transition-all"
          >
            <Store className="w-4 h-4 text-emerald-200" />
            <span>🛒 अधिकृत औषध दुकान</span>
          </button>

          <button
            onClick={() => handleDoctorCall(DOCTOR_EXPERTS[0])}
            className="bg-emerald-800 hover:bg-emerald-900 text-white font-bold py-2.5 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-sm active:scale-95 transition-all"
          >
            <PhoneCall className="w-4 h-4 text-emerald-200" />
            <span>📞 मोफत डॉक्टर सल्ला</span>
          </button>
        </div>
      </div>

      {/* 9 Points Feature Grid */}
      <div className="bg-white p-3.5 rounded-2xl shadow-md border border-slate-200">
        <div className="flex items-center justify-between mb-2.5">
          <h3 className="font-black text-slate-900 text-xs flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#1B5E20]" />
            ९ मुद्दे रोग डॉक्टर सुविधा (9 Points System):
          </h3>
          <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
            क्लिक करा व वापरा
          </span>
        </div>

        <div className="grid grid-cols-3 gap-2">
          {[
            { num: 1, icon: Camera, title: 'Photo Scan AI', sub: '९५% अचूकता' },
            { num: 2, icon: AlertTriangle, title: 'औषध माहिती', sub: 'Bayer, UPL ml/L' },
            { num: 3, icon: PhoneCall, title: '६ डॉक्टर थेट फोन', sub: 'सकाळी ७ ते ८' },
            { num: 4, icon: Video, title: 'व्हिडिओ सल्ला', sub: '२ मिनिट मराठी' },
            { num: 5, icon: FileText, title: 'फवारणी वेळापत्रक', sub: '१-३५० दिवस PDF' },
            { num: 6, icon: CloudSun, title: 'हवामान अलर्ट', sub: 'फवारणी वेळ' },
            { num: 7, icon: Mic, title: 'बोलून विचारा', sub: 'Voice Search' },
            { num: 8, icon: Store, title: 'कृषी दुकान नंबर', sub: 'बारामती/इंदापूर' },
            { num: 9, icon: History, title: 'माझा दवाखाना', sub: 'तपासणी इतिहास' },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.num}
                onClick={() => openGridFeature(item.num)}
                className="p-2 bg-gradient-to-b from-slate-50 to-emerald-50/50 hover:to-emerald-100/70 rounded-xl border border-slate-200 hover:border-emerald-500 flex flex-col items-center justify-center text-center transition-all hover:scale-[1.03] active:scale-95 shadow-sm"
              >
                <div className="w-7 h-7 rounded-lg bg-[#1B5E20] text-amber-300 flex items-center justify-center mb-1 text-xs font-black shadow-sm">
                  <Icon className="w-3.5 h-3.5" />
                </div>
                <span className="text-[10px] font-bold text-slate-900 leading-tight block">
                  {item.title}
                </span>
                <span className="text-[8px] text-slate-500 leading-none mt-0.5">
                  {item.sub}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 6 MSc / PhD Expert Doctor Cards */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <h3 className="font-black text-slate-900 text-xs flex items-center gap-1.5">
            👨‍🔬 ६ कृषी तज्ज्ञ व डॉक्टर्स (MSC/PhD Experts):
          </h3>
          <span className="text-[10px] text-emerald-800 font-bold">
            विनामूल्य सल्ला
          </span>
        </div>

        <div className="grid grid-cols-1 gap-2.5">
          {DOCTOR_EXPERTS.map((doc) => (
            <div
              key={doc.id}
              className="bg-white p-3 rounded-2xl shadow-md border border-slate-200 hover:border-emerald-500 transition-all"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-start gap-2.5">
                  <span className="text-2xl p-2 bg-emerald-50 rounded-xl border border-emerald-200">
                    {doc.avatar}
                  </span>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h4 className="font-black text-xs text-slate-950">{doc.name}</h4>
                      <span className="text-[9px] bg-amber-100 text-amber-900 font-bold px-1.5 rounded">
                        ★ {doc.rating}
                      </span>
                    </div>
                    <p className="text-[10px] text-emerald-800 font-bold">{doc.specialtyMr}</p>
                    <p className="text-[9px] text-slate-500">{doc.degree} • {doc.locationMr}</p>
                    <p className="text-[9px] text-slate-600 font-semibold mt-0.5">{doc.experience}</p>
                  </div>
                </div>

                <div className="flex flex-col gap-1 shrink-0">
                  <button
                    onClick={() => handleDoctorCall(doc)}
                    className="bg-[#1B5E20] hover:bg-emerald-800 text-amber-300 font-black px-2.5 py-1.5 rounded-lg text-[10px] flex items-center justify-center gap-1 shadow active:scale-95"
                  >
                    <PhoneCall className="w-3 h-3 text-amber-400" />
                    <span>कॉल करा</span>
                  </button>
                  <button
                    onClick={() => {
                      setCallAlert(`📹 ${doc.name} यांच्याशी व्हिडिओ सल्लामसलत बुक झाली आहे!`);
                      speakMarathi(`${doc.name} यांच्याशी व्हिडिओ कॉल शेड्यूल झाला आहे.`);
                    }}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold px-2 py-1 rounded-lg text-[9px] flex items-center justify-center gap-0.5"
                  >
                    <Video className="w-2.5 h-2.5 text-emerald-700" />
                    व्हिडिओ
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Interactive Feature Modal */}
      {activeModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl border-2 border-[#1B5E20] overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="bg-[#1B5E20] text-white p-3 flex items-center justify-between">
              <h3 className="font-bold text-xs text-amber-300">{modalTitle}</h3>
              <button
                onClick={() => setActiveModal(null)}
                className="text-white hover:text-amber-300 p-1 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4">{modalContent}</div>
            <div className="bg-slate-50 p-2.5 text-right border-t border-slate-200">
              <button
                onClick={() => setActiveModal(null)}
                className="bg-slate-800 text-white text-xs px-4 py-1.5 rounded-lg font-bold"
              >
                बंद करा
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
