package com.mahaagri.kranti.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mahaagri.kranti.data.models.Language
import com.mahaagri.kranti.data.models.TabType
import com.mahaagri.kranti.ui.theme.*

@Composable
fun SustainableScreen(
    lang: Language,
    onNavigate: (TabType) -> Unit
) {
    var pumpHp by remember { mutableStateOf(5) }
    var dripAcres by remember { mutableStateOf(3) }

    // Calculations
    val pumpTotalCost = when (pumpHp) {
        3 -> 165000
        5 -> 235000
        else -> 320000
    }
    val farmerShare = (pumpTotalCost * 0.10).toInt()
    val govtSubsidy = pumpTotalCost - farmerShare

    val waterSavedLitres = dripAcres * 450000
    val powerSavedUnits = dripAcres * 1200
    val carbonCreditEarned = dripAcres * 2400

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
    ) {
        // Hero Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Teal900)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(Teal900, Green900, Color(0xFF064E3B))
                            )
                        )
                        .padding(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Amber500)
                            .padding(horizontal = 10.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = if (lang == Language.MARATHI) "🌱 हरित व शाश्वत कृषी केंद्र" else "🌱 Sustainable Agri Hub",
                            color = Slate900,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = if (lang == Language.MARATHI) "सौर ऊर्जा, ठिबक पाणी बचत व सेंद्रिय शेती" else "Solar Power, Drip & Organic Farming",
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black
                    )

                    Text(
                        text = if (lang == Language.MARATHI)
                            "शाश्वत शेती पद्धतीचा अवलंब करून ९०% अनुदानावर सौर पंप मिळवा व कार्बन क्रेडिट्स द्वारे अधिक उत्पन्न कमवा."
                        else
                            "Adopt sustainable farming with 90% solar pump subsidies & monetize carbon credits.",
                        color = Teal100,
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }

        // PM-KUSUM 90% Solar Pump Calculator
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "☀️", fontSize = 20.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (lang == Language.MARATHI) "पीएम-कुसुम सौर पंप (९०% अनुदान)" else "PM-KUSUM Solar Pump (90% Subsidy)",
                                color = Slate900,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    Text(
                        text = if (lang == Language.MARATHI) "पंप क्षमता निवडा (HP):" else "Select Pump HP:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Slate600
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(3, 5, 7).forEach { hp ->
                            val isSelected = pumpHp == hp
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isSelected) Green800 else Slate100)
                                    .clickable { pumpHp = hp }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$hp HP पंप",
                                    color = if (isSelected) Color.White else Slate800,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }

                    // Calculation breakdown
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Amber100.copy(alpha = 0.4f))
                            .padding(12.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "एकूण सौर पंप किंमत:", fontSize = 11.sp, color = Slate700)
                                Text(text = "₹${pumpTotalCost}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "९०% सरकारी अनुदान:", fontSize = 11.sp, color = Green700, fontWeight = FontWeight.Bold)
                                Text(text = "- ₹${govtSubsidy}", fontSize = 11.sp, color = Green700, fontWeight = FontWeight.Bold)
                            }
                            HorizontalDivider(color = Slate200)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "शेतकऱ्याला फक्त भरायचे:", fontSize = 12.sp, fontWeight = FontWeight.Black, color = Slate900)
                                Text(text = "₹${farmerShare} (१०%)", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Green800)
                            }
                        }
                    }

                    Button(
                        onClick = { onNavigate(TabType.YOJANA) },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Green800),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (lang == Language.MARATHI) "योजनेसाठी अर्ज कसा करावा? पहा →" else "Apply for Solar Scheme →",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Drip Irrigation & Water Saving Impact
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "💧", fontSize = 20.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (lang == Language.MARATHI) "ठिबक सिंचन पाणी व वीज बचत" else "Drip Irrigation Savings",
                            color = Slate900,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Text(
                        text = "आपले शेती क्षेत्र: $dripAcres एकर",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Slate700
                    )

                    Slider(
                        value = dripAcres.toFloat(),
                        onValueChange = { dripAcres = it.toInt() },
                        valueRange = 1f..15f,
                        steps = 14,
                        colors = SliderDefaults.colors(thumbColor = Green800, activeTrackColor = Green800)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Blue100.copy(alpha = 0.5f))
                                .padding(10.dp)
                        ) {
                            Column {
                                Text(text = "💧 पाणी बचत", fontSize = 10.sp, color = Blue700, fontWeight = FontWeight.Bold)
                                Text(text = "$waterSavedLitres लिटर", fontSize = 12.sp, fontWeight = FontWeight.Black, color = Slate900)
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Amber100.copy(alpha = 0.5f))
                                .padding(10.dp)
                        ) {
                            Column {
                                Text(text = "⚡ वीज बचत", fontSize = 10.sp, color = Amber700, fontWeight = FontWeight.Bold)
                                Text(text = "$powerSavedUnits युनिट्स", fontSize = 12.sp, fontWeight = FontWeight.Black, color = Slate900)
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Green100)
                                .padding(10.dp)
                        ) {
                            Column {
                                Text(text = "💰 कार्बन उत्पन्न", fontSize = 10.sp, color = Green800, fontWeight = FontWeight.Bold)
                                Text(text = "₹$carbonCreditEarned", fontSize = 12.sp, fontWeight = FontWeight.Black, color = Green900)
                            }
                        }
                    }
                }
            }
        }

        // Jivamrut Recipe
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Green50)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "🍶 देशी गाय सेंद्रिय जीवामृत फॉर्म्युला (२०० लिटर)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        color = Green900
                    )
                    Text(
                        text = "• १० किलो देशी गाईचे शेण + १० लिटर गोमूत्र\n• २ किलो गूळ (केमिकल विरहित) + २ किलो डाळीचे पीठ (बेसन)\n• १ मूठ बांधावरची जिवंत माती\n• २०० लिटर पाण्यात ४८ तास सावलीत ढवळून आंबवणे.",
                        fontSize = 11.sp,
                        color = Slate800,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }
}
