import React, { useState } from 'react';
import { 
  Users, 
  PhoneCall, 
  MessageCircle, 
  MapPin, 
  PlusCircle, 
  CheckCircle2, 
  Search,
  Sparkles,
  Share2,
  X
} from 'lucide-react';
import { REGION_FARMERS } from '../data/agriData';
import { RegionFarmer } from '../types';
import { speakMarathi } from '../utils/speech';

export const Tab3MaharashtraConnect: React.FC = () => {
  const [selectedRegion, setSelectedRegion] = useState<'paschim' | 'vidarbha' | 'marathwada' | 'khandesh'>('paschim');
  const [searchQuery, setSearchQuery] = useState('');
  const [farmersList, setFarmersList] = useState<RegionFarmer[]>(REGION_FARMERS);
  const [showAddPostModal, setShowAddPostModal] = useState(false);
  const [contactAlert, setContactAlert] = useState<string | null>(null);

  // New Farmer post form
  const [newName, setNewName] = useState('');
  const [newTaluka, setNewTaluka] = useState('');
  const [newCrop, setNewCrop] = useState('');
  const [newAcres, setNewAcres] = useState('5');
  const [newPhone, setNewPhone] = useState('');

  const filteredFarmers = farmersList.filter((f) => {
    const matchesRegion = f.region === selectedRegion;
    const matchesQuery = searchQuery === '' || 
      f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.taluka.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.cropMr.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesRegion && matchesQuery;
  });

  const handleCallFarmer = (farmer: RegionFarmer) => {
    setContactAlert(`📞 ${farmer.name} (${farmer.taluka}) यांना थेट फोन लावला जात आहे: ${farmer.phone}`);
    speakMarathi(`${farmer.name} यांना कॉल लावला जात आहे.`);
    setTimeout(() => setContactAlert(null), 4000);
  };

  const handleWhatsAppFarmer = (farmer: RegionFarmer) => {
    setContactAlert(`💬 ${farmer.name} यांच्यासोबत WhatsApp शेतकरी ग्रुप चॅट उघडले आहे!`);
    speakMarathi(`${farmer.name} यांच्यासोबत व्हॉट्सअ‍ॅप जोडणी झाली आहे.`);
    setTimeout(() => setContactAlert(null), 4000);
  };

  const handleAddFarmerPost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newTaluka || !newCrop) return;

    const newFarmer: RegionFarmer = {
      id: `f_custom_${Date.now()}`,
      name: newName,
      taluka: newTaluka,
      district: selectedRegion === 'paschim' ? 'पुणे' : selectedRegion === 'vidarbha' ? 'नागपूर' : selectedRegion === 'marathwada' ? 'जालना' : 'जळगाव',
      region: selectedRegion,
      cropMr: newCrop,
      acres: parseFloat(newAcres) || 3,
      phone: newPhone || '९८२२००११२२',
      verified: true,
      avatar: '👨‍🌾',
      notes: 'नवीन शेतकरी नोंदणी - थेट संपर्कासाठी उपलब्ध.'
    };

    setFarmersList([newFarmer, ...farmersList]);
    setShowAddPostModal(false);
    setContactAlert(`✅ अभिनंदन! तुमची माहिती ${selectedRegion} शेतकरी नेटवर्कवर जोडली गेली आहे.`);
    speakMarathi(`तुमची नोंदणी यशस्वी झाली आहे.`);
    setNewName('');
    setNewTaluka('');
    setNewCrop('');
    setNewPhone('');
    setTimeout(() => setContactAlert(null), 4000);
  };

  const regions = [
    { id: 'paschim', titleMr: 'पश्चिम महाराष्ट्र', sub: 'पुणे, सांगली, कोल्हापूर, सोलापूर', emoji: '🍇' },
    { id: 'vidarbha', titleMr: 'विदर्भ', sub: 'नागपूर, अमरावती, वाशीम, यवतमाळ', emoji: '🍊' },
    { id: 'marathwada', titleMr: 'मराठवाडा', sub: 'संभाजीनगर, जालना, बीड, लातूर', emoji: '🌾' },
    { id: 'khandesh', titleMr: 'खान्देश', sub: 'जळगाव, धुळे, नंदुरबार', emoji: '🍌' },
  ];

  return (
    <div className="space-y-4 pb-20">
      {/* Contact alert */}
      {contactAlert && (
        <div className="fixed top-16 left-3 right-3 z-50 bg-slate-950 text-amber-300 p-3 rounded-2xl shadow-2xl border-2 border-[#FFC107] text-xs font-bold animate-bounce flex items-center justify-between">
          <span>{contactAlert}</span>
          <button onClick={() => setContactAlert(null)} className="text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-gradient-to-br from-[#1B5E20] via-emerald-800 to-slate-900 text-white p-3.5 rounded-2xl shadow-lg border border-emerald-500">
        <div className="flex items-center justify-between mb-1">
          <span className="bg-[#FFC107] text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
            🤝 महाराष्ट्र शेतकरी नेटवर्क
          </span>
          <span className="text-[10px] text-amber-300 font-bold">
            १२ लाख+ जोडलेले शेतकरी
          </span>
        </div>
        <h2 className="text-base font-black text-white leading-tight">
          आपल्या भागातील प्रगतशील शेतकऱ्यांशी थेट जोडा!
        </h2>
        <p className="text-[11px] text-emerald-100 mt-0.5">
          अनुभव शेअर करा, बियाणे देवाणघेवाण व एकत्रित गाडी बुकिंग करा
        </p>
      </div>

      {/* 4 Big Region Buttons */}
      <div className="grid grid-cols-2 gap-2">
        {regions.map((reg) => {
          const isSelected = selectedRegion === reg.id;
          return (
            <button
              key={reg.id}
              onClick={() => {
                setSelectedRegion(reg.id as any);
                speakMarathi(`${reg.titleMr} शेतकरी गट निवडला आहे.`);
              }}
              className={`p-3 rounded-2xl text-left transition-all relative overflow-hidden flex flex-col justify-between border ${
                isSelected
                  ? 'bg-gradient-to-br from-[#1B5E20] to-emerald-900 text-white border-[#FFC107] shadow-lg scale-[1.02]'
                  : 'bg-white text-slate-800 border-slate-200 hover:border-emerald-400'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xl">{reg.emoji}</span>
                {isSelected && (
                  <span className="bg-[#FFC107] text-slate-950 text-[9px] font-black px-1.5 py-0.5 rounded-full">
                    सक्रिय
                  </span>
                )}
              </div>
              <div>
                <h3 className={`text-xs font-black leading-tight ${isSelected ? 'text-amber-300' : 'text-slate-900'}`}>
                  {reg.titleMr}
                </h3>
                <span className={`text-[9px] block leading-tight ${isSelected ? 'text-emerald-200' : 'text-slate-500'}`}>
                  {reg.sub}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Search & Add Bar */}
      <div className="flex items-center gap-2">
        <div className="flex-1 relative">
          <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="तालुका, पीक किंवा नाव शोधा..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-2 bg-white rounded-xl text-xs border border-slate-300 focus:outline-none focus:ring-1 focus:ring-emerald-500"
          />
        </div>
        <button
          onClick={() => setShowAddPostModal(true)}
          className="bg-[#1B5E20] hover:bg-emerald-800 text-amber-300 text-xs font-black px-3 py-2 rounded-xl flex items-center gap-1 shadow shrink-0"
        >
          <PlusCircle className="w-3.5 h-3.5" />
          <span>+ माझी नोंदणी</span>
        </button>
      </div>

      {/* Farmers List */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <span className="text-xs font-black text-slate-800">
            {regions.find((r) => r.id === selectedRegion)?.titleMr} प्रगतशील शेतकरी:
          </span>
          <span className="text-[10px] text-slate-500 font-bold">
            {filteredFarmers.length} शेतकरी उपलब्ध
          </span>
        </div>

        {filteredFarmers.map((farmer) => (
          <div
            key={farmer.id}
            className="bg-white p-3 rounded-2xl shadow-md border border-slate-200 hover:border-emerald-500 transition-all"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-start gap-2.5">
                <span className="text-2xl p-2 bg-emerald-50 rounded-xl border border-emerald-200">
                  {farmer.avatar}
                </span>
                <div>
                  <div className="flex items-center gap-1">
                    <h4 className="font-black text-xs text-slate-950">{farmer.name}</h4>
                    {farmer.verified && (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 fill-emerald-100" />
                    )}
                  </div>
                  <div className="flex items-center gap-1 text-[10px] text-emerald-800 font-bold mt-0.5">
                    <MapPin className="w-3 h-3" />
                    <span>{farmer.taluka}, {farmer.district}</span>
                  </div>
                  <div className="text-[10px] text-slate-700 font-semibold mt-0.5">
                    पीक: <span className="font-bold text-amber-900">{farmer.cropMr}</span> • {farmer.acres} एकर
                  </div>
                </div>
              </div>

              <div className="flex flex-col gap-1 shrink-0">
                <button
                  onClick={() => handleCallFarmer(farmer)}
                  className="bg-[#1B5E20] hover:bg-emerald-800 text-amber-300 font-black px-2.5 py-1.5 rounded-lg text-[10px] flex items-center justify-center gap-1 shadow active:scale-95"
                >
                  <PhoneCall className="w-3 h-3 text-amber-400" />
                  <span>कॉल</span>
                </button>
                <button
                  onClick={() => handleWhatsAppFarmer(farmer)}
                  className="bg-emerald-100 hover:bg-emerald-200 text-emerald-950 font-bold px-2 py-1 rounded-lg text-[9px] flex items-center justify-center gap-0.5"
                >
                  <MessageCircle className="w-2.5 h-2.5 text-emerald-700" />
                  WhatsApp
                </button>
              </div>
            </div>

            <div className="mt-2 pt-2 border-t border-slate-100 text-[10px] text-slate-600 bg-slate-50/60 p-1.5 rounded-lg">
              💬 <span className="font-semibold text-slate-800">शेतकरी टीप:</span> "{farmer.notes}"
            </div>
          </div>
        ))}
      </div>

      {/* Add Farmer Modal */}
      {showAddPostModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl border-2 border-emerald-600 overflow-hidden">
            <div className="bg-[#1B5E20] text-white p-3 flex items-center justify-between">
              <h3 className="font-bold text-xs text-amber-300">+ शेतकरी नेटवर्क मध्ये सामील व्हा</h3>
              <button onClick={() => setShowAddPostModal(false)} className="text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleAddFarmerPost} className="p-4 space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">आपले पूर्ण नाव:</label>
                <input
                  type="text"
                  required
                  placeholder="उदा. सचिन दत्तात्रय पाटील"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full p-2 border rounded-lg focus:ring-1 focus:ring-emerald-500 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">तालुका / गाव:</label>
                  <input
                    type="text"
                    required
                    placeholder="उदा. बारामती"
                    value={newTaluka}
                    onChange={(e) => setNewTaluka(e.target.value)}
                    className="w-full p-2 border rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">क्षेत्र (एकर):</label>
                  <input
                    type="number"
                    value={newAcres}
                    onChange={(e) => setNewAcres(e.target.value)}
                    className="w-full p-2 border rounded-lg text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">मुख्य पिके (उदा. केळी G9 / ऊस / द्राक्षे):</label>
                <input
                  type="text"
                  required
                  placeholder="उदा. केळी G9 निर्यातक्षम"
                  value={newCrop}
                  onChange={(e) => setNewCrop(e.target.value)}
                  className="w-full p-2 border rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">मोबाईल नंबर:</label>
                <input
                  type="tel"
                  placeholder="९८xxxxxxxx"
                  value={newPhone}
                  onChange={(e) => setNewPhone(e.target.value)}
                  className="w-full p-2 border rounded-lg text-xs"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-[#1B5E20] hover:bg-emerald-800 text-white font-black py-2.5 rounded-xl text-xs shadow-md mt-2"
              >
                माहिती जोडा (Join Network)
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
