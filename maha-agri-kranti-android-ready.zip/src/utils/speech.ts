// Utility for Marathi & English Text-to-Speech playback

let currentUtterance: SpeechSynthesisUtterance | null = null;

export const speakText = (text: string, lang: 'mr' | 'en' = 'mr', onEnd?: () => void, onError?: () => void): boolean => {
  if (!('speechSynthesis' in window)) {
    console.warn('Speech synthesis not supported in this browser.');
    return false;
  }

  // Cancel any active speech
  window.speechSynthesis.cancel();

  // Clean text of non-speakable symbols
  const cleanText = text
    .replace(/[#*_~`]/g, '')
    .replace(/₹/g, lang === 'mr' ? ' रुपये ' : ' Rupees ')
    .replace(/kg/gi, lang === 'mr' ? ' किलो ' : ' Kilogram ')
    .replace(/Ton/gi, lang === 'mr' ? ' टन ' : ' Ton ')
    .replace(/Acre/gi, lang === 'mr' ? ' एकर ' : ' Acre ')
    .replace(/Lakh/gi, lang === 'mr' ? ' लाख ' : ' Lakh ')
    .replace(/Rs/gi, lang === 'mr' ? ' रुपये ' : ' Rupees ');

  const utterance = new SpeechSynthesisUtterance(cleanText);
  utterance.rate = lang === 'mr' ? 0.9 : 0.95;
  utterance.pitch = 1.0;

  const voices = window.speechSynthesis.getVoices();

  if (lang === 'en') {
    const enVoice = voices.find(v => v.lang.includes('en-IN')) || voices.find(v => v.lang.includes('en-GB')) || voices.find(v => v.lang.includes('en-US')) || voices.find(v => v.lang.startsWith('en'));
    if (enVoice) utterance.voice = enVoice;
    utterance.lang = 'en-IN';
  } else {
    const marathiVoice = voices.find(v => v.lang.includes('mr') || v.lang.includes('MR'));
    const hindiVoice = voices.find(v => v.lang.includes('hi') || v.lang.includes('HI'));
    const indianVoice = voices.find(v => v.lang.includes('en-IN') || v.lang.includes('IN'));

    if (marathiVoice) {
      utterance.voice = marathiVoice;
      utterance.lang = 'mr-IN';
    } else if (hindiVoice) {
      utterance.voice = hindiVoice;
      utterance.lang = 'hi-IN';
    } else if (indianVoice) {
      utterance.voice = indianVoice;
      utterance.lang = 'en-IN';
    } else {
      utterance.lang = 'mr-IN';
    }
  }

  utterance.onend = () => {
    currentUtterance = null;
    if (onEnd) onEnd();
  };

  utterance.onerror = (e) => {
    console.error('Speech synthesis error:', e);
    currentUtterance = null;
    if (onError) onError();
  };

  currentUtterance = utterance;
  window.speechSynthesis.speak(utterance);
  return true;
};

export const speakMarathi = (text: string, onEnd?: () => void, onError?: () => void): boolean => {
  return speakText(text, 'mr', onEnd, onError);
};

export const stopSpeech = () => {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
    currentUtterance = null;
  }
};

export const isSpeaking = (): boolean => {
  if (!('speechSynthesis' in window)) return false;
  return window.speechSynthesis.speaking;
};

