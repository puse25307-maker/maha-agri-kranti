import React, { useState } from 'react';
import { 
  Award, 
  Search, 
  MapPin, 
  PhoneCall, 
  MessageCircle, 
  Volume2, 
  Sparkles, 
  PlusCircle, 
  X, 
  CheckCircle2, 
  ShoppingBag, 
  Leaf, 
  TrendingUp, 
  Star,
  Quote,
  ShieldCheck,
  ChevronRight
} from 'lucide-react';
import { PROGRESSIVE_FARMERS_DATA } from '../data/agriData';
import { ProgressiveFarmerStory, Language } from '../types';
import { speakText } from '../utils/speech';

interface TabProgressiveFarmersProps {
  lang: Language;
}

export const TabProgressiveFarmers: React.FC<TabProgressiveFarmersProps> = ({ lang }) => {
  const [farmersList, setFarmersList] = useState<ProgressiveFarmerStory[]>(PROGRESSIVE_FARMERS_DATA);
  const [selectedRegion, setSelectedRegion] = useState<string>('all');
  const [selectedCrop, setSelectedCrop] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddStoryModal, setShowAddStoryModal] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);

  // New Farmer Story Form
  const [formData, setFormData] = useState({
    farmerName: '',
    village: '',
    taluka: '',
    district: 'पुणे',
    region: 'paschim' as ProgressiveFarmerStory['region'],
    mainCrop: '',
    variety: '',
    acres: '5',
    cropYieldRecord: '',
    netProfitPerAcre: '',
    farmingTechnique: '',
    produceItem: '',
    produceQty: '',
    producePrice: '',
    phone: '',
    storyQuote: ''
  });

  const regions = [
    { id: 'all', labelMr: '🚩 सर्व महाराष्ट्र', labelEn: '🚩 All Maharashtra' },
    { id: 'paschim', labelMr: '🍇 पश्चिम महाराष्ट्र', labelEn: '🍇 Western MH' },
    { id: 'khandesh', labelMr: '🍌 खान्देश', labelEn: '🍌 Khandesh' },
    { id: 'vidarbha', labelMr: '🌱 विदर्भ', labelEn: '🌱 Vidarbha' },
    { id: 'marathwada', labelMr: '🍈 मराठवाडा', labelEn: '🍈 Marathwada' },
  ];

  const cropFilters = [
    { id: 'all', labelMr: 'सर्व पिके', labelEn: 'All Crops' },
    { id: 'ऊस', labelMr: '🎋 ऊस (Sugarcane)', labelEn: '🎋 Sugarcane' },
    { id: 'द्राक्ष', labelMr: '🍇 द्राक्ष (Grapes)', labelEn: '🍇 Grapes' },
    { id: 'केळी', labelMr: '🍌 केळी (Banana)', labelEn: '🍌 Banana' },
    { id: 'सोयाबीन', labelMr: '🌱 सोयाबीन (Soybean)', labelEn: '🌱 Soybean' },
    { id: 'डाळिंब', labelMr: '🍎 डाळिंब (Pomegranate)', labelEn: '🍎 Pomegranate' },
    { id: 'कांदा', labelMr: '🧅 कांदा (Onion)', labelEn: '🧅 Onion' },
  ];

  const filteredFarmers = farmersList.filter((f) => {
    const matchesRegion = selectedRegion === 'all' || f.region === selectedRegion;
    const matchesCrop = selectedCrop === 'all' || 
      f.mainCropMr.toLowerCase().includes(selectedCrop.toLowerCase()) ||
      f.mainCropEn.toLowerCase().includes(selectedCrop.toLowerCase());

    const query = searchQuery.toLowerCase().trim();
    const matchesQuery = query === '' ||
      f.farmerName.toLowerCase().includes(query) ||
      f.mainCropMr.toLowerCase().includes(query) ||
      f.taluka.toLowerCase().includes(query) ||
      f.district.toLowerCase().includes(query) ||
      f.cropYieldRecordMr.toLowerCase().includes(query);

    return matchesRegion && matchesCrop && matchesQuery;
  });

  const handleCall = (f: ProgressiveFarmerStory) => {
    const text = lang === 'mr'
      ? `📞 प्रगतशील शेतकरी ${f.farmerName} (${f.taluka}, ${f.district}) यांना थेट फोन लावला जात आहे: ${f.phone}`
      : `📞 Calling progressive farmer ${f.farmerName}: ${f.phone}`;
    setNotification(text);
    speakText(lang === 'mr' ? `${f.farmerName} यांच्याशी संपर्क सुरू आहे.` : `Connecting to ${f.farmerName}`, lang);
    setTimeout(() => setNotification(null), 4000);
  };

  const handleWhatsApp = (f: ProgressiveFarmerStory) => {
    const text = lang === 'mr'
      ? `💬 ${f.farmerName} यांच्यासोबत WhatsApp वर शेती सल्ला व पीक खरेदी चॅट उघडले आहे!`
      : `💬 Opening WhatsApp chat with ${f.farmerName} for crop consultation & order!`;
    setNotification(text);
    speakText(lang === 'mr' ? `व्हॉट्सअ‍ॅप सल्ला व खरेदी सुरू झाली आहे.` : `WhatsApp consultation opened.`, lang);
    setTimeout(() => setNotification(null), 4000);
  };

  const handleSpeakStory = (f: ProgressiveFarmerStory) => {
    const speechMr = `प्रगतशील शेतकरी ${f.farmerName}, गाव ${f.village}, जिल्हा ${f.district}. ` +
      `मुख्य पीक: ${f.mainCropMr}. विक्रमी यश: ${f.cropYieldRecordMr}. ` +
      `नफा: ${f.netProfitPerAcreMr}. ` +
      `यशस्वी शेतीची सूत्रे: ${f.bestFarmingTechniquesMr.join(', ')}. ` +
      `शेतकऱ्यांचा संदेश: "${f.storyQuoteMr}"`;

    const speechEn = `Progressive farmer ${f.farmerName} from ${f.district}. ` +
      `Main crop: ${f.mainCropEn}. Record achievement: ${f.cropYieldRecordEn}. ` +
      `Net profit: ${f.netProfitPerAcreEn}. ` +
      `Key techniques: ${f.bestFarmingTechniquesEn.join(', ')}. ` +
      `Message: "${f.storyQuoteEn}"`;

    speakText(lang === 'mr' ? speechMr : speechEn, lang);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.farmerName || !formData.mainCrop || !formData.phone) return;

    const newStory: ProgressiveFarmerStory = {
      id: `pf_custom_${Date.now()}`,
      farmerName: formData.farmerName,
      village: formData.village || 'गाव',
      taluka: formData.taluka || 'तालुका',
      district: formData.district,
      region: formData.region,
      mainCropMr: formData.mainCrop,
      mainCropEn: formData.mainCrop,
      variety: formData.variety || 'उत्तम वाण',
      acres: parseFloat(formData.acres) || 5,
      cropYieldRecordMr: formData.cropYieldRecord || 'उत्कृष्ट दर्जेदार उत्पादन',
      cropYieldRecordEn: formData.cropYieldRecord || 'High Yield Record',
      netProfitPerAcreMr: formData.netProfitPerAcre || 'चांगला परतावा',
      netProfitPerAcreEn: formData.netProfitPerAcre || 'High Profit',
      bestFarmingTechniquesMr: formData.farmingTechnique 
        ? [formData.farmingTechnique, 'ठिबक सिंचन व सेंद्रिय खते']
        : ['ठिबक सिंचन व सेंद्रिय जिवाणू', 'योग्य अन्नद्रव्य व्यवस्थापन'],
      bestFarmingTechniquesEn: ['Drip irrigation & organic nutrients', 'Scientific management'],
      produceForSale: formData.produceItem ? [
        {
          itemMr: formData.produceItem,
          itemEn: formData.produceItem,
          quantityAvailable: formData.produceQty || 'उपलब्ध',
          priceRate: formData.producePrice || 'बाजारभावानुसार',
          qualityGrade: 'थेट शेतातून दर्जेदार'
        }
      ] : [],
      phone: formData.phone,
      whatsapp: formData.phone,
      avatarEmoji: '🌱',
      experienceYears: 10,
      awardsMr: 'प्रगतशील शेतकरी सन्मान',
      awardsEn: 'Progressive Farmer Recognition',
      storyQuoteMr: formData.storyQuote || 'सातत्य आणि नियोजन हीच शेतीतील यशाची गुरुकिल्ली आहे.',
      storyQuoteEn: formData.storyQuote || 'Consistency and planning are the keys to successful farming.',
      verified: true
    };

    setFarmersList([newStory, ...farmersList]);
    setShowAddStoryModal(false);
    const msg = lang === 'mr'
      ? `✅ अभिनंदन! तुमची शेती यशकथा व पीक माहिती यशस्वीरित्या जोडली गेली आहे!`
      : `✅ Success! Your farming story and produce have been published!`;
    setNotification(msg);
    speakText(lang === 'mr' ? `तुमची यशकथा नोंदवली आहे.` : `Story published successfully.`, lang);

    // Reset
    setFormData({
      farmerName: '',
      village: '',
      taluka: '',
      district: 'पुणे',
      region: 'paschim',
      mainCrop: '',
      variety: '',
      acres: '5',
      cropYieldRecord: '',
      netProfitPerAcre: '',
      farmingTechnique: '',
      produceItem: '',
      produceQty: '',
      producePrice: '',
      phone: '',
      storyQuote: ''
    });

    setTimeout(() => setNotification(null), 4500);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Toast Notification */}
      {notification && (
        <div className="fixed top-16 left-3 right-3 z-50 bg-slate-950 text-amber-300 p-3 rounded-2xl shadow-2xl border-2 border-[#FFC107] text-xs font-bold animate-bounce flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
            <span>{notification}</span>
          </div>
          <button onClick={() => setNotification(null)} className="text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Hero Header Banner */}
      <div className="bg-gradient-to-br from-amber-700 via-amber-900 to-emerald-950 rounded-3xl p-5 text-white shadow-xl border-2 border-[#FFC107] relative overflow-hidden">
        <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-amber-400/20 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-center justify-between mb-2">
          <div className="inline-flex items-center gap-1.5 bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider">
            <Award className="w-3.5 h-3.5 text-amber-950" />
            <span>{lang === 'mr' ? 'प्रगतशील शेतकरी हब' : 'Progressive Farmers Hub'}</span>
          </div>
          <span className="text-xs bg-black/40 border border-amber-400/50 px-2.5 py-0.5 rounded-full text-amber-300 font-bold">
            {lang === 'mr' ? 'महाराष्ट्रातील टॉप शेतकरी' : 'Top Farmers MH'}
          </span>
        </div>

        <h2 className="text-xl sm:text-2xl font-black text-white leading-snug">
          {lang === 'mr' ? '🌾 प्रगतशील शेतकरी, पीक माहिती व थेट शेतकरी खरेदी' : '🌾 Farmer Crop Records, Best Farming & Direct Buying'}
        </h2>
        <p className="text-xs sm:text-sm text-amber-100 mt-1 max-w-xl font-medium">
          {lang === 'mr'
            ? 'महाराष्ट्रातील प्रगतशील शेतकरी कोणती पिके घेतात? त्यांचे विक्रमी उत्पादन, शेतीची यशस्वी सूत्रे आणि थेट त्यांच्या शेतातून दर्जेदार बियाणे व माल खरेदी करा.'
            : 'Explore which crops top Maharashtra farmers grow, their record per-acre yields, best farming secrets, and buy certified seeds/produce directly.'}
        </p>

        {/* Action buttons */}
        <div className="mt-4 flex flex-wrap gap-2 pt-2 border-t border-amber-800/60">
          <button
            onClick={() => setShowAddStoryModal(true)}
            className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 bg-gradient-to-r from-emerald-500 to-[#1B5E20] hover:from-emerald-400 hover:to-emerald-600 text-white px-4 py-2.5 rounded-2xl font-black text-xs sm:text-sm shadow-lg transition-all active:scale-95 border border-emerald-300"
          >
            <PlusCircle className="w-4 h-4 text-amber-300" />
            <span>{lang === 'mr' ? 'तुमची पीक यशकथा व विक्री नोंदवा' : 'Share Your Story & Sell Crop'}</span>
          </button>

          <button
            onClick={() => {
              const text = lang === 'mr'
                ? 'प्रगतशील शेतकरी हब: येथे महाराष्ट्रातील टॉप शेतकऱ्यांच्या यशकथा, त्यांचे विक्रमी एकरी उत्पादन, शेतीची सूत्रे आणि थेट त्यांच्याकडून बियाणे व पीक खरेदी करण्याची सुविधा आहे.'
                : 'Progressive Farmers Hub showcases record-holding crop growers, their best techniques, and direct-from-farm buying.';
              speakText(text, lang);
            }}
            className="inline-flex items-center justify-center gap-1.5 bg-black/60 hover:bg-black/80 border border-amber-400/60 text-amber-300 px-3.5 py-2.5 rounded-2xl font-bold text-xs"
          >
            <Volume2 className="w-4 h-4" />
            <span>{lang === 'mr' ? 'माहिती ऐका' : 'Listen'}</span>
          </button>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-sm space-y-3">
        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={lang === 'mr' ? 'शेतकऱ्याचे नाव, पीक (उदा. ऊस, केळी, द्राक्ष), किंवा जिल्हा शोधा...' : 'Search farmer name, crop, or district...'}
            className="w-full pl-9 pr-8 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="absolute right-2.5 top-2.5 text-slate-400">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Region Filter Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
          {regions.map((reg) => (
            <button
              key={reg.id}
              onClick={() => setSelectedRegion(reg.id)}
              className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
                selectedRegion === reg.id
                  ? 'bg-amber-500 text-slate-950 shadow-sm font-black'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {lang === 'mr' ? reg.labelMr : reg.labelEn}
            </button>
          ))}
        </div>

        {/* Crop Filter Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs pt-1 border-t border-slate-100">
          <span className="text-[11px] font-bold text-slate-500 shrink-0">
            {lang === 'mr' ? 'पीक:' : 'Crop:'}
          </span>
          {cropFilters.map((crop) => (
            <button
              key={crop.id}
              onClick={() => setSelectedCrop(crop.id)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap transition-all ${
                selectedCrop === crop.id
                  ? 'bg-[#1B5E20] text-white shadow-sm'
                  : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
              }`}
            >
              {lang === 'mr' ? crop.labelMr : crop.labelEn}
            </button>
          ))}
        </div>
      </div>

      {/* Farmers Cards Grid */}
      <div className="space-y-4">
        {filteredFarmers.length === 0 ? (
          <div className="bg-white p-8 rounded-3xl text-center border border-slate-200 space-y-3">
            <Award className="w-12 h-12 text-slate-300 mx-auto" />
            <p className="font-bold text-slate-700 text-sm">
              {lang === 'mr' ? 'या शोधानुसार शेतकरी सापडले नाहीत.' : 'No farmers found matching search.'}
            </p>
            <button
              onClick={() => {
                setSelectedRegion('all');
                setSelectedCrop('all');
                setSearchQuery('');
              }}
              className="text-xs font-bold text-emerald-700 underline"
            >
              {lang === 'mr' ? 'सर्व फिल्टर्स रिसेट करा' : 'Reset all filters'}
            </button>
          </div>
        ) : (
          filteredFarmers.map((farmer) => (
            <div
              key={farmer.id}
              className="bg-white rounded-3xl p-4.5 border border-slate-200 shadow-sm hover:shadow-md transition-all space-y-3.5 relative overflow-hidden"
            >
              {/* Top Header Profile & Awards */}
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-start gap-3">
                  {farmer.image ? (
                    <img 
                      src={farmer.image} 
                      alt={farmer.farmerName} 
                      className="w-12 h-12 rounded-2xl object-cover shrink-0 border-2 border-emerald-200 shadow-sm"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-2xl bg-amber-50 border-2 border-amber-200 flex items-center justify-center text-2xl shrink-0">
                      {farmer.avatarEmoji}
                    </div>
                  )}
                  <div>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <h3 className="font-black text-base text-slate-900 leading-snug">
                        {farmer.farmerName}
                      </h3>
                      {farmer.verified && (
                        <span className="inline-flex items-center gap-0.5 text-[10px] font-black bg-emerald-100 text-emerald-900 border border-emerald-300 px-1.5 py-0.2 rounded-full">
                          <ShieldCheck className="w-3 h-3 text-emerald-700" />
                          {lang === 'mr' ? 'प्रमाणित' : 'Verified'}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1 text-xs text-slate-600 font-medium mt-0.5">
                      <MapPin className="w-3 h-3 text-amber-600 shrink-0" />
                      <span>{farmer.village}, {farmer.taluka} ({farmer.district}) • {farmer.acres} {lang === 'mr' ? 'एकर शेती' : 'Acres'}</span>
                    </div>

                    <div className="text-[10px] font-bold text-amber-800 bg-amber-50 px-2 py-0.5 rounded-md mt-1 inline-block border border-amber-200">
                      🏆 {lang === 'mr' ? farmer.awardsMr : farmer.awardsEn}
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => handleSpeakStory(farmer)}
                  className="p-2 bg-slate-50 hover:bg-amber-50 rounded-xl text-slate-600 hover:text-amber-700 border border-slate-200 transition-all shrink-0"
                  title={lang === 'mr' ? 'यशकथा ऐका' : 'Listen Story'}
                >
                  <Volume2 className="w-4 h-4" />
                </button>
              </div>

              {/* What Crop They Grow & Record Yield Highlight */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div className="bg-emerald-50/70 p-3 rounded-2xl border border-emerald-200 space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-black text-emerald-950">
                    <Leaf className="w-3.5 h-3.5 text-emerald-700" />
                    <span>{lang === 'mr' ? 'लागवड केलेले मुख्य पीक:' : 'Main Crop Grown:'}</span>
                  </div>
                  <div className="text-sm font-black text-[#1B5E20]">
                    {lang === 'mr' ? farmer.mainCropMr : farmer.mainCropEn}
                  </div>
                  <div className="text-[11px] text-slate-600 font-semibold">
                    {lang === 'mr' ? `वाण: ${farmer.variety}` : `Variety: ${farmer.variety}`}
                  </div>
                </div>

                <div className="bg-amber-50/80 p-3 rounded-2xl border border-amber-200 space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-black text-amber-950">
                    <TrendingUp className="w-3.5 h-3.5 text-amber-700" />
                    <span>{lang === 'mr' ? 'विक्रमी उत्पादन व नफा:' : 'Yield & Profit Record:'}</span>
                  </div>
                  <div className="text-xs font-black text-amber-900">
                    {lang === 'mr' ? farmer.cropYieldRecordMr : farmer.cropYieldRecordEn}
                  </div>
                  <div className="text-[11px] font-bold text-emerald-800">
                    💰 {lang === 'mr' ? farmer.netProfitPerAcreMr : farmer.netProfitPerAcreEn}
                  </div>
                </div>
              </div>

              {/* Best Farming Secrets & Techniques */}
              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200/80 space-y-1.5">
                <div className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                  <span>{lang === 'mr' ? 'यशस्वी शेतीची सूत्रे व पद्धती (Best Farming Secrets):' : 'Key Farming Secrets & Techniques:'}</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                  {(lang === 'mr' ? farmer.bestFarmingTechniquesMr : farmer.bestFarmingTechniquesEn).map((tech, idx) => (
                    <div key={idx} className="flex items-start gap-1.5 text-xs text-slate-700">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{tech}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Quote from farmer */}
              <div className="bg-gradient-to-r from-amber-50 to-orange-50 p-2.5 rounded-xl border-l-4 border-amber-500 text-xs italic text-slate-800 flex items-start gap-2">
                <Quote className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <span>"{lang === 'mr' ? farmer.storyQuoteMr : farmer.storyQuoteEn}"</span>
              </div>

              {/* Direct Farm Produce for Sale */}
              {farmer.produceForSale && farmer.produceForSale.length > 0 && (
                <div className="bg-emerald-900 text-white p-3.5 rounded-2xl space-y-2 border border-emerald-700">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5 font-black text-amber-300">
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>{lang === 'mr' ? 'थेट शेतातून विक्रीसाठी उपलब्ध (Buy Direct):' : 'Available Direct from Farm:'}</span>
                    </div>
                    <span className="text-[10px] bg-emerald-800 px-2 py-0.5 rounded-full font-bold">
                      {lang === 'mr' ? 'दलालीमुक्त' : 'Zero Middlemen'}
                    </span>
                  </div>

                  <div className="space-y-1.5">
                    {farmer.produceForSale.map((prod, pIdx) => (
                      <div key={pIdx} className="bg-emerald-950/80 p-2 rounded-xl border border-emerald-800 flex items-center justify-between text-xs">
                        <div>
                          <div className="font-bold text-white">
                            {lang === 'mr' ? prod.itemMr : prod.itemEn}
                          </div>
                          <div className="text-[10px] text-emerald-300">
                            {prod.quantityAvailable} • {prod.qualityGrade}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-black text-amber-400 text-xs">
                            {prod.priceRate}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Contact Actions */}
              <div className="pt-2 border-t border-slate-100 flex gap-2">
                <button
                  onClick={() => handleCall(farmer)}
                  className="flex-1 flex items-center justify-center gap-1.5 bg-[#1B5E20] hover:bg-emerald-800 text-white py-2.5 px-3 rounded-xl font-black text-xs shadow-sm transition-all active:scale-95"
                >
                  <PhoneCall className="w-3.5 h-3.5 text-amber-300" />
                  <span>{lang === 'mr' ? 'थेट फोन करा' : 'Call Farmer'}</span>
                </button>

                <button
                  onClick={() => handleWhatsApp(farmer)}
                  className="flex-1 flex items-center justify-center gap-1.5 bg-[#25D366] hover:bg-emerald-600 text-slate-950 py-2.5 px-3 rounded-xl font-black text-xs shadow-sm transition-all active:scale-95"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>{lang === 'mr' ? 'WhatsApp खरेदी व सल्ला' : 'WhatsApp Order'}</span>
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add Farmer Story Modal */}
      {showAddStoryModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-5 space-y-4 shadow-2xl border-2 border-[#FFC107] max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-600" />
                <h3 className="font-black text-base text-slate-900">
                  {lang === 'mr' ? 'तुमची शेती यशकथा व पीक विक्री जोडा' : 'Add Your Farming Story & Produce'}
                </h3>
              </div>
              <button onClick={() => setShowAddStoryModal(false)} className="p-1 rounded-full hover:bg-slate-100 text-slate-500">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {lang === 'mr' ? 'शेतकऱ्याचे नाव *' : 'Farmer Name *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.farmerName}
                    onChange={(e) => setFormData({ ...formData, farmerName: e.target.value })}
                    placeholder="उदा. महेश पाटील"
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {lang === 'mr' ? 'मोबाईल नंबर *' : 'Phone Number *'}
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="९८२२००११२२"
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {lang === 'mr' ? 'गाव' : 'Village'}
                  </label>
                  <input
                    type="text"
                    value={formData.village}
                    onChange={(e) => setFormData({ ...formData, village: e.target.value })}
                    placeholder="गाव"
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {lang === 'mr' ? 'तालुका' : 'Taluka'}
                  </label>
                  <input
                    type="text"
                    value={formData.taluka}
                    onChange={(e) => setFormData({ ...formData, taluka: e.target.value })}
                    placeholder="तालुका"
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {lang === 'mr' ? 'जिल्हा' : 'District'}
                  </label>
                  <input
                    type="text"
                    value={formData.district}
                    onChange={(e) => setFormData({ ...formData, district: e.target.value })}
                    placeholder="जिल्हा"
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  />
                </div>
              </div>

              {/* Crop details */}
              <div className="pt-2 border-t border-slate-100 space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      {lang === 'mr' ? 'मुख्य पीक *' : 'Main Crop *'}
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.mainCrop}
                      onChange={(e) => setFormData({ ...formData, mainCrop: e.target.value })}
                      placeholder="उदा. ऊस, केळी, डाळिंब"
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      {lang === 'mr' ? 'वाण / व्हरायटी' : 'Variety'}
                    </label>
                    <input
                      type="text"
                      value={formData.variety}
                      onChange={(e) => setFormData({ ...formData, variety: e.target.value })}
                      placeholder="उदा. Co 86032 / G9"
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      {lang === 'mr' ? 'विक्रमी उत्पादन (एकर)' : 'Record Yield / Acre'}
                    </label>
                    <input
                      type="text"
                      value={formData.cropYieldRecord}
                      onChange={(e) => setFormData({ ...formData, cropYieldRecord: e.target.value })}
                      placeholder="उदा. एकरी १२० टन"
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      {lang === 'mr' ? 'निव्वळ नफा (एकर)' : 'Net Profit / Acre'}
                    </label>
                    <input
                      type="text"
                      value={formData.netProfitPerAcre}
                      onChange={(e) => setFormData({ ...formData, netProfitPerAcre: e.target.value })}
                      placeholder="उदा. ₹४ लाख"
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {lang === 'mr' ? 'शेतीचे मुख्य तंत्र / सूत्र' : 'Key Farming Technique'}
                  </label>
                  <input
                    type="text"
                    value={formData.farmingTechnique}
                    onChange={(e) => setFormData({ ...formData, farmingTechnique: e.target.value })}
                    placeholder="उदा. ५x२ फूट पट्टा जोडओळ + जीवामृत ड्रिपने देणे"
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  />
                </div>
              </div>

              {/* Produce for sale */}
              <div className="pt-2 border-t border-slate-100 space-y-2">
                <label className="block font-bold text-emerald-800">
                  {lang === 'mr' ? 'शेतातून थेट विक्रीसाठी उपलब्ध उत्पादन (ऐच्छिक)' : 'Produce for Sale from Farm (Optional)'}
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <input
                    type="text"
                    value={formData.produceItem}
                    onChange={(e) => setFormData({ ...formData, produceItem: e.target.value })}
                    placeholder="उदा. प्रमाणित ऊस रोपे"
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  />
                  <input
                    type="text"
                    value={formData.produceQty}
                    onChange={(e) => setFormData({ ...formData, produceQty: e.target.value })}
                    placeholder="उदा. २०,००० रोपे"
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  />
                  <input
                    type="text"
                    value={formData.producePrice}
                    onChange={(e) => setFormData({ ...formData, producePrice: e.target.value })}
                    placeholder="उदा. ₹१.८० / रोप"
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  {lang === 'mr' ? 'इतर शेतकऱ्यांना संदेश / सल्ला' : 'Advice for Other Farmers'}
                </label>
                <textarea
                  rows={2}
                  value={formData.storyQuote}
                  onChange={(e) => setFormData({ ...formData, storyQuote: e.target.value })}
                  placeholder={lang === 'mr' ? 'तुमचा अनुभव व सल्ला थोडक्यात लिहा...' : 'Share your advice...'}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium resize-none"
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddStoryModal(false)}
                  className="flex-1 py-2.5 bg-slate-100 text-slate-700 rounded-xl font-bold"
                >
                  {lang === 'mr' ? 'रद्द करा' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 rounded-xl font-black shadow-lg"
                >
                  {lang === 'mr' ? 'यशकथा प्रकाशित करा ✓' : 'Publish Story ✓'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
