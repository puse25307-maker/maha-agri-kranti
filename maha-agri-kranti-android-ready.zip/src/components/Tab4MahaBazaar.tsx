import React, { useState } from 'react';
import { 
  Truck, 
  ShoppingBag, 
  TrendingUp, 
  DollarSign, 
  PlusCircle, 
  Star, 
  Check, 
  X, 
  PhoneCall, 
  Volume2, 
  Sparkles,
  ArrowUpRight
} from 'lucide-react';
import { MARKET_CROPS, EXPORT_BHAV_TABLE, LIVE_MANDI_RATES } from '../data/agriData';
import { MarketCropItem } from '../types';
import { speakMarathi } from '../utils/speech';

export const Tab4MahaBazaar: React.FC = () => {
  const [crops, setCrops] = useState<MarketCropItem[]>(MARKET_CROPS);
  const [showAddProduceModal, setShowAddProduceModal] = useState(false);
  const [selectedCropToBuy, setSelectedCropToBuy] = useState<MarketCropItem | null>(null);
  const [orderSuccessAlert, setOrderSuccessAlert] = useState<string | null>(null);

  // Group booking state
  const [truckJoined, setTruckJoined] = useState(false);
  const [truckFarmersCount, setTruckFarmersCount] = useState(12);

  // Form state
  const [cropName, setCropName] = useState('');
  const [farmerName, setFarmerName] = useState('');
  const [location, setLocation] = useState('');
  const [quantity, setQuantity] = useState('');
  const [price, setPrice] = useState('');
  const [apmcRefPrice, setApmcRefPrice] = useState('');
  const [contact, setContact] = useState('');

  const handleJoinTruck = () => {
    if (!truckJoined) {
      setTruckJoined(true);
      setTruckFarmersCount((prev) => prev + 1);
      setOrderSuccessAlert('🚚 अभिनंदन! तुम्ही थेट इराण/दिल्ली जाणाऱ्या ट्रक ग्रुप बुकिंगमध्ये सामील झाला आहात!');
      speakMarathi('तुम्ही एक ट्रक भरूया शेतकरी ग्रुप बुकिंगमध्ये सामील झाला आहात. तुमचे भाडे ३० टक्के कमी होईल.');
    } else {
      setTruckJoined(false);
      setTruckFarmersCount((prev) => prev - 1);
    }
  };

  const handleAddProduce = (e: React.FormEvent) => {
    e.preventDefault();
    if (!cropName || !price) return;

    const newItem: MarketCropItem = {
      id: `mc_${Date.now()}`,
      nameMr: cropName,
      nameEn: cropName,
      emoji: '🌾',
      farmerName: farmerName || 'प्रगतशील शेतकरी',
      location: location || 'इंदापूर, पुणे',
      qty: quantity || '२ टन उपलब्ध',
      directPrice: parseFloat(price) || 25,
      apmcPrice: parseFloat(apmcRefPrice) || Math.round(parseFloat(price) * 0.7),
      contact: contact || '९८२२००११२२',
      tag: '✨ नवीन नोंद'
    };

    setCrops([newItem, ...crops]);
    setShowAddProduceModal(false);
    setOrderSuccessAlert(`✅ ${cropName} विक्रीसाठी महा बाजारात थेट लिस्ट झाला आहे!`);
    speakMarathi(`${cropName} विक्रीसाठी महा बाजारात यशस्वीरित्या जोडले आहे.`);

    setCropName('');
    setFarmerName('');
    setLocation('');
    setQuantity('');
    setPrice('');
    setApmcRefPrice('');
    setContact('');
  };

  const handleBuyClick = (item: MarketCropItem) => {
    setSelectedCropToBuy(item);
    speakMarathi(`${item.farmerName} यांच्या ${item.nameMr} खरेदीसाठी थेट संपर्क सुरू आहे.`);
  };

  const handleSpeakExportComparison = () => {
    const text = 'थेट निर्यात भाव तुलना: लोकल आडतीमध्ये १५ रुपये प्रति किलोने १० टनाचे दीड लाख रुपये मिळतात. तेच जर इराणला थेट निर्यात केले तर १२५ रुपये किलोने साडेबारा लाख रुपये मिळतात. म्हणजे शेतकऱ्याला सात पट जॅकपॉट नफा मिळतो.';
    speakMarathi(text);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Alert Notification */}
      {orderSuccessAlert && (
        <div className="fixed top-16 left-3 right-3 z-50 bg-slate-950 text-amber-300 p-3 rounded-2xl shadow-2xl border-2 border-[#FFC107] text-xs font-bold animate-bounce flex items-center justify-between">
          <span>{orderSuccessAlert}</span>
          <button onClick={() => setOrderSuccessAlert(null)} className="text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-gradient-to-br from-[#1B5E20] via-emerald-800 to-slate-900 text-white p-3.5 rounded-2xl shadow-lg border border-emerald-500">
        <div className="flex items-center justify-between mb-1">
          <span className="bg-[#FFC107] text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
            🛒 महा बाजार - थेट विक्री
          </span>
          <span className="text-[10px] text-amber-300 font-bold">
            दलालमुक्त शेतकरी बाजार
          </span>
        </div>
        <h2 className="text-base font-black text-white leading-tight">
          शेतकरी स्वतःच व्यापारी — थेट ग्राहकाला व व्यापाऱ्याला विका!
        </h2>
        <p className="text-[11px] text-emerald-100 mt-0.5">
          APMC आडत वाचवा आणि थेट २५% ते ३००% जादा भाव मिळवा
        </p>
      </div>

      {/* 1. Yellow Banner: "🚚 Ek Truck Bharuya" Group Booking */}
      <div className="bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-400 p-3.5 rounded-2xl shadow-lg border-2 border-amber-500 text-slate-950">
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-slate-950 text-amber-300 flex items-center justify-center shrink-0 shadow">
              <Truck className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <span className="text-[10px] font-black bg-red-600 text-white px-2 py-0.5 rounded-full uppercase tracking-wider">
                ग्रुप बुकिंग (Group Booking)
              </span>
              <h3 className="text-xs font-black leading-tight mt-0.5">
                🚚 एक ट्रक भरूया — थेट दिल्ली / आखाती निर्यात!
              </h3>
            </div>
          </div>
        </div>

        <p className="text-xs text-slate-900 font-medium mb-3">
          लहान शेतकऱ्यांनी मिळून १० टन माल एकत्र केल्यास वाहतूक खर्च ४०% कमी होतो आणि थेट निर्यात भाव मिळतो.
        </p>

        <div className="flex items-center justify-between bg-white/70 p-2.5 rounded-xl border border-amber-400/60 mb-2">
          <div className="flex items-center gap-1.5 text-xs font-bold">
            <span className="w-2 h-2 rounded-full bg-emerald-600 animate-ping"></span>
            <span>{truckFarmersCount} शेतकरी सामील झाले आहेत</span>
          </div>
          <span className="text-[10px] font-black text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
            ७.५ टन भरले (२.५ टन शिल्लक)
          </span>
        </div>

        <button
          onClick={handleJoinTruck}
          className={`w-full py-2.5 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 shadow-md transition-all active:scale-95 ${
            truckJoined
              ? 'bg-emerald-800 text-white'
              : 'bg-slate-950 text-amber-300 hover:bg-slate-900'
          }`}
        >
          <Truck className="w-4 h-4" />
          <span>{truckJoined ? '✅ तुम्ही ग्रुपमध्ये आहात (बाहेर पडा)' : '🚚 मी पण माल देणार — ग्रुपमध्ये सामील व्हा'}</span>
        </button>
      </div>

      {/* 2. Crop List: Shetkari Swatach Vyapari */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
            <ShoppingBag className="w-3.5 h-3.5 text-[#1B5E20]" />
            थेट शेतातील ताजा माल (Direct Farm Listings):
          </h3>
          <button
            onClick={() => setShowAddProduceModal(true)}
            className="bg-[#1B5E20] hover:bg-emerald-800 text-amber-300 text-[10px] font-black px-2.5 py-1 rounded-lg flex items-center gap-1 shadow shrink-0"
          >
            <PlusCircle className="w-3 h-3" /> + माझा माल विका
          </button>
        </div>

        <div className="grid grid-cols-1 gap-2.5">
          {crops.map((item) => (
            <div
              key={item.id}
              className="bg-white p-3 rounded-2xl shadow-md border border-slate-200 hover:border-emerald-500 transition-all flex flex-col justify-between"
            >
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="flex items-start gap-2.5">
                  <span className="text-3xl p-1.5 bg-emerald-50 rounded-xl border border-emerald-100">
                    {item.emoji}
                  </span>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h4 className="font-black text-xs text-slate-950">{item.nameMr}</h4>
                      {item.tag && (
                        <span className="text-[9px] font-bold bg-amber-100 text-amber-900 px-1.5 py-0.2 rounded">
                          {item.tag}
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-emerald-800 font-bold">{item.farmerName} • {item.location}</p>
                    <p className="text-[10px] text-slate-600 font-semibold mt-0.5">उपलब्ध: {item.qty}</p>
                  </div>
                </div>

                {/* Price Display */}
                <div className="text-right shrink-0">
                  <div className="text-base font-black text-emerald-800 leading-none">
                    ₹{item.directPrice} <span className="text-[10px] font-normal text-slate-600">/किलो</span>
                  </div>
                  <div className="text-[9px] text-slate-600 line-through mt-0.5 font-bold">
                    APMC: ₹{item.apmcPrice}/kg
                  </div>
                  <span className="text-[8px] bg-red-100 text-red-700 font-bold px-1 rounded">
                    +{(item.directPrice - item.apmcPrice) * 100 / item.apmcPrice | 0}% जादा नफा
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                <span className="text-[9px] text-slate-500 font-bold">
                  📞 थेट शेतकरी नंबर: {item.contact}
                </span>
                <button
                  onClick={() => handleBuyClick(item)}
                  className="bg-[#1B5E20] hover:bg-emerald-800 text-amber-300 font-black px-3 py-1 rounded-lg text-xs flex items-center gap-1 shadow active:scale-95"
                >
                  <PhoneCall className="w-3 h-3 text-amber-400" />
                  <span>खरेदी करा</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 3. Export Bhav Comparison Table */}
      <div className="bg-white p-4 rounded-2xl shadow-md border border-slate-200">
        <div className="flex items-center justify-between mb-2">
          <div>
            <h3 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-700" />
              थेट निर्यात भाव तुलना (१० टन मालावर नफा):
            </h3>
            <p className="text-[10px] text-slate-500">लोकल आडत vs दुबई vs इराण जॅकपॉट</p>
          </div>
          <button
            onClick={handleSpeakExportComparison}
            className="text-[10px] bg-amber-400 hover:bg-amber-500 text-slate-950 px-2 py-1 rounded-lg font-bold flex items-center gap-1 shadow-sm"
          >
            <Volume2 className="w-3 h-3" /> ऐका 🔊
          </button>
        </div>

        <div className="overflow-hidden rounded-xl border border-slate-200">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-100 text-[10px] text-slate-700 border-b border-slate-200">
                <th className="p-2 font-bold">मार्केट ठिकाण</th>
                <th className="p-2 font-bold text-center">दर / किलो</th>
                <th className="p-2 font-bold text-center">१० टन रक्कम</th>
                <th className="p-2 font-bold text-right">नफा गुणक</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-[11px]">
              {EXPORT_BHAV_TABLE.map((row, idx) => (
                <tr key={idx} className={`${row.color} transition-all`}>
                  <td className="p-2 font-semibold">{row.market}</td>
                  <td className="p-2 text-center font-bold">₹{row.price}</td>
                  <td className="p-2 text-center font-black">₹{row.totalOn10Ton}</td>
                  <td className="p-2 text-right font-black">{row.multiplier}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-2.5 p-2 bg-amber-50 border border-amber-200 rounded-xl text-[10px] text-amber-950 font-bold flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-amber-600 shrink-0" />
          <span>टीप: इराणला थेट केळी पाठवल्यास २१ दिवसांत बँक खात्यात थेट पेमेंट जमा होते.</span>
        </div>
      </div>

      {/* 4. Live APMC Mandi Rates Ticker */}
      <div className="bg-slate-900 text-white p-3 rounded-2xl shadow-md border border-slate-800">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[10px] font-black text-amber-400 uppercase tracking-wider flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
            महाराष्ट्र बाजार समिती थेट लाइव्ह भाव (Live Mandi)
          </span>
          <span className="text-[9px] text-slate-400">आजचे ताजे भाव</span>
        </div>

        <div className="grid grid-cols-2 gap-1.5 text-[10px]">
          {LIVE_MANDI_RATES.slice(0, 6).map((rate, idx) => (
            <div key={idx} className="p-2 bg-slate-800/80 rounded-lg border border-slate-700 flex justify-between items-center">
              <div>
                <span className="font-bold text-amber-200 block">{rate.mandi}</span>
                <span className="text-[9px] text-slate-300">{rate.crop}</span>
              </div>
              <div className="text-right">
                <span className="font-black text-emerald-400 block">₹{rate.avgPrice}</span>
                <span className="text-[8px] text-slate-400">₹{rate.minPrice}-₹{rate.maxPrice}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modal: Add Produce Form */}
      {showAddProduceModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl border-2 border-emerald-600 overflow-hidden">
            <div className="bg-[#1B5E20] text-white p-3 flex items-center justify-between">
              <h3 className="font-bold text-xs text-amber-300">+ माझा शेतमाल विक्रीसाठी ठेवा</h3>
              <button onClick={() => setShowAddProduceModal(false)} className="text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleAddProduce} className="p-4 space-y-2.5 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-0.5">शेतमालाचे नाव (उदा. केळी G9 / द्राक्ष):</label>
                <input
                  type="text"
                  required
                  placeholder="उदा. निर्यातक्षम केळी"
                  value={cropName}
                  onChange={(e) => setCropName(e.target.value)}
                  className="w-full p-2 border rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-0.5">माझा अपेक्षित दर (₹/kg):</label>
                  <input
                    type="number"
                    required
                    placeholder="उदा. २२"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full p-2 border rounded-lg font-bold text-emerald-800"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-0.5">APMC बाजार भाव:</label>
                  <input
                    type="number"
                    placeholder="उदा. १५"
                    value={apmcRefPrice}
                    onChange={(e) => setApmcRefPrice(e.target.value)}
                    className="w-full p-2 border rounded-lg text-slate-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-0.5">शेतकऱ्याचे नाव:</label>
                  <input
                    type="text"
                    placeholder="उदा. अनिल पवार"
                    value={farmerName}
                    onChange={(e) => setFarmerName(e.target.value)}
                    className="w-full p-2 border rounded-lg"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-0.5">उपलब्ध प्रमाण (उदा. २ टन):</label>
                  <input
                    type="text"
                    placeholder="उदा. ५ टन"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    className="w-full p-2 border rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-0.5">गाव / तालुका (Location):</label>
                <input
                  type="text"
                  placeholder="उदा. इंदापूर, पुणे"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full p-2 border rounded-lg"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-0.5">मोबाईल नंबर (Contact):</label>
                <input
                  type="tel"
                  placeholder="९८xxxxxxxx"
                  value={contact}
                  onChange={(e) => setContact(e.target.value)}
                  className="w-full p-2 border rounded-lg"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-[#1B5E20] hover:bg-emerald-800 text-amber-300 font-black py-2.5 rounded-xl text-xs shadow-md mt-2"
              >
                विकायला ठेवा (Publish Produce)
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Direct Buy Contact */}
      {selectedCropToBuy && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl border-2 border-emerald-600 overflow-hidden">
            <div className="bg-[#1B5E20] text-white p-3 flex items-center justify-between">
              <h3 className="font-bold text-xs text-amber-300">थेट खरेदी ऑर्डर (Direct Farm Purchase)</h3>
              <button onClick={() => setSelectedCropToBuy(null)} className="text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 space-y-3 text-xs">
              <div className="flex items-center gap-3 bg-emerald-50 p-3 rounded-xl border border-emerald-200">
                <span className="text-3xl">{selectedCropToBuy.emoji}</span>
                <div>
                  <h4 className="font-black text-slate-950">{selectedCropToBuy.nameMr}</h4>
                  <p className="text-emerald-800 font-bold">{selectedCropToBuy.farmerName} • {selectedCropToBuy.location}</p>
                  <p className="text-slate-600 font-bold">दर: ₹{selectedCropToBuy.directPrice}/kg ({selectedCropToBuy.qty})</p>
                </div>
              </div>

              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-slate-800">
                <span className="font-bold text-amber-950 block mb-1">शेतकऱ्यांशी थेट व्यवहार:</span>
                <p className="text-[11px] leading-relaxed">
                  तुम्ही शेतकऱ्याशी थेट बोलून शेतावर वजन आणि रोख/NEFT पेमेंट ठरवू शकता. कोणताही दलाल किंवा कमिशन नाही!
                </p>
              </div>

              <div className="space-y-2 pt-1">
                <button
                  onClick={() => {
                    setOrderSuccessAlert(`📞 ${selectedCropToBuy.farmerName} यांना कॉल जोडला जात आहे... फोन: ${selectedCropToBuy.contact}`);
                    setSelectedCropToBuy(null);
                  }}
                  className="w-full bg-[#1B5E20] text-amber-300 font-black py-2.5 rounded-xl flex items-center justify-center gap-1.5 shadow"
                >
                  <PhoneCall className="w-4 h-4 text-amber-400" />
                  <span>शेतकऱ्याला कॉल करा ({selectedCropToBuy.contact})</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
